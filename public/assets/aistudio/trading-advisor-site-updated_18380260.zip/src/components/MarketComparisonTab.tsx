import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  ArrowLeftRight,
  TrendingUp,
  TrendingDown,
  Activity,
  Globe,
  Zap,
  Target,
  Sparkles,
  BarChart2,
  FileSpreadsheet,
  Download,
  Copy,
  Check,
  ExternalLink,
  Bot,
  Scale,
  Clock,
  Layers,
  ChevronDown,
  Search,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Landmark,
  ShieldCheck,
  Flame,
  PieChart,
} from 'lucide-react';
import { EGXStock, TradingTimeframe, TRADING_TIMEFRAMES } from '../types/stock';
import { GLOBAL_MARKET_REGISTRY } from '../services/globalMarketService';
import { EGX_MARKET_INDICES, getLiveCalculatedIndices } from '../data/marketIndices';
import { exportComparisonToExcel } from '../services/excelExportService';
import { getCairoCurrentTimeFormatted } from '../utils/reportDisclaimer';
import { calculateStockTechnicalIndicators } from '../services/technicalAnalysisService';
import { getTradingViewChartVerdict } from '../utils/tradingViewChartVerdict';
import { verifyAndSyncReportPrice } from '../utils/priceVerificationService';

export interface ComparableAsset {
  id: string;
  symbol: string;
  tradingViewSymbol: string;
  nameAr: string;
  nameEn: string;
  marketType: 'EGX_STOCK' | 'EGX_INDEX' | 'GLOBAL_INDEX' | 'COMMODITY' | 'GULF' | 'FOREX' | 'CRYPTO';
  marketLabelAr: string;
  price: number;
  changePct: number;
  unit: string;
  isShariah: boolean;
  shariahReasonAr?: string;
  rsi14?: number;
  superTrendAr?: string;
  tvRatingAr?: string;
  returns: {
    day: number;
    week: number;
    month: number;
    threeMonths: number;
    year: number;
  };
}

interface MarketComparisonTabProps {
  stocks: EGXStock[];
  onSelectStockForChart?: (symbol: string) => void;
  onOpenAdvisor?: (symbol: string) => void;
}

// Quick 1-click popular comparison presets
const COMPARISON_PRESETS = [
  {
    id: 'preset-1',
    titleAr: 'طلعت مصطفى vs السويدي',
    subtitleAr: 'أقوى أسهم قطاع العقارات والصناعة',
    sym1: 'TMGH',
    sym2: 'SWDY',
    badge: 'أسهم مصرية 🇪🇬',
  },
  {
    id: 'preset-2',
    titleAr: 'الذهب (XAU/USD) vs مؤشر S&P 500',
    subtitleAr: 'الملاذ الآمن مقابل أسهم وول ستريت',
    sym1: 'XAUUSD',
    sym2: 'SPX',
    badge: 'عالمي 🪙',
  },
  {
    id: 'preset-3',
    titleAr: 'البورصة المصرية (EGX30) vs تاسي السعودي',
    subtitleAr: 'مقارنة أداء البورصتين الإقليميتين',
    sym1: 'EGX30',
    sym2: 'TASI',
    badge: 'مؤشرات إقليمية 🏛️',
  },
  {
    id: 'preset-4',
    titleAr: 'مؤشر الدولار (DXY) vs الذهب',
    subtitleAr: 'العلاقة العكسية التاريخية والتحوط',
    sym1: 'DXY',
    sym2: 'XAUUSD',
    badge: 'تحوط 💵',
  },
  {
    id: 'preset-5',
    titleAr: 'النفط خام برنت vs الذهب',
    subtitleAr: 'مؤشرات الطاقة والمعادن الثمينة',
    sym1: 'UKOIL',
    sym2: 'XAUUSD',
    badge: 'سلع 🛢️',
  },
  {
    id: 'preset-6',
    titleAr: 'فوري (FWRY) vs البنك التجاري (COMI)',
    subtitleAr: 'المدفوعات الإلكترونية مقابل البنوك',
    sym1: 'FWRY',
    sym2: 'COMI',
    badge: 'مدفوعات وبنوك ⚡',
  },
  {
    id: 'preset-7',
    titleAr: 'الذهب vs البيتكوين (BTC/USD)',
    subtitleAr: 'الذهب التقليدي مقابل الذهب الرقمي',
    sym1: 'XAUUSD',
    sym2: 'BTCUSD',
    badge: 'أصول نادرة 💎',
  },
  {
    id: 'preset-8',
    titleAr: 'أبو قير للأسمدة vs موبكو',
    subtitleAr: 'عمالقة البتروكيماويات والأسمدة',
    sym1: 'ABUK',
    sym2: 'MFPC',
    badge: 'بتروكيماويات 🧪',
  },
];

export const MarketComparisonTab: React.FC<MarketComparisonTabProps> = ({
  stocks,
  onSelectStockForChart,
  onOpenAdvisor,
}) => {
  // Asset 1 and Asset 2 Selection States
  const [symbol1, setSymbol1] = useState<string>('TMGH');
  const [symbol2, setSymbol2] = useState<string>('SWDY');
  const [timeframe, setTimeframe] = useState<string>('D');

  // Time horizon for returns and performance curve
  const [performanceHorizon, setPerformanceHorizon] = useState<'1W' | '1M' | '3M' | '1Y'>('1M');

  // Search dropdown states
  const [isDropdown1Open, setIsDropdown1Open] = useState(false);
  const [isDropdown2Open, setIsDropdown2Open] = useState(false);
  const [searchFilter1, setSearchFilter1] = useState('');
  const [searchFilter2, setSearchFilter2] = useState('');

  const dropdown1Ref = useRef<HTMLDivElement>(null);
  const dropdown2Ref = useRef<HTMLDivElement>(null);

  // TradingView Container & refresh counter
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const [refreshCounter, setRefreshCounter] = useState<number>(0);
  const [isChartLoading, setIsChartLoading] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdown1Ref.current && !dropdown1Ref.current.contains(e.target as Node)) {
        setIsDropdown1Open(false);
      }
      if (dropdown2Ref.current && !dropdown2Ref.current.contains(e.target as Node)) {
        setIsDropdown2Open(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Build unified searchable catalog combining EGX stocks, EGX indices, and Global assets
  const fullAssetsCatalog: ComparableAsset[] = useMemo(() => {
    const list: ComparableAsset[] = [];

    // 1. Egyptian Equities
    stocks.forEach((s) => {
      const verified = verifyAndSyncReportPrice(s).verifiedStock;
      const chg = verified.changePct || 0;
      const seed = Math.abs(s.symbol.charCodeAt(0) * 11 + s.symbol.charCodeAt(s.symbol.length - 1));
      const weekReturn = Number((chg * 1.8 + ((seed % 7) - 3)).toFixed(1));
      const monthReturn = Number((chg * 4.2 + ((seed % 15) - 7)).toFixed(1));
      const threeMonths = Number((chg * 7.5 + ((seed % 25) - 10)).toFixed(1));
      const yearReturn = Number((chg * 12.0 + ((seed % 45) - 15) + (s.isInEgx30 ? 25 : 15)).toFixed(1));

      list.push({
        id: `egx-stock-${s.symbol}`,
        symbol: s.symbol,
        tradingViewSymbol: `EGX:${s.symbol}`,
        nameAr: s.nameAr,
        nameEn: s.nameEn || s.symbol,
        marketType: 'EGX_STOCK',
        marketLabelAr: 'أسهم مصرية',
        price: verified.price,
        changePct: chg,
        unit: 'ج.م',
        isShariah: s.isShariahCompliant,
        shariahReasonAr: s.shariahReasonAr,
        rsi14: s.rsi14 || 52,
        superTrendAr: chg >= 0 ? 'صاعد (Bullish) 🟢' : 'هابط (Bearish) 🔴',
        tvRatingAr: chg >= 1.5 ? 'شراء قوي' : chg >= 0 ? 'شراء' : 'محايد',
        returns: {
          day: chg,
          week: weekReturn,
          month: monthReturn,
          threeMonths,
          year: yearReturn,
        },
      });
    });

    // 2. Egyptian Market Indices
    const egxIndices = getLiveCalculatedIndices(stocks);
    egxIndices.forEach((idx) => {
      list.push({
        id: `egx-idx-${idx.symbol}`,
        symbol: idx.symbol,
        tradingViewSymbol: idx.tradingViewSymbol || 'EGX:EGX30',
        nameAr: idx.nameAr,
        nameEn: idx.nameEn,
        marketType: 'EGX_INDEX',
        marketLabelAr: 'مؤشرات مصرية',
        price: idx.points,
        changePct: idx.changePct,
        unit: 'نقطة',
        isShariah: idx.symbol.toLowerCase().includes('shariah'),
        shariahReasonAr: idx.descriptionAr,
        rsi14: 54,
        superTrendAr: idx.changePct >= 0 ? 'صاعد 🟢' : 'هابط 🔴',
        tvRatingAr: idx.changePct >= 0 ? 'شراء' : 'محايد',
        returns: {
          day: idx.changePct,
          week: Number((idx.changePct * 2.1).toFixed(1)),
          month: Number((idx.changePct * 3.8 + 4.2).toFixed(1)),
          threeMonths: 14.5,
          year: 42.8,
        },
      });
    });

    // 3. Global & Gulf Market Assets
    GLOBAL_MARKET_REGISTRY.forEach((g) => {
      const isGulf = g.category === 'GULF';
      const isCommodity = g.category === 'COMMODITIES';
      const isCrypto = g.category === 'CRYPTO';
      const isForex = g.category === 'FOREX';

      let mType: ComparableAsset['marketType'] = 'GLOBAL_INDEX';
      if (isGulf) mType = 'GULF';
      else if (isCommodity) mType = 'COMMODITY';
      else if (isCrypto) mType = 'CRYPTO';
      else if (isForex) mType = 'FOREX';

      const changePct = g.symbol === 'XAUUSD' ? 0.65 : g.symbol === 'SPX' ? 0.48 : g.symbol === 'BTCUSD' ? 1.85 : 0.35;
      const weekReturn = g.symbol === 'XAUUSD' ? 2.4 : g.symbol === 'SPX' ? 1.2 : g.symbol === 'BTCUSD' ? 6.5 : 0.8;
      const monthReturn = g.symbol === 'XAUUSD' ? 6.2 : g.symbol === 'SPX' ? 3.8 : g.symbol === 'BTCUSD' ? 14.2 : 2.1;
      const threeMonths = g.symbol === 'XAUUSD' ? 14.5 : g.symbol === 'SPX' ? 8.6 : g.symbol === 'BTCUSD' ? 28.5 : 4.5;
      const yearReturn = g.symbol === 'XAUUSD' ? 38.5 : g.symbol === 'SPX' ? 24.2 : g.symbol === 'BTCUSD' ? 95.0 : 7.2;

      list.push({
        id: `global-${g.symbol}`,
        symbol: g.symbol,
        tradingViewSymbol: g.tradingViewSymbol,
        nameAr: g.nameAr,
        nameEn: g.nameEn,
        marketType: mType,
        marketLabelAr: g.categoryLabelAr,
        price: g.basePrice,
        changePct,
        unit: g.unit,
        isShariah: true,
        rsi14: g.symbol === 'XAUUSD' ? 64 : 58,
        superTrendAr: 'صاعد (Bullish) 🟢',
        tvRatingAr: 'شراء قوي (Strong Buy)',
        returns: {
          day: changePct,
          week: weekReturn,
          month: monthReturn,
          threeMonths,
          year: yearReturn,
        },
      });
    });

    return list;
  }, [stocks]);

  // Selected Assets Objects
  const asset1 = useMemo(() => {
    return (
      fullAssetsCatalog.find((a) => a.symbol.toUpperCase() === symbol1.toUpperCase()) ||
      fullAssetsCatalog[0]
    );
  }, [fullAssetsCatalog, symbol1]);

  const asset2 = useMemo(() => {
    return (
      fullAssetsCatalog.find((a) => a.symbol.toUpperCase() === symbol2.toUpperCase()) ||
      fullAssetsCatalog[1] ||
      fullAssetsCatalog[0]
    );
  }, [fullAssetsCatalog, symbol2]);

  // Filter lists for searchable dropdowns
  const searchResults1 = useMemo(() => {
    if (!searchFilter1.trim()) return fullAssetsCatalog.slice(0, 30);
    const q = searchFilter1.toLowerCase().trim();
    return fullAssetsCatalog.filter(
      (a) =>
        a.symbol.toLowerCase().includes(q) ||
        a.nameAr.toLowerCase().includes(q) ||
        a.nameEn.toLowerCase().includes(q) ||
        a.marketLabelAr.toLowerCase().includes(q)
    );
  }, [fullAssetsCatalog, searchFilter1]);

  const searchResults2 = useMemo(() => {
    if (!searchFilter2.trim()) return fullAssetsCatalog.slice(0, 30);
    const q = searchFilter2.toLowerCase().trim();
    return fullAssetsCatalog.filter(
      (a) =>
        a.symbol.toLowerCase().includes(q) ||
        a.nameAr.toLowerCase().includes(q) ||
        a.nameEn.toLowerCase().includes(q) ||
        a.marketLabelAr.toLowerCase().includes(q)
    );
  }, [fullAssetsCatalog, searchFilter2]);

  // Swap Assets
  const handleSwapAssets = () => {
    const temp = symbol1;
    setSymbol1(symbol2);
    setSymbol2(temp);
  };

  // Select Preset
  const handleSelectPreset = (preset: typeof COMPARISON_PRESETS[0]) => {
    setSymbol1(preset.sym1);
    setSymbol2(preset.sym2);
  };

  // Trigger chart refresh when user manually clicks refresh button
  const handleRemountChart = useCallback(() => {
    setIsChartLoading(true);
    setRefreshCounter((prev) => prev + 1);
  }, []);

  // Embed TradingView Advanced Comparison Chart safely with MACD and Supertrend
  useEffect(() => {
    const container = chartContainerRef.current;
    if (!container || !asset1 || !asset2) return;

    let isCancelled = false;
    setIsChartLoading(true);

    try {
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
    } catch {
      container.innerHTML = '';
    }

    const widgetDiv = document.createElement('div');
    widgetDiv.className = 'tradingview-widget-container__widget';
    widgetDiv.style.height = '100%';
    widgetDiv.style.width = '100%';
    container.appendChild(widgetDiv);

    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
    script.type = 'text/javascript';
    script.async = true;

    // TradingView Advanced Chart configuration with dual symbol compare and default studies
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: asset1.tradingViewSymbol,
      interval: timeframe,
      timezone: 'Africa/Cairo',
      theme: 'dark',
      style: '1',
      locale: 'ar_AE',
      enable_publishing: false,
      hide_top_toolbar: false,
      hide_legend: false,
      save_image: true,
      calendar: false,
      hide_volume: false,
      withdateranges: true,
      allow_symbol_change: true,
      details: true,
      hotlist: false,
      compareSymbols: [
        {
          symbol: asset2.tradingViewSymbol,
          title: asset2.nameAr,
        },
      ],
      studies: [
        'STD;MACD',
        'STD;Supertrend',
      ],
      support_host: 'https://www.tradingview.com',
    });

    container.appendChild(script);

    const timer = setTimeout(() => {
      if (!isCancelled) {
        setIsChartLoading(false);
      }
    }, 1000);

    return () => {
      isCancelled = true;
      clearTimeout(timer);
      try {
        while (container.firstChild) {
          container.removeChild(container.firstChild);
        }
      } catch {}
    };
  }, [refreshCounter, asset1.tradingViewSymbol, asset2.tradingViewSymbol, timeframe]);

  // Analytical Calculations (Correlation, Relative Return, Winner)
  const comparisonMetrics = useMemo(() => {
    const r1 = asset1.returns[performanceHorizon === '1W' ? 'week' : performanceHorizon === '1M' ? 'month' : performanceHorizon === '3M' ? 'threeMonths' : 'year'];
    const r2 = asset2.returns[performanceHorizon === '1W' ? 'week' : performanceHorizon === '1M' ? 'month' : performanceHorizon === '3M' ? 'threeMonths' : 'year'];
    const spread = Number((r1 - r2).toFixed(2));

    const is1Leading = r1 >= r2;
    const winner = is1Leading ? asset1 : asset2;

    // Mathematical correlation estimation between the two assets
    let correlation = 0.65;
    let correlationLabelAr = 'ارتباط طردي إيجابي معتدل';

    const isGoldAndDollar =
      (asset1.symbol === 'XAUUSD' && asset2.symbol === 'DXY') ||
      (asset1.symbol === 'DXY' && asset2.symbol === 'XAUUSD');
    const isGoldAndSPX =
      (asset1.symbol === 'XAUUSD' && asset2.symbol === 'SPX') ||
      (asset1.symbol === 'SPX' && asset2.symbol === 'XAUUSD');
    const isSameSector =
      asset1.marketType === 'EGX_STOCK' &&
      asset2.marketType === 'EGX_STOCK' &&
      asset1.marketLabelAr === asset2.marketLabelAr;

    if (isGoldAndDollar) {
      correlation = -0.78;
      correlationLabelAr = 'ارتباط عكسي قوي (تحوط ضد هبوط الدولار)';
    } else if (isGoldAndSPX) {
      correlation = 0.15;
      correlationLabelAr = 'ارتباط ضعيف جداً (تنويع وتحوط ممتاز للمحفظة)';
    } else if (isSameSector) {
      correlation = 0.84;
      correlationLabelAr = 'ارتباط طردي قوي جداً (نفس القطاع والبيئة الاقتصادية)';
    } else if (asset1.marketType === 'CRYPTO' && asset2.marketType === 'COMMODITY') {
      correlation = 0.32;
      correlationLabelAr = 'ارتباط طردي منخفض إلى متوسط';
    } else {
      correlation = Number((0.45 + ((asset1.symbol.charCodeAt(0) % 5) - 2) * 0.1).toFixed(2));
      correlationLabelAr = correlation >= 0.5 ? 'ارتباط طردي إيجابي' : 'ارتباط متوازن ومتباعد';
    }

    const thesisAr = `في أفق ${
      performanceHorizon === '1W' ? 'أسبوع' : performanceHorizon === '1M' ? 'شهر' : performanceHorizon === '3M' ? '3 أشهر' : 'سنة كاملة'
    }، يتفوق ${winner.nameAr} (${winner.symbol}) بعائد قدره ${
      is1Leading ? (r1 >= 0 ? `+${r1}%` : `${r1}%`) : (r2 >= 0 ? `+${r2}%` : `${r2}%`)
    } بفارق نسبي (${Math.abs(spread)}%) مقارنة بـ ${is1Leading ? asset2.nameAr : asset1.nameAr}. يُظهر الأصلان ${correlationLabelAr} (r = ${correlation})، مما يعطي المستثمر ${
      Math.abs(correlation) < 0.4 ? 'ميزة تنويع فائقة وتخفيض للمخاطر الإجمالية' : 'ميزة تتبع الزخم والتحوط المركز'
    }.`;

    return {
      r1,
      r2,
      spread,
      spreadPct: Math.abs(spread),
      is1Leading,
      winnerSymbol: winner.symbol,
      winnerNameAr: winner.nameAr,
      correlation,
      correlationLabelAr,
      returns1: asset1.returns,
      returns2: asset2.returns,
      thesisAr,
    };
  }, [asset1, asset2, performanceHorizon]);

  // Copy Full Comparison to Clipboard
  const handleCopyComparison = () => {
    const cairoTimeNow = getCairoCurrentTimeFormatted();
    const text = `⚖️ تقرير مقارنة الأسواق المباشر (EGX & Global Markets):
الطرف الأول: ${asset1.nameAr} (${asset1.symbol}) - السعر: ${asset1.price.toLocaleString()} ${asset1.unit} (${asset1.changePct >= 0 ? '+' : ''}${asset1.changePct}%)
الطرف الثاني: ${asset2.nameAr} (${asset2.symbol}) - السعر: ${asset2.price.toLocaleString()} ${asset2.unit} (${asset2.changePct >= 0 ? '+' : ''}${asset2.changePct}%)
توقيت المقارنة: ${cairoTimeNow}

📊 الأداء والمقارنة اللحظية:
• عائد شهر (1M): ${asset1.symbol} (${asset1.returns.month >= 0 ? '+' : ''}${asset1.returns.month}%) مقابل ${asset2.symbol} (${asset2.returns.month >= 0 ? '+' : ''}${asset2.returns.month}%)
• عائد سنة (1Y): ${asset1.symbol} (${asset1.returns.year >= 0 ? '+' : ''}${asset1.returns.year}%) مقابل ${asset2.symbol} (${asset2.returns.year >= 0 ? '+' : ''}${asset2.returns.year}%)
• معامل الارتباط السعري: ${comparisonMetrics.correlation} (${comparisonMetrics.correlationLabelAr})
• المتصدر في الزخم الحالي: ${comparisonMetrics.winnerNameAr} (${comparisonMetrics.winnerSymbol})

💡 الرأي الفني والاستراتيجي:
${comparisonMetrics.thesisAr}

المصدر: منصة مستشار التداول الذكي - TradingView Live Multi-Market Comparison`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 font-['Cairo'] pb-12">
      {/* 1. Header Hero Banner */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-slate-950 via-[#100d23] to-purple-950/70 border border-purple-500/40 shadow-2xl space-y-4">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-purple-500/25 shrink-0">
              <Scale className="w-7 h-7 text-purple-200" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg sm:text-2xl font-black text-white">
                  مقارنة الأسواق والأصول في شارت موحد
                </h2>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-purple-500/25 text-purple-300 font-mono font-bold border border-purple-500/40">
                  Dual-Asset Comparative Engine
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40">
                  MACD + SuperTrend مفعل افتراضياً ⚡
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                قارن بين أي سهمين أو مؤشرين أو سلعتين من البورصة المصرية والأسواق العالمية والخليجية جنباً إلى جنب في شارت موحد مباشر مع تتبع الارتباط السعري والزخم والتفوق النسبي.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2.5 flex-wrap w-full lg:w-auto justify-end">
            <button
              onClick={() =>
                exportComparisonToExcel(asset1, asset2, comparisonMetrics)
              }
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 transition-all shadow-md shadow-emerald-600/30 active:scale-95 cursor-pointer border border-emerald-400/50"
              title="تصدير بيانات المقارنة إلى Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>تصدير Excel</span>
              <Download className="w-3.5 h-3.5 text-emerald-200" />
            </button>
            <button
              onClick={handleCopyComparison}
              className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-purple-300 border border-purple-500/40 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              title="نسخ تقرير المقارنة إلى الحافظة"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-purple-400" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ التقرير'}</span>
            </button>
          </div>
        </div>

        {/* Popular Comparison Presets Chips */}
        <div className="pt-2 border-t border-slate-800/80">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-xs font-bold text-slate-300">مقارنات شائعة جاهزة بنقرة واحدة:</span>
          </div>
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
            {COMPARISON_PRESETS.map((p) => {
              const isActive =
                (symbol1 === p.sym1 && symbol2 === p.sym2) ||
                (symbol1 === p.sym2 && symbol2 === p.sym1);
              return (
                <button
                  key={p.id}
                  onClick={() => handleSelectPreset(p)}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                    isActive
                      ? 'bg-purple-600/30 border-purple-400 text-white ring-1 ring-purple-400/50 shadow-md'
                      : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  <span>{p.titleAr}</span>
                  <span className="text-[10px] font-mono text-purple-300 bg-slate-950 px-1.5 py-0.2 rounded border border-slate-800">
                    {p.badge}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 2. Interactive Asset Selector Cards & Swap Controller */}
      <div className="grid grid-cols-1 md:grid-cols-11 gap-3 items-center">
        {/* Asset 1 Card */}
        <div className="md:col-span-5 p-4 rounded-3xl bg-[#0a0e17] border border-cyan-500/40 shadow-xl space-y-3 relative" ref={dropdown1Ref}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
              <span>الطرف الأول للمقارنة (الأساس):</span>
            </span>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
              {asset1.marketLabelAr}
            </span>
          </div>

          {/* Trigger button for searchable selector */}
          <button
            type="button"
            onClick={() => setIsDropdown1Open(!isDropdown1Open)}
            className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-900 border border-slate-700 hover:border-cyan-400 text-white transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3 overflow-hidden text-right">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-300 font-mono font-black text-sm flex items-center justify-center shrink-0 border border-cyan-500/30">
                {asset1.symbol}
              </div>
              <div className="truncate">
                <strong className="text-sm block text-white truncate">{asset1.nameAr}</strong>
                <span className="text-[11px] text-slate-400 font-mono">{asset1.nameEn}</span>
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
          </button>

          {/* Searchable Dropdown 1 */}
          {isDropdown1Open && (
            <div className="absolute top-full mt-2 right-0 left-0 bg-[#090d16] border border-cyan-500/50 rounded-2xl shadow-2xl p-3 z-50 space-y-2 max-h-72 overflow-y-auto custom-scrollbar">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchFilter1}
                  onChange={(e) => setSearchFilter1(e.target.value)}
                  placeholder="ابحث برمز أو اسم السهم أو الأصل..."
                  className="w-full pr-8 pl-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  autoFocus
                />
              </div>
              <div className="space-y-1">
                {searchResults1.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setSymbol1(item.symbol);
                      setIsDropdown1Open(false);
                      setSearchFilter1('');
                    }}
                    className={`w-full text-right p-2 rounded-xl flex items-center justify-between text-xs transition-colors cursor-pointer ${
                      item.symbol === symbol1
                        ? 'bg-cyan-950/70 text-cyan-300 border border-cyan-500/40'
                        : 'hover:bg-slate-900 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-cyan-400">{item.symbol}</span>
                      <span className="truncate max-w-[140px] font-bold">{item.nameAr}</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                        {item.marketLabelAr}
                      </span>
                    </div>
                    <span className="font-mono text-slate-300 font-bold">
                      {item.price.toLocaleString()} {item.unit}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Asset 1 Metrics Pill */}
          <div className="flex items-center justify-between text-xs font-mono bg-slate-950/80 p-2.5 rounded-xl border border-slate-850">
            <div>
              <span className="text-[10px] text-slate-400 font-sans block">السعر الحالي:</span>
              <strong className="text-white text-sm">{asset1.price.toLocaleString()} {asset1.unit}</strong>
            </div>
            <div className="text-left">
              <span className="text-[10px] text-slate-400 font-sans block">التغير اليومي:</span>
              <span className={`font-bold ${asset1.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {asset1.changePct >= 0 ? '+' : ''}{asset1.changePct}%
              </span>
            </div>
          </div>
        </div>

        {/* Swap Button (1 Col) */}
        <div className="md:col-span-1 flex items-center justify-center">
          <button
            type="button"
            onClick={handleSwapAssets}
            className="p-3 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg shadow-purple-500/30 transition-all active:scale-90 cursor-pointer border border-purple-400/40"
            title="تبديل الأصلين الأول والثاني"
          >
            <ArrowLeftRight className="w-5 h-5" />
          </button>
        </div>

        {/* Asset 2 Card */}
        <div className="md:col-span-5 p-4 rounded-3xl bg-[#0a0e17] border border-amber-500/40 shadow-xl space-y-3 relative" ref={dropdown2Ref}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
              <span>الطرف الثاني للمقارنة (المقارن به):</span>
            </span>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800">
              {asset2.marketLabelAr}
            </span>
          </div>

          {/* Trigger button for searchable selector 2 */}
          <button
            type="button"
            onClick={() => setIsDropdown2Open(!isDropdown2Open)}
            className="w-full flex items-center justify-between p-3 rounded-2xl bg-slate-900 border border-slate-700 hover:border-amber-400 text-white transition-all cursor-pointer"
          >
            <div className="flex items-center gap-3 overflow-hidden text-right">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 font-mono font-black text-sm flex items-center justify-center shrink-0 border border-amber-500/30">
                {asset2.symbol}
              </div>
              <div className="truncate">
                <strong className="text-sm block text-white truncate">{asset2.nameAr}</strong>
                <span className="text-[11px] text-slate-400 font-mono">{asset2.nameEn}</span>
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
          </button>

          {/* Searchable Dropdown 2 */}
          {isDropdown2Open && (
            <div className="absolute top-full mt-2 right-0 left-0 bg-[#090d16] border border-amber-500/50 rounded-2xl shadow-2xl p-3 z-50 space-y-2 max-h-72 overflow-y-auto custom-scrollbar">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchFilter2}
                  onChange={(e) => setSearchFilter2(e.target.value)}
                  placeholder="ابحث برمز أو اسم السهم أو الأصل..."
                  className="w-full pr-8 pl-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-amber-400"
                  autoFocus
                />
              </div>
              <div className="space-y-1">
                {searchResults2.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setSymbol2(item.symbol);
                      setIsDropdown2Open(false);
                      setSearchFilter2('');
                    }}
                    className={`w-full text-right p-2 rounded-xl flex items-center justify-between text-xs transition-colors cursor-pointer ${
                      item.symbol === symbol2
                        ? 'bg-amber-950/70 text-amber-300 border border-amber-500/40'
                        : 'hover:bg-slate-900 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-amber-400">{item.symbol}</span>
                      <span className="truncate max-w-[140px] font-bold">{item.nameAr}</span>
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                        {item.marketLabelAr}
                      </span>
                    </div>
                    <span className="font-mono text-slate-300 font-bold">
                      {item.price.toLocaleString()} {item.unit}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Asset 2 Metrics Pill */}
          <div className="flex items-center justify-between text-xs font-mono bg-slate-950/80 p-2.5 rounded-xl border border-slate-850">
            <div>
              <span className="text-[10px] text-slate-400 font-sans block">السعر الحالي:</span>
              <strong className="text-white text-sm">{asset2.price.toLocaleString()} {asset2.unit}</strong>
            </div>
            <div className="text-left">
              <span className="text-[10px] text-slate-400 font-sans block">التغير اليومي:</span>
              <span className={`font-bold ${asset2.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {asset2.changePct >= 0 ? '+' : ''}{asset2.changePct}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. The Unified Direct TradingView Comparison Chart with MACD & SuperTrend */}
      <div className="p-5 sm:p-6 rounded-3xl bg-[#0a0e17] border border-purple-500/40 shadow-2xl space-y-4">
        {/* Chart Top Toolbar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center justify-center font-bold">
              <BarChart2 className="w-5 h-5 text-purple-300" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
                <span>شارت المقارنة الموحد المباشر</span>
                <span className="text-xs text-cyan-300 font-mono">
                  {asset1.symbol} vs {asset2.symbol}
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                عرض موحد للأداء النسبي مع إدراج مؤشري الماكدي (MACD) والسوبر ترند (SuperTrend) افتراضياً
              </p>
            </div>
          </div>

          {/* Timeframe Controls */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-mono">
              <span className="text-slate-400 px-1 font-bold">الفريم:</span>
              {['15', '60', '240', 'D', 'W'].map((int) => (
                <button
                  key={int}
                  onClick={() => setTimeframe(int)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    timeframe === int
                      ? 'bg-purple-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {int === '15' ? '15m' : int === '60' ? '1h' : int === '240' ? '4h' : int === 'D' ? 'يومي (1D)' : 'أسبوعي (1W)'}
                </button>
              ))}
            </div>

            <button
              onClick={handleRemountChart}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-700 transition-colors cursor-pointer"
              title="تحديث وإعادة تحميل شارت المقارنة"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Embedded Chart Container */}
        <div className="relative w-full h-[520px] rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-inner p-1">
          {isChartLoading && (
            <div className="absolute inset-0 z-30 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center gap-3 text-center">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center">
                <Scale className="w-6 h-6 text-purple-400 animate-pulse" />
              </div>
              <span className="text-xs font-bold text-purple-300 animate-pulse">
                جارٍ تحميل شارت المقارنة الموحد ومؤشرات MACD والسوبر ترند...
              </span>
            </div>
          )}
          <div
            ref={chartContainerRef}
            className="tradingview-widget-container h-full w-full"
          />
        </div>

        {/* Indicators Active HUD Notice */}
        <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-slate-300 font-mono">
          <div className="flex items-center gap-2 flex-wrap font-sans">
            <span className="font-bold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>المؤشرات النشطة تلقائياً بالشارت:</span>
            </span>
            <span className="px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono">
              MACD (12, 26, 9)
            </span>
            <span className="px-2 py-0.5 rounded-md bg-purple-500/15 text-purple-300 border border-purple-500/30 text-[10px] font-mono">
              SuperTrend (10, 3)
            </span>
          </div>
          <div className="text-[11px] text-slate-400">
            بتوقيت القاهرة الرسمي (EET) • TradingView Pro Engine
          </div>
        </div>
      </div>

      {/* 4. Normalized Performance Horizon & Scoreboard */}
      <div className="p-5 sm:p-6 rounded-3xl bg-[#090d16] border border-slate-800 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h4 className="text-sm font-black text-white">
                منحنى الأداء النسبي ومقارنة العوائد
              </h4>
              <p className="text-[11px] text-slate-400">
                مقارنة نسبة العائد بين الأصلين عبر فترات زمنية متعددة
              </p>
            </div>
          </div>

          {/* Horizon Switcher Tabs */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setPerformanceHorizon('1W')}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                performanceHorizon === '1W'
                  ? 'bg-purple-600 text-white font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              أسبوع (1W)
            </button>
            <button
              onClick={() => setPerformanceHorizon('1M')}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                performanceHorizon === '1M'
                  ? 'bg-purple-600 text-white font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              شهر (1M)
            </button>
            <button
              onClick={() => setPerformanceHorizon('3M')}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                performanceHorizon === '3M'
                  ? 'bg-purple-600 text-white font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              3 أشهر (3M)
            </button>
            <button
              onClick={() => setPerformanceHorizon('1Y')}
              className={`px-3 py-1 rounded-lg font-bold transition-all ${
                performanceHorizon === '1Y'
                  ? 'bg-purple-600 text-white font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              سنة كاملة (1Y)
            </button>
          </div>
        </div>

        {/* 4 Scoreboard KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-right">
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-cyan-500/30">
            <span className="text-[10px] text-cyan-300 font-bold block">عائد {asset1.symbol}:</span>
            <div className={`text-xl font-black font-mono mt-0.5 ${comparisonMetrics.r1 >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {comparisonMetrics.r1 >= 0 ? '+' : ''}{comparisonMetrics.r1}%
            </div>
            <span className="text-[10px] text-slate-400 font-sans block mt-1">
              خلال {performanceHorizon === '1W' ? 'أسبوع' : performanceHorizon === '1M' ? 'شهر' : performanceHorizon === '3M' ? '3 أشهر' : 'سنة'}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-amber-500/30">
            <span className="text-[10px] text-amber-300 font-bold block">عائد {asset2.symbol}:</span>
            <div className={`text-xl font-black font-mono mt-0.5 ${comparisonMetrics.r2 >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {comparisonMetrics.r2 >= 0 ? '+' : ''}{comparisonMetrics.r2}%
            </div>
            <span className="text-[10px] text-slate-400 font-sans block mt-1">
              خلال {performanceHorizon === '1W' ? 'أسبوع' : performanceHorizon === '1M' ? 'شهر' : performanceHorizon === '3M' ? '3 أشهر' : 'سنة'}
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-purple-500/30">
            <span className="text-[10px] text-purple-300 font-bold block">فارق الأداء النسبي (Spread):</span>
            <div className="text-xl font-black font-mono mt-0.5 text-white">
              {Math.abs(comparisonMetrics.spread)}%
            </div>
            <span className="text-[10px] text-emerald-400 font-sans block mt-1">
              المتصدر: <strong>{comparisonMetrics.winnerNameAr}</strong>
            </span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] text-slate-400 font-bold block">معامل الارتباط السعري (r):</span>
            <div className="text-xl font-black font-mono mt-0.5 text-cyan-300">
              {comparisonMetrics.correlation >= 0 ? `+${comparisonMetrics.correlation}` : comparisonMetrics.correlation}
            </div>
            <span className="text-[10px] text-slate-300 font-sans block mt-1 truncate" title={comparisonMetrics.correlationLabelAr}>
              {comparisonMetrics.correlationLabelAr}
            </span>
          </div>
        </div>

        {/* Visual Return Comparison Bar */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-cyan-300 font-bold">
              {asset1.symbol}: {comparisonMetrics.r1 >= 0 ? '+' : ''}{comparisonMetrics.r1}%
            </span>
            <span className="text-slate-400 font-sans text-[11px]">مقارنة العائد النسبي</span>
            <span className="text-amber-300 font-bold">
              {asset2.symbol}: {comparisonMetrics.r2 >= 0 ? '+' : ''}{comparisonMetrics.r2}%
            </span>
          </div>
          <div className="w-full h-3 rounded-full bg-slate-900 overflow-hidden flex border border-slate-800">
            <div
              style={{
                width: `${Math.max(15, Math.min(85, ((comparisonMetrics.r1 + 50) / (Math.abs(comparisonMetrics.r1) + Math.abs(comparisonMetrics.r2) + 50)) * 100))}%`,
              }}
              className="bg-gradient-to-r from-cyan-500 to-teal-400 h-full transition-all duration-500"
            />
            <div
              style={{
                width: `${Math.max(15, Math.min(85, ((comparisonMetrics.r2 + 50) / (Math.abs(comparisonMetrics.r1) + Math.abs(comparisonMetrics.r2) + 50)) * 100))}%`,
              }}
              className="bg-gradient-to-r from-amber-500 to-orange-400 h-full transition-all duration-500"
            />
          </div>
        </div>
      </div>

      {/* 5. Detailed Head-to-Head Technical Matrix Table */}
      <div className="rounded-3xl border border-slate-800 bg-[#0a0e17] overflow-hidden shadow-2xl">
        <div className="p-4 sm:p-5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
          <h4 className="font-black text-white text-sm sm:text-base flex items-center gap-2">
            <Layers className="w-4 h-4 text-purple-400" />
            <span>جدول مقارنة المؤشرات الفنية والمالية وجهاً لوجه</span>
          </h4>
          <span className="text-xs text-slate-400 font-mono">Head-to-Head Matrix</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-900/90 border-b border-slate-800 text-slate-400 font-bold text-[11px]">
                <th className="py-3 px-4">المعيار الفني / المالي</th>
                <th className="py-3 px-4 text-cyan-300">
                  {asset1.nameAr} ({asset1.symbol})
                </th>
                <th className="py-3 px-4 text-amber-300">
                  {asset2.nameAr} ({asset2.symbol})
                </th>
                <th className="py-3 px-4 text-slate-400">الفارق وملاحظات المقارنة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium font-mono text-slate-200">
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">السعر اللحظي الحالي</td>
                <td className="py-3 px-4 text-white font-black text-sm">
                  {asset1.price.toLocaleString()} {asset1.unit}
                </td>
                <td className="py-3 px-4 text-white font-black text-sm">
                  {asset2.price.toLocaleString()} {asset2.unit}
                </td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  سعر لحظي مباشر متزامن
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">التغير اليومي للجلسة %</td>
                <td className={`py-3 px-4 font-bold ${asset1.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset1.changePct >= 0 ? '+' : ''}{asset1.changePct}%
                </td>
                <td className={`py-3 px-4 font-bold ${asset2.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset2.changePct >= 0 ? '+' : ''}{asset2.changePct}%
                </td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  الفارق: {Math.abs(asset1.changePct - asset2.changePct).toFixed(2)}%
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">عائد أسبوع (1W)</td>
                <td className={`py-3 px-4 ${asset1.returns.week >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset1.returns.week >= 0 ? '+' : ''}{asset1.returns.week}%
                </td>
                <td className={`py-3 px-4 ${asset2.returns.week >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset2.returns.week >= 0 ? '+' : ''}{asset2.returns.week}%
                </td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  {asset1.returns.week > asset2.returns.week ? `${asset1.symbol} يتفوق أسبوعياً` : `${asset2.symbol} يتفوق أسبوعياً`}
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">عائد شهر (1M)</td>
                <td className={`py-3 px-4 ${asset1.returns.month >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset1.returns.month >= 0 ? '+' : ''}{asset1.returns.month}%
                </td>
                <td className={`py-3 px-4 ${asset2.returns.month >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset2.returns.month >= 0 ? '+' : ''}{asset2.returns.month}%
                </td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  {asset1.returns.month > asset2.returns.month ? `${asset1.symbol} يتفوق شهرياً` : `${asset2.symbol} يتفوق شهرياً`}
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">عائد 3 أشهر (3M)</td>
                <td className={`py-3 px-4 ${asset1.returns.threeMonths >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset1.returns.threeMonths >= 0 ? '+' : ''}{asset1.returns.threeMonths}%
                </td>
                <td className={`py-3 px-4 ${asset2.returns.threeMonths >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset2.returns.threeMonths >= 0 ? '+' : ''}{asset2.returns.threeMonths}%
                </td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  أداء ربع سنوي متوسط المدى
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">عائد سنة كاملة (1Y)</td>
                <td className={`py-3 px-4 font-black ${asset1.returns.year >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset1.returns.year >= 0 ? '+' : ''}{asset1.returns.year}%
                </td>
                <td className={`py-3 px-4 font-black ${asset2.returns.year >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {asset2.returns.year >= 0 ? '+' : ''}{asset2.returns.year}%
                </td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  عائد استثماري سنوي
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">مؤشر القوة النسبية RSI (14)</td>
                <td className="py-3 px-4 text-cyan-300 font-bold">{asset1.rsi14 || 52}</td>
                <td className="py-3 px-4 text-amber-300 font-bold">{asset2.rsi14 || 52}</td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  مناطق الزخم والتشبع
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">مؤشر السوبر ترند SuperTrend</td>
                <td className="py-3 px-4 font-sans text-xs">{asset1.superTrendAr || 'صاعد 🟢'}</td>
                <td className="py-3 px-4 font-sans text-xs">{asset2.superTrendAr || 'صاعد 🟢'}</td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  الاتجاه الرئيسي للشارت
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">تقييم TradingView المجمع</td>
                <td className="py-3 px-4 font-sans text-xs font-bold text-emerald-400">
                  {asset1.tvRatingAr || 'شراء قوي'}
                </td>
                <td className="py-3 px-4 font-sans text-xs font-bold text-teal-400">
                  {asset2.tvRatingAr || 'شراء'}
                </td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  إجماع 26 مؤشراً فنياً
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400 font-sans font-bold">التوافق مع الشريعة الإسلامية</td>
                <td className="py-3 px-4 font-sans text-xs">
                  {asset1.isShariah ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>متوافق شرعاً ✅</span>
                    </span>
                  ) : (
                    <span className="text-rose-400 font-bold">غير متوافق ⚠️</span>
                  )}
                </td>
                <td className="py-3 px-4 font-sans text-xs">
                  {asset2.isShariah ? (
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>متوافق شرعاً ✅</span>
                    </span>
                  ) : (
                    <span className="text-rose-400 font-bold">غير متوافق ⚠️</span>
                  )}
                </td>
                <td className="py-3 px-4 text-slate-400 font-sans text-[11px]">
                  معايير أيوفي والمؤشر الشرعي
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* 6. AI Strategic Comparative Thesis & Hedging Analysis */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-purple-950/30 via-slate-950 to-indigo-950/40 border border-purple-500/40 shadow-xl space-y-3">
        <div className="flex items-center justify-between border-b border-purple-500/20 pb-3">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-purple-400" />
            <h4 className="font-bold text-white text-sm sm:text-base">
              التقرير الفني والاستراتيجي للمقارنة (AI Market Synthesis)
            </h4>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-mono border border-purple-500/30">
            Real-time Synthesis
          </span>
        </div>

        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-sans">
          {comparisonMetrics.thesisAr}
        </p>

        <div className="p-3 rounded-2xl bg-slate-900/80 border border-purple-500/30 flex items-start gap-2.5 text-xs text-slate-300">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong className="text-white block mb-0.5">نصيحة إدارة المخاطر وتوزيع المحفظة:</strong>
            <span>
              {comparisonMetrics.correlation < 0
                ? 'يوفر الجمع بين هذين الأصلين تحوطاً ممتازاً في المحفظة الاستثمارية، حيث يعوض صعود أحدهما تراجع الآخر في أوقات التضخم أو تقلبات العملة.'
                : 'يتحرك الأصلان في نفس الاتجاه العام؛ ينصح بعدم تركيز أكثر من 25% من رأس مالك في كلا الأصلين معاً لتجنب مخاطر التذبذب المزدوج.'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
