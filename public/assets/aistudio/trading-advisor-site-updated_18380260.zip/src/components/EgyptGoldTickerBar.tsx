import React, { useState, useEffect } from 'react';
import {
  Coins,
  TrendingUp,
  ShieldCheck,
  X,
  RefreshCw,
  Sparkles,
  Scale,
  Award,
  Clock,
  ArrowUpRight,
  Calculator,
  ChevronDown,
  ChevronUp,
  Flame,
  CheckCircle2,
  DollarSign,
  Gem,
} from 'lucide-react';
import {
  getLiveEgyptGoldSnapshot,
  fetchLiveEgyptGoldSnapshot,
  EgyptGoldMarketSnapshot,
} from '../services/goldPriceService';

interface EgyptGoldTickerBarProps {
  className?: string;
  onClose?: () => void;
}

export const EgyptGoldTickerBar: React.FC<EgyptGoldTickerBarProps> = ({ className = '', onClose }) => {
  const [snapshot, setSnapshot] = useState<EgyptGoldMarketSnapshot>(() => getLiveEgyptGoldSnapshot());
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeModalTab, setActiveModalTab] = useState<'CALIBERS' | 'POUND' | 'BARS' | 'HEDGING'>('CALIBERS');
  
  // View mode: 'CARDS' (Expanded Luxury Cards) or 'RIBBON' (Compact Elegant Strip)
  const [viewMode, setViewMode] = useState<'CARDS' | 'RIBBON'>(() => {
    return (localStorage.getItem('egx_gold_view_mode') as 'CARDS' | 'RIBBON') || 'CARDS';
  });

  // Built-in Quick Calculator State
  const [showCalculator, setShowCalculator] = useState(false);
  const [calcCaliber, setCalcCaliber] = useState<'24' | '21' | '18' | 'POUND'>('21');
  const [calcGrams, setCalcGrams] = useState<number>(10);

  const toggleViewMode = () => {
    setViewMode((prev) => {
      const next = prev === 'CARDS' ? 'RIBBON' : 'CARDS';
      localStorage.setItem('egx_gold_view_mode', next);
      return next;
    });
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      const data = await fetchLiveEgyptGoldSnapshot();
      setSnapshot(data);
    } catch (_err) {
      // keep existing
    } finally {
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  // Auto-refresh gold rates periodically every 45 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      handleRefresh();
    }, 45000);
    return () => clearInterval(timer);
  }, []);

  // Calculator price computation
  const calcPricePerUnit = () => {
    switch (calcCaliber) {
      case '24':
        return { sell: snapshot.gold24k.sellPriceEgp, buy: snapshot.gold24k.buyPriceEgp, label: 'جرام عيار 24' };
      case '21':
        return { sell: snapshot.gold21k.sellPriceEgp, buy: snapshot.gold21k.buyPriceEgp, label: 'جرام عيار 21' };
      case '18':
        return { sell: snapshot.gold18k.sellPriceEgp, buy: snapshot.gold18k.buyPriceEgp, label: 'جرام عيار 18' };
      case 'POUND':
        return { sell: snapshot.goldPound.sellPriceEgp, buy: snapshot.goldPound.buyPriceEgp, label: 'جنيه ذهب (8ج 21)' };
    }
  };

  const currentRate = calcPricePerUnit();
  const totalSellValue = currentRate.sell * (calcGrams || 0);
  const totalBuyValue = currentRate.buy * (calcGrams || 0);

  return (
    <div
      dir="rtl"
      className={`rounded-3xl border border-amber-500/40 bg-gradient-to-b from-[#181205] via-[#0d1017] to-[#120d04] shadow-2xl shadow-amber-950/40 text-xs font-['Cairo'] relative overflow-hidden backdrop-blur-xl ${className}`}
    >
      {/* Golden Metallic Glow Trim */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-amber-400 to-transparent opacity-80" />

      {/* Top Header Row */}
      <div className="px-4 py-2.5 sm:px-5 border-b border-amber-500/20 flex items-center justify-between gap-3 flex-wrap bg-gradient-to-r from-amber-950/40 via-slate-900/60 to-amber-950/40">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 p-0.5 shadow-md shadow-amber-500/25 shrink-0 flex items-center justify-center">
            <Coins className="w-4 h-4 text-slate-950 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-black text-amber-100 tracking-tight flex items-center gap-1.5">
                <span>بورصة الذهب بالصاغة المصرية</span>
                <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-sans">
                  مباشر ⚡
                </span>
              </h2>
            </div>
            <p className="text-[10px] text-amber-200/70 font-medium flex items-center gap-1.5">
              <span>تحديث الصاغة المصرية الرسمي</span>
              <span>•</span>
              <span className="font-mono text-emerald-400 font-bold">{snapshot.cairoTimestamp}</span>
              <span className="hidden sm:inline">•</span>
              <span className="hidden sm:inline text-slate-400">{snapshot.summaryAr}</span>
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Quick Calculator Toggle */}
          <button
            type="button"
            onClick={() => setShowCalculator(!showCalculator)}
            className={`px-2.5 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border ${
              showCalculator
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-sm shadow-amber-500/30'
                : 'bg-slate-900/90 text-amber-300 border-amber-500/30 hover:border-amber-400'
            }`}
            title="فتح حاسبة قيمة الذهب الفورية"
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>حاسبة الذهب</span>
          </button>

          {/* Detailed BTC Bullion & Hedge Modal Trigger */}
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-amber-500/20 to-yellow-500/15 hover:from-amber-500/30 hover:to-yellow-500/25 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
            title="استعراض أوزان سبائك BTC والجنيه الذهب وفروق المصنعية"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">سبائك BTC والتحوط</span>
          </button>

          {/* Toggle View Mode: Cards vs Ribbon */}
          <button
            type="button"
            onClick={toggleViewMode}
            className="px-2.5 py-1 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
            title={viewMode === 'CARDS' ? 'التبديل للشريط السريع المدمج' : 'التبديل لعرض البطاقات الفاخرة'}
          >
            {viewMode === 'CARDS' ? (
              <>
                <ChevronUp className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline">عرض مدمج</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden md:inline">عرض البطاقات ⭐</span>
              </>
            )}
          </button>

          {/* Refresh Button */}
          <button
            type="button"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="p-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 transition-colors cursor-pointer"
            title="تحديث أسعار الذهب الآن"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>

          {/* Close Bar */}
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-900/90 hover:bg-rose-950/60 text-slate-400 hover:text-rose-400 border border-slate-700/80 hover:border-rose-800 transition-colors cursor-pointer"
              title="إخفاء لوحة الذهب"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* View Mode 1: Executive Luxury Cards (Default Stunning View) */}
      {viewMode === 'CARDS' && (
        <div className="p-3 sm:p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Card 1: عيار 21 (التاج والأساس الأكثر تداولاً) */}
          <div className="relative rounded-2xl p-3.5 bg-gradient-to-b from-amber-500/15 via-amber-950/30 to-slate-950/80 border border-amber-400/50 shadow-lg shadow-amber-950/50 flex flex-col justify-between group hover:border-amber-300 transition-all hover:scale-[1.01]">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-amber-500/25">
              <div className="flex items-center gap-1.5">
                <span className="text-base">👑</span>
                <span className="text-xs font-black text-amber-200">عيار 21 (الأكثر طلباً)</span>
              </div>
              <span className="text-[10px] font-mono font-bold text-emerald-400 flex items-center gap-0.5 bg-emerald-950/80 px-1.5 py-0.5 rounded-full border border-emerald-800/60">
                <ArrowUpRight className="w-3 h-3" />
                +{snapshot.gold21k.changePct24h}%
              </span>
            </div>

            <div>
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-[11px] text-slate-400">سعر البيع (شراء العميل):</span>
                <span className="font-mono text-lg font-black text-amber-300">
                  {snapshot.gold21k.sellPriceEgp.toLocaleString('ar-EG')} <span className="text-xs font-sans text-amber-200">ج.م</span>
                </span>
              </div>
              <div className="flex items-baseline justify-between text-[11px]">
                <span className="text-slate-400">سعر الشراء (بيع العميل):</span>
                <span className="font-mono font-bold text-slate-200">
                  {snapshot.gold21k.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                </span>
              </div>
            </div>

            <div className="mt-2.5 pt-2 border-t border-amber-500/20 flex items-center justify-between text-[10px] text-amber-300/80">
              <span>فرق الصاغة: <strong>20 ج.م</strong></span>
              <span className="text-slate-400">عيار 875/1000</span>
            </div>
          </div>

          {/* Card 2: عيار 24 (الذهب الخالص وسبائك الاستثمار) */}
          <div className="relative rounded-2xl p-3.5 bg-gradient-to-b from-slate-900/90 via-[#0d1017] to-slate-950/80 border border-amber-500/30 hover:border-amber-400/60 shadow-md flex flex-col justify-between transition-all hover:scale-[1.01]">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
              <div className="flex items-center gap-1.5">
                <span className="text-base">🧈</span>
                <span className="text-xs font-black text-amber-300">عيار 24 (السبائك والخالص)</span>
              </div>
              <span className="text-[10px] text-amber-400 font-bold bg-amber-950/60 px-1.5 py-0.2 rounded border border-amber-800/60">
                999.9
              </span>
            </div>

            <div>
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-[11px] text-slate-400">سعر البيع:</span>
                <span className="font-mono text-lg font-black text-white">
                  {snapshot.gold24k.sellPriceEgp.toLocaleString('ar-EG')} <span className="text-xs font-sans text-slate-400">ج.م</span>
                </span>
              </div>
              <div className="flex items-baseline justify-between text-[11px]">
                <span className="text-slate-400">سعر الشراء:</span>
                <span className="font-mono font-bold text-amber-200">
                  {snapshot.gold24k.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                </span>
              </div>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
              <span>فرق الصاغة: 25 ج.م</span>
              <span className="text-amber-400/90 font-medium">معيار السبائك BTC</span>
            </div>
          </div>

          {/* Card 3: عيار 18 (مشغولات الذهب الإيطالي والأناقة) */}
          <div className="relative rounded-2xl p-3.5 bg-gradient-to-b from-slate-900/90 via-[#0d1017] to-slate-950/80 border border-slate-800 hover:border-slate-700 shadow-md flex flex-col justify-between transition-all hover:scale-[1.01]">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
              <div className="flex items-center gap-1.5">
                <span className="text-base">💎</span>
                <span className="text-xs font-black text-slate-200">عيار 18 (المشغولات)</span>
              </div>
              <span className="text-[10px] text-slate-400 font-bold bg-slate-800 px-1.5 py-0.2 rounded">
                750/1000
              </span>
            </div>

            <div>
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-[11px] text-slate-400">سعر البيع:</span>
                <span className="font-mono text-lg font-black text-white">
                  {snapshot.gold18k.sellPriceEgp.toLocaleString('ar-EG')} <span className="text-xs font-sans text-slate-400">ج.م</span>
                </span>
              </div>
              <div className="flex items-baseline justify-between text-[11px]">
                <span className="text-slate-400">سعر الشراء:</span>
                <span className="font-mono font-bold text-slate-300">
                  {snapshot.gold18k.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                </span>
              </div>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
              <span>فرق الصاغة: 18 ج.م</span>
              <span>ذهب إيطالي وخفيف</span>
            </div>
          </div>

          {/* Card 4: الجنيه الذهب (8 جرام عيار 21 BTC) */}
          <div className="relative rounded-2xl p-3.5 bg-gradient-to-b from-amber-500/10 via-slate-900/90 to-slate-950/80 border border-amber-500/35 hover:border-amber-400/60 shadow-md flex flex-col justify-between transition-all hover:scale-[1.01]">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-amber-500/20">
              <div className="flex items-center gap-1.5">
                <span className="text-base">🪙</span>
                <span className="text-xs font-black text-amber-200">الجنيه الذهب (8 جرام)</span>
              </div>
              <span className="text-[10px] text-amber-300 font-bold bg-amber-950/80 px-1.5 py-0.2 rounded border border-amber-800/60">
                BTC
              </span>
            </div>

            <div>
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-[11px] text-slate-400">سعر البيع:</span>
                <span className="font-mono text-lg font-black text-amber-200">
                  {snapshot.goldPound.sellPriceEgp.toLocaleString('ar-EG')} <span className="text-xs font-sans text-slate-400">ج.م</span>
                </span>
              </div>
              <div className="flex items-baseline justify-between text-[11px]">
                <span className="text-slate-400">سعر الشراء:</span>
                <span className="font-mono font-bold text-slate-300">
                  {snapshot.goldPound.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                </span>
              </div>
            </div>

            <div className="mt-2.5 pt-2 border-t border-amber-500/20 flex items-center justify-between text-[10px] text-amber-300/80">
              <span>نصف: {snapshot.halfGoldPound.sellPriceEgp.toLocaleString('ar-EG')}</span>
              <span>ربع: {snapshot.quarterGoldPound.sellPriceEgp.toLocaleString('ar-EG')}</span>
            </div>
          </div>

          {/* Card 5: الأونصة العالمية وسعر التعادل في الصاغة */}
          <div className="relative rounded-2xl p-3.5 bg-gradient-to-b from-slate-900/90 via-[#0d1017] to-slate-950/80 border border-slate-800 hover:border-slate-700 shadow-md flex flex-col justify-between transition-all hover:scale-[1.01]">
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
              <div className="flex items-center gap-1.5">
                <span className="text-base">🌐</span>
                <span className="text-xs font-black text-cyan-300">أونصة الذهب Spot</span>
              </div>
              <span className="text-[10px] text-cyan-400 font-bold bg-cyan-950/80 px-1.5 py-0.2 rounded border border-cyan-800/60 font-mono">
                XAU/USD
              </span>
            </div>

            <div>
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-[11px] text-slate-400">السعر العالمي:</span>
                <span className="font-mono text-lg font-black text-cyan-300">
                  ${snapshot.globalSpot.priceUsd.toFixed(1)}
                </span>
              </div>
              <div className="flex items-baseline justify-between text-[11px]">
                <span className="text-slate-400">الأونصة بالجنيه:</span>
                <span className="font-mono font-bold text-slate-200">
                  {snapshot.goldOunceEgp.toLocaleString('ar-EG')} ج.م
                </span>
              </div>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
              <span>دولار الصاغة: <strong className="text-white">${snapshot.globalSpot.usdEgpRate.toFixed(1)}ج</strong></span>
              <span className="text-emerald-400 font-medium">التحوط ممتاز 🛡️</span>
            </div>
          </div>
        </div>
      )}

      {/* View Mode 2: Compact Elegant Ribbon */}
      {viewMode === 'RIBBON' && (
        <div className="px-4 py-2 flex items-center gap-3 overflow-x-auto no-scrollbar flex-wrap justify-between">
          <div className="flex items-center gap-2.5 flex-wrap">
            {/* عيار 21 */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-500/40">
              <span className="text-amber-300 font-black text-xs">عيار 21 👑:</span>
              <span className="font-mono font-black text-white text-sm">
                {snapshot.gold21k.sellPriceEgp.toLocaleString('ar-EG')}
              </span>
              <span className="text-[10px] text-slate-400">بيع /</span>
              <span className="font-mono font-bold text-amber-200 text-xs">
                {snapshot.gold21k.buyPriceEgp.toLocaleString('ar-EG')}
              </span>
              <span className="text-[10px] text-slate-400">شراء</span>
              <span className="text-[10px] text-emerald-400 font-bold font-mono mr-1">
                +{snapshot.gold21k.changePct24h}%
              </span>
            </div>

            {/* عيار 24 */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-900/90 border border-slate-800">
              <span className="text-amber-400 font-black text-xs">عيار 24 🧈:</span>
              <span className="font-mono font-bold text-white text-xs">
                {snapshot.gold24k.sellPriceEgp.toLocaleString('ar-EG')}
              </span>
              <span className="text-[10px] text-slate-400">بيع /</span>
              <span className="font-mono text-slate-300 text-xs">
                {snapshot.gold24k.buyPriceEgp.toLocaleString('ar-EG')}
              </span>
            </div>

            {/* عيار 18 */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-900/90 border border-slate-800">
              <span className="text-slate-300 font-black text-xs">عيار 18 💎:</span>
              <span className="font-mono font-bold text-white text-xs">
                {snapshot.gold18k.sellPriceEgp.toLocaleString('ar-EG')}
              </span>
              <span className="text-[10px] text-slate-400">بيع /</span>
              <span className="font-mono text-slate-300 text-xs">
                {snapshot.gold18k.buyPriceEgp.toLocaleString('ar-EG')}
              </span>
            </div>

            {/* الجنيه الذهب */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30">
              <span className="text-amber-300 font-black text-xs">الجنيه الذهب (8ج) 🪙:</span>
              <span className="font-mono font-bold text-amber-200 text-xs">
                {snapshot.goldPound.sellPriceEgp.toLocaleString('ar-EG')}
              </span>
              <span className="text-[10px] text-slate-400">ج.م</span>
            </div>

            {/* الأونصة العالمية */}
            <div className="hidden xl:flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-900/90 border border-slate-800 text-xs font-mono">
              <span className="text-slate-400 font-sans">Spot XAU:</span>
              <span className="text-cyan-300 font-bold">${snapshot.globalSpot.priceUsd.toFixed(1)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Built-in Live Quick Gold Calculator (Drop-down drawer) */}
      {showCalculator && (
        <div className="px-4 py-3 bg-gradient-to-r from-slate-950 via-[#0f1420] to-slate-950 border-t border-amber-500/30 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
            <span className="flex items-center gap-1.5 text-xs font-bold text-amber-300">
              <Calculator className="w-4 h-4 text-amber-400" />
              حاسبة قيمة الذهب الفورية (حساب التكلفة وعائد البيع للصاغة)
            </span>
            <button
              onClick={() => setShowCalculator(false)}
              className="text-slate-500 hover:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
            {/* 1. Caliber Selection */}
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">اختر العيار أو المنتج:</label>
              <select
                value={calcCaliber}
                onChange={(e) => setCalcCaliber(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-amber-300 font-bold focus:outline-none focus:border-amber-400"
              >
                <option value="21">عيار 21 (الأكثر انتشاراً)</option>
                <option value="24">عيار 24 (سبائك خالص 999.9)</option>
                <option value="18">عيار 18 (مشغولات إيطالي)</option>
                <option value="POUND">الجنيه الذهب (8 جرام 21)</option>
              </select>
            </div>

            {/* 2. Weight in Grams or Coins Count */}
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                {calcCaliber === 'POUND' ? 'عدد الجنيهات:' : 'الوزن بالجرام:'}
              </label>
              <input
                type="number"
                min="0.1"
                step="0.1"
                value={calcGrams}
                onChange={(e) => setCalcGrams(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-amber-400 text-right"
                placeholder="مثلاً: 10"
              />
            </div>

            {/* 3. Output Total Buy (Cost to buy from Sagha) */}
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30">
              <span className="block text-[10px] text-slate-400 mb-0.5">تكلفة الشراء من الصاغة:</span>
              <span className="font-mono text-base font-black text-amber-300">
                {Math.round(totalSellValue).toLocaleString('ar-EG')} <span className="text-xs font-sans">ج.م</span>
              </span>
            </div>

            {/* 4. Output Total Sell (Value to sell to Sagha) */}
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30">
              <span className="block text-[10px] text-slate-400 mb-0.5">عائد البيع للصاغة:</span>
              <span className="font-mono text-base font-black text-emerald-300">
                {Math.round(totalBuyValue).toLocaleString('ar-EG')} <span className="text-xs font-sans">ج.م</span>
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Comprehensive Full Gold Market Modal (BTC Bullion Bars & Hedging Guide) */}
      {isModalOpen && (
        <div
          dir="rtl"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn font-['Cairo']"
        >
          <div className="relative w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-inner">
                  <Coins className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-black text-white">
                      أسعار الذهب والسبائك الرسمية (BTC)
                    </h3>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      مباشر ولحظي ⚡
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-2">
                    <span>{snapshot.sourceLabelAr}</span>
                    <span>•</span>
                    <span className="font-mono text-cyan-300">{snapshot.cairoTimestamp}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors cursor-pointer"
                  title="تحديث البيانات الآن"
                >
                  <RefreshCw className={`w-4 h-4 text-amber-400 ${isRefreshing ? 'animate-spin' : ''}`} />
                </button>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Navigation Tabs in Modal */}
            <div className="flex items-center gap-2 px-4 pt-3 pb-1 border-b border-slate-800 bg-slate-950/70 text-xs">
              <button
                type="button"
                onClick={() => setActiveModalTab('CALIBERS')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                  activeModalTab === 'CALIBERS'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                الأعيرة والجرامات (24/21/18)
              </button>
              <button
                type="button"
                onClick={() => setActiveModalTab('POUND')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                  activeModalTab === 'POUND'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                الجنيه الذهب وأجزاؤه
              </button>
              <button
                type="button"
                onClick={() => setActiveModalTab('BARS')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                  activeModalTab === 'BARS'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                سبائك BTC المعتمدة 🧈
              </button>
              <button
                type="button"
                onClick={() => setActiveModalTab('HEDGING')}
                className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                  activeModalTab === 'HEDGING'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                نصائح التحوط والاستثمار 🛡️
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4 max-h-[60vh] no-scrollbar">
              {activeModalTab === 'CALIBERS' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 rounded-2xl bg-slate-950 border border-amber-500/30">
                      <span className="text-xs font-bold text-amber-300 block mb-1">عيار 24 (السبائك)</span>
                      <div className="text-lg font-black font-mono text-white mb-1">
                        {snapshot.gold24k.sellPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                      <div className="text-[11px] text-slate-400">
                        شراء: {snapshot.gold24k.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/40">
                      <span className="text-xs font-bold text-amber-200 block mb-1">عيار 21 (الشائع ⭐)</span>
                      <div className="text-lg font-black font-mono text-amber-300 mb-1">
                        {snapshot.gold21k.sellPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                      <div className="text-[11px] text-slate-300">
                        شراء: {snapshot.gold21k.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                      <span className="text-xs font-bold text-slate-300 block mb-1">عيار 18 (المشغولات)</span>
                      <div className="text-lg font-black font-mono text-white mb-1">
                        {snapshot.gold18k.sellPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                      <div className="text-[11px] text-slate-400">
                        شراء: {snapshot.gold18k.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                    </div>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-1">
                    <div className="flex justify-between">
                      <span className="text-slate-400">أونصة الذهب (31.1 جرام خالص):</span>
                      <span className="font-mono font-bold text-amber-300">{snapshot.goldOunceEgp.toLocaleString('ar-EG')} ج.م</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">سعر الصرف التقديري بالصاغة:</span>
                      <span className="font-mono font-bold text-cyan-300">$1 = {snapshot.globalSpot.usdEgpRate.toFixed(2)} ج.م</span>
                    </div>
                  </div>
                </div>
              )}

              {activeModalTab === 'POUND' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/40">
                      <span className="text-xs font-black text-amber-300 block mb-1">جنيه ذهب كامل (8 جرام)</span>
                      <div className="text-lg font-black font-mono text-white mb-1">
                        {snapshot.goldPound.sellPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                      <div className="text-[11px] text-slate-300">
                        شراء: {snapshot.goldPound.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                      <span className="text-xs font-bold text-slate-200 block mb-1">نصف جنيه ذهب (4 جرام)</span>
                      <div className="text-lg font-black font-mono text-white mb-1">
                        {snapshot.halfGoldPound.sellPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                      <div className="text-[11px] text-slate-400">
                        شراء: {snapshot.halfGoldPound.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                      <span className="text-xs font-bold text-slate-200 block mb-1">ربع جنيه ذهب (2 جرام)</span>
                      <div className="text-lg font-black font-mono text-white mb-1">
                        {snapshot.quarterGoldPound.sellPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                      <div className="text-[11px] text-slate-400">
                        شراء: {snapshot.quarterGoldPound.buyPriceEgp.toLocaleString('ar-EG')} ج.م
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeModalTab === 'BARS' && (
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">
                    أسعار سبائك شركة BTC المعتمدة والمغلفة عيار 24 خالص (999.9) مع الكاش باك الرسمي:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {snapshot.bullionBars.map((bar) => (
                      <div
                        key={bar.nameAr}
                        className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800"
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-amber-400 font-bold">🧈 {bar.nameAr}</span>
                        </div>
                        <span className="font-mono font-bold text-white text-xs">
                          {bar.priceEgp.toLocaleString('ar-EG')} ج.م
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeModalTab === 'HEDGING' && (
                <div className="space-y-3 text-xs text-slate-300">
                  <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/40">
                    <h4 className="font-bold text-emerald-300 mb-1 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      استراتيجية التحوط والتنويع مع الأسهم:
                    </h4>
                    <p className="leading-relaxed text-slate-300">
                      {snapshot.globalSpot.hedgingAdviceAr}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <div className="font-bold text-white">نصائح الصاغة عند الشراء:</div>
                    <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px]">
                      <li>السبائك المغلفة (BTC / Sam) تحتفظ بفاتورة رسمية وكاش باك عند الاسترداد.</li>
                      <li>الجنيه الذهب معفى من معظم المصنعيات المعقدة ومثالي للادخار المتوسط.</li>
                      <li>تأكد دائماً من ختم الصاغة الرسمي ووزن القطعة بالميزان الحساس أمامك.</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
