import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Catch and safely ignore benign TradingView iframe disconnection & non-fatal Firestore offline fallback errors
if (typeof window !== 'undefined') {
  const isIgnorableErr = (err: any) => {
    if (!err) return false;
    const msg = typeof err === 'string' ? err : (err.message || String(err));
    return (
      msg.includes('contentWindow') ||
      msg.includes('Cannot listen to the event') ||
      msg.includes('provided iframe') ||
      msg.includes('Could not reach Cloud Firestore backend') ||
      msg.includes('securetoken.googleapis.com') ||
      msg.includes('auth/token-service-api-has-not-been-used') ||
      msg.includes('Fetching auth token failed')
    );
  };

  const origConsoleError = console.error;
  console.error = (...args: any[]) => {
    const combined = args
      .map((a) => (typeof a === 'string' ? a : (a?.message || '')))
      .join(' ');
    if (isIgnorableErr(combined)) {
      return;
    }
    origConsoleError.apply(console, args);
  };

  window.addEventListener(
    'error',
    (event) => {
      if (isIgnorableErr(event.message) || isIgnorableErr(event.error)) {
        event.stopImmediatePropagation();
        event.preventDefault();
        return true;
      }
    },
    true
  );

  window.addEventListener(
    'unhandledrejection',
    (event) => {
      if (isIgnorableErr(event.reason)) {
        event.stopImmediatePropagation();
        event.preventDefault();
      }
    },
    true
  );
}

createRoot(document.getElementById('root')!).render(<App />);
