/**
 * محرك الذكاء الاصطناعي الموحد لشبكة ApMix و Larp و BluesMinds
 * يدعم التدوير التلقائي الذكي بين 7 مفاتيح ApMix مع تخصيص المفتاح السابع للأخبار كأولوية
 * ونظام Failover فوري إلى LARP_KEY و BLUESMINDS_KEY.
 *
 * Base URL: https://api.apmix.ai/v1
 * Anthropic Base URL: https://api.apmix.ai
 */

import { EGXStock } from '../types/stock';
import { calculateStockTechnicalIndicators } from './technicalAnalysisService';
import { getTradingViewChartVerdict } from '../utils/tradingViewChartVerdict';
import { evaluateSmcAnalysis } from '../utils/smcAnalysisEngine';
import { calculateBollingerBands } from '../utils/bollingerBandsEngine';
import { calculateAccumulationDistribution } from '../utils/accumulationDistributionEngine';
import { getEstimated20DayAvgVolume } from './institutionalLiquidityAlertService';
import { ComprehensiveStockAnalysisReport } from './radarAdvancedEngine';

// --- قائمة المفاتيح المدمجة ---
export const APMIX_KEYS = [
  "apx_live_wdFHjAo1VwzTEgMFfGpkvTA3FVxsdn9qN2wHYwih",
  "apx_live_JapqlhxCa0ThpL8YZYDUxHeTpayKVo6gxXLW2yX8",
  "apx_live_8C81RAHyeS5Jf7kLWcyQIEhk4NvJ45oMzb4f0Bod",
  "apx_live_0y3gohjC021Sv0ZfpoEZjLixFsQRiBe5vZHbQstb",
  "apx_live_pzURsNqalD3eOSJ8t3VUvfcHCIrwDoN0mv1gc9KQ",
  "apx_live_UlWXkU6K33idwWVbEuaoDc3GrHQXGGdhlpHWp6RB",
  "apx_live_BUNLCs55EIv8DbBbRWihVYb9KlTUKbvSROSmPQXy" // المفتاح السابع المخصص للأخبار كأولوية
];

export const LARP_KEY = "lrsk-76d863f33b8ded1ecb7017565a5fbb369a0eb6dd69372cbf0968d794afb73c6e";
export const BLUESMINDS_KEY = "sk-KxUwtzW8aOfX9kjuncOGCMRxPfLbrw7ADmQk6K5zod8GNxBs";

export const APMIX_BASE_URL = "https://api.apmix.ai/v1";
export const APMIX_ANTHROPIC_BASE_URL = "https://api.apmix.ai";

let currentGeneralKeyIndex = 0;

export interface ApmixChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ApmixRequestOptions {
  messages: ApmixChatMessage[];
  category?: 'NEWS' | 'CHAT' | 'ANALYSIS' | 'CHART';
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface ApmixResponseResult {
  text: string;
  providerUsed: string;
  keyLabel: string;
}

/**
 * Builds the prioritized key list based on request category
 */
function getOrderedKeyPool(category: 'NEWS' | 'CHAT' | 'ANALYSIS' | 'CHART' = 'CHAT'): { key: string; label: string }[] {
  const pool: { key: string; label: string }[] = [];

  if (category === 'NEWS') {
    // المفتاح السابع له الأولوية القصوى للأخبار
    pool.push({ key: APMIX_KEYS[6], label: 'ApMix Key #7 (News Priority)' });
    // تدوير باقي مفاتيح ApMix كاحتياطي
    for (let i = 0; i < 6; i++) {
      pool.push({ key: APMIX_KEYS[i], label: `ApMix Key #${i + 1}` });
    }
  } else {
    // تدوير المفاتيح 0 إلى 5 للدردشة والشارت والتحليل
    for (let i = 0; i < 6; i++) {
      const idx = (currentGeneralKeyIndex + i) % 6;
      pool.push({ key: APMIX_KEYS[idx], label: `ApMix Key #${idx + 1}` });
    }
    // المفتاح السابع كاحتياطي
    pool.push({ key: APMIX_KEYS[6], label: 'ApMix Key #7' });
  }

  // خط الدفاع والاحتياطي الثانوي
  pool.push({ key: LARP_KEY, label: 'Larp AI Secondary Backup' });
  pool.push({ key: BLUESMINDS_KEY, label: 'BluesMinds AI Final Backup' });

  return pool;
}

/**
 * Executes a chat completion request across the ApMix network with automated smart failover
 */
export async function callApmixChatCompletion(
  options: ApmixRequestOptions
): Promise<ApmixResponseResult> {
  const category = options.category || 'CHAT';
  const model = options.model || 'gpt-4o-mini';
  const temperature = options.temperature ?? 0.3;
  const maxTokens = options.maxTokens ?? 1000;

  const keyPool = getOrderedKeyPool(category);

  // Advance general index for next request
  if (category !== 'NEWS') {
    currentGeneralKeyIndex = (currentGeneralKeyIndex + 1) % 6;
  }

  // 1. First, attempt via local server proxy if available (bypasses browser CORS & protects network)
  try {
    const serverProxyResp = await fetch('/api/apmix/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messages: options.messages,
        category,
        model,
        temperature,
        maxTokens,
      }),
    });

    if (serverProxyResp.ok) {
      const data = await serverProxyResp.json();
      if (data.text) {
        return {
          text: data.text,
          providerUsed: data.provider || 'ApMix AI Turbo Network',
          keyLabel: data.keyLabel || 'Server Rotated Key',
        };
      }
    }
  } catch (_e) {
    // Continue to direct client-side fetch pool
  }

  // 2. Client-side direct connection with multi-key failover
  for (const { key, label } of keyPool) {
    try {
      const response = await fetch(`${APMIX_BASE_URL}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${key}`,
        },
        body: JSON.stringify({
          model,
          messages: options.messages,
          temperature,
          max_tokens: maxTokens,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const content = data.choices?.[0]?.message?.content;
        if (content) {
          return {
            text: content.trim(),
            providerUsed: 'ApMix AI Turbo',
            keyLabel: label,
          };
        }
      }
    } catch (_err) {
      // Rotate immediately to next key in pool
    }
  }

  throw new Error('All ApMix and backup AI keys are currently busy or unavailable');
}

/**
 * Free-form Stock Chat via ApMix
 */
export async function askStockChatViaApmix(
  stock: EGXStock,
  question: string,
  history: { sender: 'USER' | 'AI'; text: string }[] = []
): Promise<string> {
  const p = stock.price;
  const techInd = calculateStockTechnicalIndicators(stock, '1D');
  const tv = getTradingViewChartVerdict(stock, 'يومي (1D)');
  const smc = evaluateSmcAnalysis(stock, 'يومي (1D)');
  const bollinger = calculateBollingerBands(stock, 'يومي (1D)');
  const adMetric = calculateAccumulationDistribution(stock, 'يومي (1D)');
  const adv20 = getEstimated20DayAvgVolume(stock);
  const vol = stock.volume || 0;
  const rvol20 = adv20 > 0 ? (vol / adv20).toFixed(2) : '1.0';

  const entryLow = (p * 0.985).toFixed(2);
  const entryHigh = (p * 1.012).toFixed(2);
  const target1 = (p * 1.045).toFixed(2);
  const target2 = (p * 1.085).toFixed(2);
  const stopLoss = Math.min(stock.low || p * 0.96, p * 0.965).toFixed(2);

  const historyContext = history
    .slice(-4)
    .map((m) => `${m.sender === 'USER' ? 'المتداول' : 'المستشار'}: ${m.text}`)
    .join('\n');

  const systemPrompt = `أنت كبير المستشارين الماليين وخبير التداول الذكي المعتمد لمنصة رادار البورصة المصرية EGX.
مهمتك: الإجابة على استفسارات المتداولين بدقة عالية وموضوعية استناداً إلى بيانات الشارت والسيولة اللحظية.
أسلوبك: مهني، مباشر، مدعوم بالأرقام والمستويات ونقاط الدعم والمقاومة، مع تقديم نصيحة إدارة المخاطر المناسبة باللغة العربية الفصحى الواضحة.`;

  const userPrompt = `سؤال المتداول: "${question}"

بيانات السهم اللحظية المعتمدة:
- السهم: ${stock.nameAr} (${stock.symbol}) - قطاع: ${stock.sectorAr || 'استثمار عام'}
- السعر الحالي: ${p.toFixed(2)} ج.م (التغير: ${stock.changePct >= 0 ? '+' : ''}${stock.changePct}%)
- أعلى سعر: ${stock.high || p * 1.02} ج.م | أدنى سعر: ${stock.low || p * 0.98} ج.م
- حجم التداول اليوم: ${vol.toLocaleString('en-US')} سهم | متوسط 20 يوم: ${adv20.toLocaleString('en-US')} سهم | RVOL: ${rvol20}x
- التقييم الفني لـ TradingView: [${tv.overallRatingAr}] بنسبة ثقة ${tv.overallScorePct}%
- مؤشر SuperTrend: ${techInd.superTrend.trendAr} (دعم وقائي: ${techInd.superTrend.superTrendValue.toFixed(2)} ج.م)
- مؤشر القوة النسبية RSI(14): ${stock.rsi14 || techInd.rsi.value.toFixed(1)} (${techInd.rsi.statusAr})
- مستويات الارتكاز Pivot: ${tv.levels.pivot} ج.م | S1: ${tv.levels.support1} ج.م | R1: ${tv.levels.resistance1} ج.م
- مدرسة السيولة الذكية (SMC): كتل أوامر صانع السوق عند ${smc.orderBlock.zoneMin} - ${smc.orderBlock.zoneMax} ج.م (${smc.orderBlock.badgeAr})
- مرحلة وايكوف: [${adMetric.wyckoffStageAr}] (تجميع ${adMetric.accumulationScore}% مقابل تصريف ${adMetric.distributionScore}%)
- الموقف الشرعي: ${stock.isShariahCompliant ? 'متوافق مع الشريعة الإسلامية ومدرج بمؤشر EGX30 Shariah ✅' : `غير مدرج بالشريعة ⚠️`}
- نطاق الشراء الاسترشادي: ${entryLow} - ${entryHigh} ج.م | الأهداف: ${target1} ج.م و ${target2} ج.م | وقف الخسارة: ${stopLoss} ج.م

${historyContext ? `السياق السابق:\n${historyContext}\n` : ''}

أجب باحترافية وتنسيق نقطي مريح، مع ذكر الأرقام الصريحة للمستويات الداعمة.`;

  const result = await callApmixChatCompletion({
    category: 'CHAT',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
    temperature: 0.25,
    maxTokens: 850,
  });

  return result.text;
}

/**
 * News Analysis via ApMix using Priority Key #7
 */
export async function analyzeStockNewsViaApmix(
  symbol: string,
  nameAr: string,
  stockPrice?: number,
  changePct?: number
): Promise<string> {
  const prompt = `أنت كبير محللي أخبار أسواق المال والمحلل الاقتصادي في البورصة المصرية EGX.
قم بتحليل أحدث الأخبار والإفصاحات وتوزيعات الأرباح والتوسعات لسهم:
- السهم: ${nameAr} (${symbol})
${stockPrice !== undefined ? `- السعر اللحظي: ${stockPrice.toFixed(2)} ج.م (${changePct ?? 0 >= 0 ? '+' : ''}${changePct ?? 0}%)` : ''}

المطلوب:
1. تقرير إخباري موجز واحترافي يغطي الإفصاحات الرسمية، تطورات الأرباح والمشروعات.
2. تقييم معنويات الأخبار (إيجابي / محايد / سلبي) وأثرها على مسار السهم.
3. أهم المحفزات الصاعدة وأبرز المخاطر المحتملة.
4. توصية تنفيذية للمتداولين بناءً على الزخم الإخباري.`;

  const result = await callApmixChatCompletion({
    category: 'NEWS',
    messages: [
      {
        role: 'system',
        content: 'أنت خبير تحليل الأخبار والإفصاحات الرسمية للبورصة المصرية. تقدم تقارير احترافية وموثقة تدعم قرارات الاستثمار والتداول.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.25,
    maxTokens: 800,
  });

  return result.text;
}

/**
 * 360 Stock Comprehensive Insight via ApMix
 */
export async function generateStock360ViaApmix(
  stock: EGXStock,
  report: ComprehensiveStockAnalysisReport
): Promise<{
  headlineAr: string;
  institutionalAnalysisAr: string;
  keyLevelsSummaryAr: string;
  smartAdviceAr: string;
  volumeAndLiquidityVerdictAr: string;
}> {
  const vol = report.annualVolumeStudy;
  const liq = report.liquidityLineStudy;

  const prompt = `قم بإعداد تحليل 360 درجة موجز واحترافي باللغة العربية الفصحى لسهم شركة بالبورصة المصرية:
- السهم: ${stock.nameAr} (${stock.symbol})
- القطاع: ${stock.sectorAr}
- السعر الحالي: ${stock.price.toFixed(2)} ج.م (التغير: ${stock.changePct}%)
- حجم التداول اليوم: ${vol.currentVolume.toLocaleString()} سهم (RVOL السنوي: ${vol.relativeVolume1Year}x)
- شرط الحجم الإيجابي: تخطي ${vol.volumePositiveThreshold.toLocaleString()} سهم
- خط السيولة ونسبة التدفق: ${liq.liquidityLineTrendAr} (${liq.netInflowRatio}% سيولة داخلة)
- صافي السيولة التراكمية: ${(liq.estimatedNetInflowEgp / 1_000_000).toFixed(1)} مليون ج.م
- متوسط السعر المرجح VWAP: ${liq.vwapPrice} ج.م

أجب بصيغة JSON فقط تحتوي على:
{
  "headlineAr": "عنوان تشخيصي جذاب للسهم",
  "institutionalAnalysisAr": "فقرة من 3 أسطر عن سلوك السيولة الذكية والفوليم وخط السيولة",
  "keyLevelsSummaryAr": "ملخص للمستهدفات والدعوم الهامة",
  "smartAdviceAr": "الرأي الفني والتوصية الدقيقة للدخول",
  "volumeAndLiquidityVerdictAr": "جملة واحدة حاسمة عن وضع الفوليم"
}`;

  const result = await callApmixChatCompletion({
    category: 'ANALYSIS',
    messages: [
      {
        role: 'system',
        content: 'أنت كبير محللي البورصة المصرية المتخصص في تحليل السيولة المؤسساتية. أجب بصيغة JSON فقط.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.2,
    maxTokens: 600,
  });

  try {
    const jsonStr = result.text.replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(jsonStr);
  } catch (_e) {
    return {
      headlineAr: `تشخيص فني ودراسة حجم وسيولة سنوية لسهم ${stock.nameAr} (${stock.symbol})`,
      institutionalAnalysisAr: `يظهر سهم ${stock.nameAr} نشاطاً تداولياً بسعر ${stock.price.toFixed(2)} ج.م مع خط سيولة (${liq.liquidityLineTrendAr}) وتدفق شرائي ${liq.netInflowRatio}%.`,
      keyLevelsSummaryAr: `مستوى الدعم: ${report.execution.stopLoss} ج.م والمستهدف: ${report.execution.target1} ج.م.`,
      smartAdviceAr: liq.bullishTurnConditions.recommendationSummaryAr,
      volumeAndLiquidityVerdictAr: `السهم في مسار واعد يتطلب استمرار تدفق السيولة لاختراق المقاومة.`,
    };
  }
}
