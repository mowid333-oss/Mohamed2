import express from 'express';
import type { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

// Support large image payloads for chart vision analysis
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Initialize GoogleGenAI server-side client
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. TradingView scanner proxy to bypass CORS in dev & prod
app.use('/api/tv-scan', async (req: Request, res: Response) => {
  try {
    const targetUrl = `https://scanner.tradingview.com${req.url}`;
    const response = await fetch(targetUrl, {
      method: req.method,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
      body: req.method !== 'GET' && req.method !== 'HEAD' ? JSON.stringify(req.body) : undefined,
    });

    const data = await response.text();
    res.status(response.status);
    res.setHeader('Content-Type', response.headers.get('content-type') || 'application/json');
    res.send(data);
  } catch (error: any) {
    console.error('TradingView proxy error:', error?.message);
    res.status(502).json({ error: 'Failed to proxy request to TradingView scanner' });
  }
});

// 2. Direct TradingView Chart AI Analysis endpoint
app.post('/api/gemini/analyze-chart', async (req: Request, res: Response) => {
  try {
    const { stock, timeframe, prompt } = req.body;
    if (!stock || !prompt) {
      return res.status(400).json({ error: 'Stock data and prompt are required' });
    }

    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server',
        fallbackNeeded: true,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.2,
        maxOutputTokens: 1400,
      },
    });

    res.json({
      success: true,
      text: response.text || '',
    });
  } catch (error: any) {
    console.error('Direct chart analysis API error:', error?.message);
    res.status(500).json({
      error: error?.message || 'Error generating chart analysis',
      fallbackNeeded: true,
    });
  }
});

// 3. Chart Vision AI (Gemini Vision Image Analysis) endpoint
app.post('/api/gemini/chart-vision', async (req: Request, res: Response) => {
  // Kept outside the try-block so the ApMix fallback can reuse the input if Gemini is unavailable/fails
  let visionFallbackInput: { base64Data: string; mimeType?: string; prompt: string } | null = null;
  try {
    const { base64Data, mimeType, prompt, userContextSymbol } = req.body;
    if (!base64Data || !prompt) {
      return res.status(400).json({ error: 'Image base64 data and prompt are required' });
    }
    visionFallbackInput = { base64Data, mimeType, prompt };

    const ai = getGenAI();
    if (!ai) {
      // Gemini key missing -> try the ApMix multi-key network before giving up
      const fb = await callApmixVisionFallback(visionFallbackInput);
      if (fb) {
        return res.json({ success: true, text: fb.text, provider: 'ApMix AI Network ⚡', keyLabel: fb.label });
      }
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server',
        fallbackNeeded: true,
      });
    }

    const cleanBase64 = base64Data.replace(/^data:image\/[a-z]+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          inlineData: {
            mimeType: mimeType || 'image/png',
            data: cleanBase64,
          },
        },
        prompt,
      ],
      config: {
        temperature: 0.2,
        maxOutputTokens: 2500,
      },
    });

    res.json({
      success: true,
      text: response.text || '',
    });
  } catch (error: any) {
    console.error('Chart vision analysis API error:', error?.message);
    // Gemini request failed -> try the ApMix multi-key network before returning the error
    if (visionFallbackInput) {
      const fb = await callApmixVisionFallback(visionFallbackInput);
      if (fb) {
        return res.json({ success: true, text: fb.text, provider: 'ApMix AI Network ⚡', keyLabel: fb.label });
      }
    }
    res.status(500).json({
      error: error?.message || 'Error analyzing chart image with vision',
      fallbackNeeded: true,
    });
  }
});

// 4. Free-Form Chart Q&A Chat endpoint
app.post('/api/gemini/chart-chat', async (req: Request, res: Response) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server',
        fallbackNeeded: true,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.25,
        maxOutputTokens: 900,
      },
    });

    res.json({
      success: true,
      text: response.text || '',
    });
  } catch (error: any) {
    console.error('Chart chat API error:', error?.message);
    res.status(500).json({
      error: error?.message || 'Error answering chart query',
      fallbackNeeded: true,
    });
  }
});

// 5. ApMix & Multi-Key AI Proxy Endpoint with Automated Failover
const APMIX_SERVER_KEYS = [
  "apx_live_wdFHjAo1VwzTEgMFfGpkvTA3FVxsdn9qN2wHYwih",
  "apx_live_JapqlhxCa0ThpL8YZYDUxHeTpayKVo6gxXLW2yX8",
  "apx_live_8C81RAHyeS5Jf7kLWcyQIEhk4NvJ45oMzb4f0Bod",
  "apx_live_0y3gohjC021Sv0ZfpoEZjLixFsQRiBe5vZHbQstb",
  "apx_live_pzURsNqalD3eOSJ8t3VUvfcHCIrwDoN0mv1gc9KQ",
  "apx_live_UlWXkU6K33idwWVbEuaoDc3GrHQXGGdhlpHWp6RB",
  "apx_live_BUNLCs55EIv8DbBbRWihVYb9KlTUKbvSROSmPQXy" // News priority key
];
const LARP_SERVER_KEY = "lrsk-76d863f33b8ded1ecb7017565a5fbb369a0eb6dd69372cbf0968d794afb73c6e";
const BLUESMINDS_SERVER_KEY = "sk-KxUwtzW8aOfX9kjuncOGCMRxPfLbrw7ADmQk6K5zod8GNxBs";

let serverKeyIndex = 0;

app.post('/api/apmix/chat', async (req: Request, res: Response) => {
  try {
    const { messages, category = 'CHAT', model = 'gpt-4o-mini', temperature = 0.3, maxTokens = 1000 } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'messages array is required' });
    }

    const keysToTry: { key: string; label: string }[] = [];
    if (category === 'NEWS') {
      keysToTry.push({ key: APMIX_SERVER_KEYS[6], label: 'ApMix Key #7 (News Priority)' });
      for (let i = 0; i < 6; i++) {
        keysToTry.push({ key: APMIX_SERVER_KEYS[i], label: `ApMix Key #${i + 1}` });
      }
    } else {
      for (let i = 0; i < 6; i++) {
        const idx = (serverKeyIndex + i) % 6;
        keysToTry.push({ key: APMIX_SERVER_KEYS[idx], label: `ApMix Key #${idx + 1}` });
      }
      keysToTry.push({ key: APMIX_SERVER_KEYS[6], label: 'ApMix Key #7' });
      serverKeyIndex = (serverKeyIndex + 1) % 6;
    }
    keysToTry.push({ key: LARP_SERVER_KEY, label: 'Larp AI Secondary' });
    keysToTry.push({ key: BLUESMINDS_SERVER_KEY, label: 'BluesMinds AI Final' });

    let lastError = '';
    for (const { key, label } of keysToTry) {
      try {
        const resp = await fetch('https://api.apmix.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${key}`,
          },
          body: JSON.stringify({
            model,
            messages,
            temperature,
            max_tokens: maxTokens,
          }),
        });

        if (resp.ok) {
          const data = await resp.json();
          const text = data.choices?.[0]?.message?.content;
          if (text) {
            return res.json({
              success: true,
              text: text.trim(),
              provider: 'ApMix AI Network ⚡',
              keyLabel: label,
            });
          }
        } else {
          lastError = `Status ${resp.status}`;
        }
      } catch (err: any) {
        lastError = err?.message || 'Network error';
      }
    }

    return res.status(502).json({
      error: 'All ApMix and backup keys failed',
      details: lastError,
      fallbackNeeded: true,
    });
  } catch (error: any) {
    console.error('ApMix server proxy error:', error?.message);
    res.status(500).json({ error: error?.message || 'Error processing ApMix chat' });
  }
});

// ApMix vision fallback (used only when Gemini is unavailable). Never throws: returns null on failure so the
// original Gemini error response is preserved. Uses the same ApMix key pool/rotation as /api/apmix/chat.
async function callApmixVisionFallback(input: {
  base64Data: string;
  mimeType?: string;
  prompt: string;
}): Promise<{ text: string; label: string } | null> {
  try {
    const cleanBase64 = input.base64Data.replace(/^data:image\/[a-z]+;base64,/, '');
    const messages = [
      {
        role: 'user',
        content: [
          { type: 'text', text: input.prompt },
          { type: 'image_url', image_url: { url: `data:${input.mimeType || 'image/png'};base64,${cleanBase64}` } },
        ],
      },
    ];

    const pool: { key: string; label: string }[] = [];
    for (let i = 0; i < 6; i++) {
      const idx = (serverKeyIndex + i) % 6;
      pool.push({ key: APMIX_SERVER_KEYS[idx], label: `ApMix Key #${idx + 1}` });
    }
    pool.push({ key: APMIX_SERVER_KEYS[6], label: 'ApMix Key #7' });
    serverKeyIndex = (serverKeyIndex + 1) % 6;

    const deadline = Date.now() + 60_000; // overall cap so the request never hangs
    for (const { key, label } of pool) {
      const remaining = deadline - Date.now();
      if (remaining <= 0) break;
      try {
        const resp = await fetch('https://api.apmix.ai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${key}`,
          },
          body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages,
            temperature: 0.2,
            max_tokens: 2500,
          }),
          signal: AbortSignal.timeout(Math.min(30_000, remaining)),
        });
        if (!resp.ok) continue;
        const data: any = await resp.json();
        const text = data?.choices?.[0]?.message?.content;
        if (typeof text === 'string' && text.trim()) {
          return { text: text.trim(), label };
        }
      } catch (_err) {
        // rotate to the next key
      }
    }
  } catch (err: any) {
    console.error('ApMix vision fallback error:', err?.message);
  }
  return null;
}

// 6. Verified Global Markets News & Fact-Checking endpoint
app.post('/api/gemini/global-market-news', async (req: Request, res: Response) => {
  try {
    const { assetSymbol, query } = req.body;
    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server',
        fallbackNeeded: true,
      });
    }

    const prompt = `أنت كبير محللي الأسواق المالية العالمية ومحقق الأخبار (Fact-Checker).
المطلوب: تقديم أحدث وأدق الأخبار المؤكدة الموثوقة لحظياً للأسواق العالمية (S&P 500, Gold XAU/USD, Brent Oil, Nasdaq, Bitcoin, Dollar Index DXY).
استفسار المستخدم أو الأصل: ${query || assetSymbol || 'الأسواق العالمية'}.
تأكد من استبعاد أي شائعات أو أخبار قديمة غير صحيحة، واذكر المصادر المعتمدة بدقة (Bloomberg, Reuters, Investing.com, CNBC) مع بيان التأثير على حركة السوق والمتوسطات المتحركة.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.2,
      },
    });

    res.json({
      success: true,
      text: response.text || '',
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || [],
    });
  } catch (error: any) {
    console.error('Global market news API error:', error?.message);
    res.status(500).json({
      error: error?.message || 'Error fetching verified global market news',
      fallbackNeeded: true,
    });
  }
});

// Setup Vite middlewares in dev, or static serving in production
async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT} (isProd: ${isProd})`);
  });
}

startServer();
