import express from 'express';
import type { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';

// Support large image payloads for chart vision analysis
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Initialize GoogleGenAI server-side client
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. TradingView scanner proxy to bypass CORS in dev & prod
app.use('/api/tv-scan', async (req: Request, res: Response) => {
  try {
    const targetUrl = `https://scanner.tradingview.com${req.url}`;
    const response = await fetch(targetUrl, {
      method: req.method,
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      },
      body: req.method !== 'GET' && req.method !== 'HEAD' ? JSON.stringify(req.body) : undefined,
    });

    const data = await response.text();
    res.status(response.status);
    res.setHeader('Content-Type', response.headers.get('content-type') || 'application/json');
    res.send(data);
  } catch (error: any) {
    console.error('TradingView proxy error:', error?.message);
    res.status(502).json({ error: 'Failed to proxy request to TradingView scanner' });
  }
});

// 2. Direct TradingView Chart AI Analysis endpoint
app.post('/api/gemini/analyze-chart', async (req: Request, res: Response) => {
  try {
    const { stock, timeframe, prompt } = req.body;
    if (!stock || !prompt) {
      return res.status(400).json({ error: 'Stock data and prompt are required' });
    }

    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server',
        fallbackNeeded: true,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.2,
        maxOutputTokens: 1400,
      },
    });

    res.json({
      success: true,
      text: response.text || '',
    });
  } catch (error: any) {
    console.error('Direct chart analysis API error:', error?.message);
    res.status(500).json({
      error: error?.message || 'Error generating chart analysis',
      fallbackNeeded: true,
    });
  }
});

// 3. Chart Vision AI (Gemini Vision Image Analysis) endpoint
app.post('/api/gemini/chart-vision', async (req: Request, res: Response) => {
  try {
    const { base64Data, mimeType, prompt, userContextSymbol } = req.body;
    if (!base64Data || !prompt) {
      return res.status(400).json({ error: 'Image base64 data and prompt are required' });
    }

    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server',
        fallbackNeeded: true,
      });
    }

    const cleanBase64 = base64Data.replace(/^data:image\/[a-z]+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        {
          inlineData: {
            mimeType: mimeType || 'image/png',
            data: cleanBase64,
          },
        },
        prompt,
      ],
      config: {
        temperature: 0.2,
        maxOutputTokens: 1600,
      },
    });

    res.json({
      success: true,
      text: response.text || '',
    });
  } catch (error: any) {
    console.error('Chart vision analysis API error:', error?.message);
    res.status(500).json({
      error: error?.message || 'Error analyzing chart image with vision',
      fallbackNeeded: true,
    });
  }
});

// 4. Free-Form Chart Q&A Chat endpoint
app.post('/api/gemini/chart-chat', async (req: Request, res: Response) => {
  try {
    const { prompt } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server',
        fallbackNeeded: true,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        temperature: 0.25,
        maxOutputTokens: 900,
      },
    });

    res.json({
      success: true,
      text: response.text || '',
    });
  } catch (error: any) {
    console.error('Chart chat API error:', error?.message);
    res.status(500).json({
      error: error?.message || 'Error answering chart query',
      fallbackNeeded: true,
    });
  }
});

// 5. Verified Global Markets News & Fact-Checking endpoint
app.post('/api/gemini/global-market-news', async (req: Request, res: Response) => {
  try {
    const { assetSymbol, query } = req.body;
    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY is not configured on server',
        fallbackNeeded: true,
      });
    }

    const prompt = `أنت كبير محللي الأسواق المالية العالمية ومحقق الأخبار (Fact-Checker).
المطلوب: تقديم أحدث وأدق الأخبار المؤكدة الموثوقة لحظياً للأسواق العالمية (S&P 500, Gold XAU/USD, Brent Oil, Nasdaq, Bitcoin, Dollar Index DXY).
استفسار المستخدم أو الأصل: ${query || assetSymbol || 'الأسواق العالمية'}.
تأكد من استبعاد أي شائعات أو أخبار قديمة غير صحيحة، واذكر المصادر المعتمدة بدقة (Bloomberg, Reuters, Investing.com, CNBC) مع بيان التأثير على حركة السوق والمتوسطات المتحركة.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.2,
      },
    });

    res.json({
      success: true,
      text: response.text || '',
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || [],
    });
  } catch (error: any) {
    console.error('Global market news API error:', error?.message);
    res.status(500).json({
      error: error?.message || 'Error fetching verified global market news',
      fallbackNeeded: true,
    });
  }
});

// Setup Vite middlewares in dev, or static serving in production
async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT} (isProd: ${isProd})`);
  });
}

startServer();
