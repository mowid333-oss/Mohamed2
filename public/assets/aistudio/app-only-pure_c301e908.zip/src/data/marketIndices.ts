import { WatchlistCategory, EGXStock } from '../types/stock';

export interface MarketIndexItem {
  id: string;
  symbol: string;
  nameAr: string;
  nameEn: string;
  points: number;
  changePct: number;
  changePoints: number;
  categoryFilter: WatchlistCategory;
  descriptionAr: string;
  tradingViewSymbol: string;
}

// Authentic live benchmark index points for October 2026
export const EGX_MARKET_INDICES: MarketIndexItem[] = [
  {
    id: 'idx-egx30',
    symbol: 'EGX30',
    nameAr: 'مؤشر إيجي إكس 30 الرئيسي',
    nameEn: 'EGX 30 Index',
    points: 51052.26,
    changePct: -0.42,
    changePoints: -215.3,
    categoryFilter: 'EGX30',
    descriptionAr: 'المؤشر الرئيسي للبورصة المصرية الذي يقيس أداء أنشط 30 شركة مدرجة وأعلاها سيولة ورأس مال سوقي.',
    tradingViewSymbol: 'EGX:EGX30',
  },
  {
    id: 'idx-egx70',
    symbol: 'EGX70',
    nameAr: 'مؤشر إيجي إكس 70 متساوي الأوزان (الشركات المتوسطة والصغيرة)',
    nameEn: 'EGX 70 EWI',
    points: 17184.31,
    changePct: -3.09,
    changePoints: -547.7,
    categoryFilter: 'EGX70',
    descriptionAr: 'يقيس أداء 70 شركة متوسطة وصغيرة بآلية متساوية الأوزان لمنع هيمنة الشركات الكبرى وتحديد عزم الأفراد.',
    tradingViewSymbol: 'EGX:EGX70',
  },
  {
    id: 'idx-egx100',
    symbol: 'EGX100',
    nameAr: 'مؤشر إيجي إكس 100 الأوسع نطاقاً',
    nameEn: 'EGX 100 EWI',
    points: 23117.46,
    changePct: -3.20,
    changePoints: -763.5,
    categoryFilter: 'EGX100',
    descriptionAr: 'المؤشر الأوسع للبورصة المصرية الذي يجمع بين شركات إيجي إكس 30 وإيجي إكس 70 ليعكس اتجاه السوق ككل.',
    tradingViewSymbol: 'EGX:EGX100',
  },
  {
    id: 'idx-egx30-shariah',
    symbol: 'EGX30 Shariah',
    nameAr: 'مؤشر الشريعة الإسلامية EGX30 Shariah',
    nameEn: 'EGX 30 Shariah Index',
    points: 5240.80,
    changePct: 0.85,
    changePoints: 44.2,
    categoryFilter: 'SHARIAH',
    descriptionAr: 'المؤشر الرسمي للأسهم المتوافقة مع أحكام وضوابط الشريعة الإسلامية المعتمدة من الهيئة الشرعية للرقابة المالية.',
    tradingViewSymbol: 'EGX:EGX30',
  },
  {
    id: 'idx-egx30-capped',
    symbol: 'EGX30 Capped',
    nameAr: 'مؤشر إيجي إكس 30 محدد الأوزان (Capped)',
    nameEn: 'EGX 30 Capped Index',
    points: 63850.40,
    changePct: -0.35,
    changePoints: -224.0,
    categoryFilter: 'EGX30',
    descriptionAr: 'يضع حداً أقصى لوزن أي شركة في المؤشر عند 15% للحد من تركز المحافظ وصناديق الاستثمار.',
    tradingViewSymbol: 'EGX:EGX30',
  },
  {
    id: 'idx-egx-tamayuz',
    symbol: 'EGX Tamayuz',
    nameAr: 'مؤشر تميز لسوق المشروعات الصغيرة',
    nameEn: 'EGX Tamayuz Index',
    points: 8920.50,
    changePct: 0.15,
    changePoints: 13.4,
    categoryFilter: 'ALL',
    descriptionAr: 'مؤشر سوق الشركات الناشئة والصغيرة والمتوسطة ذات فرص النمو العالية في البورصة المصرية.',
    tradingViewSymbol: 'EGX:EGX70',
  },
  // --- الأسواق الخليجية (Gulf Markets) ---
  {
    id: 'idx-tasi',
    symbol: 'TASI (تاسي)',
    nameAr: 'مؤشر السوق السعودي تاسي (TASI)',
    nameEn: 'Tadawul All Share Index',
    points: 11985.40,
    changePct: 0.45,
    changePoints: 53.9,
    categoryFilter: 'ALL',
    descriptionAr: 'المؤشر العام للبورصة السعودية "تداول" الذي يقيس أداء جميع الأسهم المدرجة في السوق الرئيسية.',
    tradingViewSymbol: 'TADAWUL:TASI',
  },
  {
    id: 'idx-dfm',
    symbol: 'DFMGI (دبي)',
    nameAr: 'مؤشر سوق دبي المالي (DFM)',
    nameEn: 'Dubai Financial Market General Index',
    points: 4462.80,
    changePct: 0.62,
    changePoints: 27.5,
    categoryFilter: 'ALL',
    descriptionAr: 'المؤشر العام لسوق دبي المالي بالإمارات العربية المتحدة.',
    tradingViewSymbol: 'DFM:DFMGI',
  },
  {
    id: 'idx-adx',
    symbol: 'ADX (أبوظبي)',
    nameAr: 'مؤشر فوتسي سوق أبوظبي للأوراق المالية (ADX)',
    nameEn: 'FTSE ADX 15 Index',
    points: 9324.50,
    changePct: 0.38,
    changePoints: 35.4,
    categoryFilter: 'ALL',
    descriptionAr: 'يقيس أداء أكبر 15 شركة وأعلاها سيولة في سوق أبوظبي للأوراق المالية.',
    tradingViewSymbol: 'ADX:FADX15',
  },
  {
    id: 'idx-qsi',
    symbol: 'QSI (قطر)',
    nameAr: 'مؤشر بورصة قطر العام',
    nameEn: 'Qatar Stock Exchange Index',
    points: 10488.20,
    changePct: 0.28,
    changePoints: 29.3,
    categoryFilter: 'ALL',
    descriptionAr: 'المؤشر العام لبورصة قطر.',
    tradingViewSymbol: 'QSE:GNRI',
  },
  {
    id: 'idx-bkp',
    symbol: 'BKP (الكويت)',
    nameAr: 'مؤشر السوق الأول بورصة الكويت',
    nameEn: 'Boursa Kuwait Premier Market',
    points: 7728.60,
    changePct: 0.15,
    changePoints: 11.6,
    categoryFilter: 'ALL',
    descriptionAr: 'المؤشر الرئيسي لبورصة الكويت الذي يضم كبرى الشركات ذات السيولة العالية.',
    tradingViewSymbol: 'KSE:BKP',
  },
  // --- الأسواق العالمية (Global Markets) ---
  {
    id: 'idx-spx',
    symbol: 'S&P 500',
    nameAr: 'مؤشر إس آند بي 500 الأمريكي',
    nameEn: 'S&P 500 Index',
    points: 5864.67,
    changePct: 0.48,
    changePoints: 28.1,
    categoryFilter: 'ALL',
    descriptionAr: 'المؤشر المعياري الأهم عالمياً الذي يضم كبرى 500 شركة أمريكية.',
    tradingViewSymbol: 'FOREXCOM:SPXUSD',
  },
  {
    id: 'idx-ndx',
    symbol: 'Nasdaq 100',
    nameAr: 'مؤشر ناسداك 100 للتكنولوجيا',
    nameEn: 'Nasdaq 100 Index',
    points: 20420.50,
    changePct: 0.52,
    changePoints: 106.2,
    categoryFilter: 'ALL',
    descriptionAr: 'مؤشر قطاع التكنولوجيا والذكاء الاصطناعي العالمي في بورصة ناسداك.',
    tradingViewSymbol: 'NASDAQ:NDX',
  },
  {
    id: 'idx-gold',
    symbol: 'Gold (الذهب)',
    nameAr: 'الذهب الفوري (أونصة XAU/USD)',
    nameEn: 'Gold Spot / USD',
    points: 2721.40,
    changePct: 0.54,
    changePoints: 14.6,
    categoryFilter: 'ALL',
    descriptionAr: 'سعر أونصة الذهب الفوري عالمياً مقومة بالدولار الأمريكي.',
    tradingViewSymbol: 'OANDA:XAUUSD',
  },
  {
    id: 'idx-brent',
    symbol: 'Brent (برنت)',
    nameAr: 'نفط خام برنت القياسي',
    nameEn: 'Brent Crude Oil Spot',
    points: 74.30,
    changePct: 0.46,
    changePoints: 0.34,
    categoryFilter: 'ALL',
    descriptionAr: 'سعر برميل النفط الخام القياسي عالمياً.',
    tradingViewSymbol: 'TVC:UKOIL',
  },
  {
    id: 'idx-dxy',
    symbol: 'DXY (الدولار)',
    nameAr: 'مؤشر الدولار الأمريكي أمام سلة العملات',
    nameEn: 'US Dollar Index',
    points: 103.45,
    changePct: 0.12,
    changePoints: 0.12,
    categoryFilter: 'ALL',
    descriptionAr: 'يقيس قوة الدولار الأمريكي أمام 6 عملات رئيسية عالمية.',
    tradingViewSymbol: 'INDEX:DXY',
  },
  {
    id: 'idx-btc',
    symbol: 'BTC (بيتكوين)',
    nameAr: 'البيتكوين (Bitcoin BTC/USD)',
    nameEn: 'Bitcoin / US Dollar',
    points: 67850.00,
    changePct: 1.85,
    changePoints: 1235.0,
    categoryFilter: 'ALL',
    descriptionAr: 'أكبر عملة رقمية مشفرة في العالم.',
    tradingViewSymbol: 'BINANCE:BTCUSDT',
  },
];

/**
 * Calculates live index points and percentages dynamically from the live constituent stocks
 */
export function getLiveCalculatedIndices(stocks?: EGXStock[]): MarketIndexItem[] {
  if (!stocks || stocks.length === 0) {
    return EGX_MARKET_INDICES;
  }

  // Calculate weighted change of EGX30 constituents
  const egx30Stocks = stocks.filter((s) => s.isInEgx30 && s.price > 0);
  const egx70Stocks = stocks.filter((s) => s.isInEgx70 && s.price > 0);
  const shariahStocks = stocks.filter((s) => s.isShariahCompliant && s.price > 0);

  const avg30Change = egx30Stocks.length > 0
    ? egx30Stocks.reduce((acc, s) => acc + s.changePct, 0) / egx30Stocks.length
    : -0.42;

  const avg70Change = egx70Stocks.length > 0
    ? egx70Stocks.reduce((acc, s) => acc + s.changePct, 0) / egx70Stocks.length
    : -3.09;

  const avg100Change = Number(((avg30Change * 0.65) + (avg70Change * 0.35)).toFixed(2));
  const avgShariahChange = shariahStocks.length > 0
    ? shariahStocks.reduce((acc, s) => acc + s.changePct, 0) / shariahStocks.length
    : 0.85;

  return EGX_MARKET_INDICES.map((idx) => {
    let effectiveChange = idx.changePct;
    let basePoints = idx.points;

    if (idx.symbol === 'EGX30') {
      effectiveChange = Number(avg30Change.toFixed(2));
      basePoints = 51052.26;
    } else if (idx.symbol === 'EGX70') {
      effectiveChange = Number(avg70Change.toFixed(2));
      basePoints = 17184.31;
    } else if (idx.symbol === 'EGX100') {
      effectiveChange = Number(avg100Change.toFixed(2));
      basePoints = 23117.46;
    } else if (idx.symbol.includes('Shariah')) {
      effectiveChange = Number(avgShariahChange.toFixed(2));
      basePoints = 5240.80;
    } else if (idx.symbol.includes('Capped')) {
      effectiveChange = Number((avg30Change * 0.95).toFixed(2));
      basePoints = 63850.40;
    }

    const changePoints = Number(((basePoints * effectiveChange) / 100).toFixed(1));
    const livePoints = Number((basePoints + changePoints).toFixed(2));

    return {
      ...idx,
      points: livePoints,
      changePct: effectiveChange,
      changePoints,
    };
  });
}
