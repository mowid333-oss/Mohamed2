import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Sparkles,
  Layers,
  Activity,
  Calculator,
  PieChart,
  BookOpen,
  LineChart,
  ShieldCheck,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertCircle,
  Building2,
  TrendingUp,
  Zap,
  Target,
  FileText,
  Bell,
  Scale,
  Compass,
  Users,
  Newspaper,
  Bot,
  Image as ImageIcon,
  Flame,
  Play,
  Pause,
  FileSpreadsheet,
  Download,
  MessageSquare,
  Globe,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { exportMasterComprehensiveAllStocksExcel } from './services/excelExportService';
import { EGXStock, WatchlistCategory } from './types/stock';
import { fetchLiveEgxStocks } from './services/marketDataService';
import { Header } from './components/Header';
import { GlobalMarketsTab } from './components/GlobalMarketsTab';
import { GlobalMarketAlertToast } from './components/GlobalMarketAlertToast';
import { MarketIndicatorAlert } from './types/globalMarket';
import { DailyEgxMarketStatusBar } from './components/DailyEgxMarketStatusBar';
import { LiveTickerTape } from './components/LiveTickerTape';
import { LiveOpportunitiesTape } from './components/LiveOpportunitiesTape';
import { WatchlistSelector } from './components/WatchlistSelector';
import { StockTable } from './components/StockTable';
import { TradingViewWidget } from './components/TradingViewWidget';
import { ShariahStocksTab } from './components/ShariahStocksTab';
import { AdvancedRadarsTab } from './components/AdvancedRadarsTab';
import { DailyAnalysisReportTab } from './components/DailyAnalysisReportTab';
import { AlertsManagerTab } from './components/AlertsManagerTab';
import { TechnicalAnalystTab } from './components/TechnicalAnalystTab';
import { DivergenceRadarTab } from './components/DivergenceRadarTab';
import { AsoMarketIndicator } from './components/AsoMarketIndicator';
import { InvestorCategoriesTab } from './components/InvestorCategoriesTab';
import { EgxNewsTab } from './components/EgxNewsTab';
import { TechnicalAdvisorModal } from './components/TechnicalAdvisorModal';
import { ChartImageAnalyzerModal } from './components/ChartImageAnalyzerModal';
import { GoogleAiNewsModal } from './components/GoogleAiNewsModal';
import { ShariahScreeningGuideModal } from './components/ShariahScreeningGuideModal';
import { StockDetailsModal } from './components/StockDetailsModal';
import { ComprehensiveStockReportModal } from './components/ComprehensiveStockReportModal';
import { UserAlertsModal } from './components/UserAlertsModal';
import { DailyAnalysisReportModal } from './components/DailyAnalysisReportModal';
import { DirectChartAnalysisModal } from './components/DirectChartAnalysisModal';
import { AiStockChatDrawer } from './components/AiStockChatDrawer';
import { DcaCalculator } from './components/DcaCalculator';
import { SectorsOverview } from './components/SectorsOverview';
import { AnalystForecastsWidget } from './components/AnalystForecastsWidget';
import { TradeManagementTab } from './components/TradeManagementTab';
import { PortfolioJournalTab } from './components/PortfolioJournalTab';
import { loadPortfolioAccount, savePortfolioAccount } from './services/portfolioService';
import { PortfolioAccount } from './types/portfolio';
import { auth } from './services/firebase';
import {
  FirestoreUserAlert,
  subscribeToUserAlerts,
  subscribeToUserWatchlist,
  getOrGenerateDailyReport,
  DailyReportData,
  saveUserAlert,
  toggleAlertStatus,
  deleteUserAlert,
} from './services/userFirestoreService';
import { playBullishAlertSound, playSonarPingSound } from './services/soundAlerts';
import {
  scanInstitutionalLiquidityAlerts,
  getNewUnseenLiquidityAlerts,
  markLiquidityAlertsAsSeen,
  InstitutionalLiquidityAlert,
} from './services/institutionalLiquidityAlertService';
import { LiveLiquidityAlertsDrawer } from './components/LiveLiquidityAlertsDrawer';
import { FloatingLiquidityAlertToast } from './components/FloatingLiquidityAlertToast';
import { SmartUserGuideModal } from './components/SmartUserGuideModal';
import { SystemHealthDiagnosticModal } from './components/SystemHealthDiagnosticModal';
import { DayTradingAnalystTab } from './components/DayTradingAnalystTab';
import {
  runFullSystemDiagnostics,
  SystemHealthReport,
  getStoredHealthReport,
  getHealthCheckIntervalSec,
  setHealthCheckIntervalSec,
} from './services/systemHealthService';

const DEFAULT_FAVORITES = [
  'TMGH',
  'SWDY',
  'FWRY',
  'ABUK',
  'MFPC',
  'AMOC',
  'ESRS',
  'EGAL',
  'ETEL',
  'ADIB',
  'FAIT',
  'JUFO',
  'DOMT',
  'SUGR',
  'ISPH',
  'PHDC',
];

export default function App() {
  const [stocks, setStocks] = useState<EGXStock[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [lastUpdated, setLastUpdated] = useState<string>('جاري التحديث...');
  const [isLiveFeed, setIsLiveFeed] = useState<boolean>(false);
  const [selectedSymbol, setSelectedSymbol] = useState<string>('TMGH');
  const [activeCategory, setActiveCategory] = useState<WatchlistCategory>('ALL');
  const [shariahOnly, setShariahOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'liquidity' | 'gainers' | 'losers' | 'price'>('liquidity');

  // Main Navigation Tabs
  const [activeTab, setActiveTab] = useState<
    | 'WATCHLIST'
    | 'SHARIAH'
    | 'GLOBAL_MARKETS'
    | 'TECHNICAL_ANALYST'
    | 'TRADE_MANAGEMENT'
    | 'PORTFOLIO'
    | 'ASO_REGIME'
    | 'DIVERGENCE'
    | 'RADARS'
    | 'INVESTOR_CATEGORIES'
    | 'NEWS'
    | 'DAILY_REPORT'
    | 'ALERTS'
    | 'CHART'
    | 'DCA'
    | 'SECTORS'
    | 'DAY_TRADING'
  >('WATCHLIST');

  // Real-time Global Indicator Alert Toast State
  const [activeGlobalToastAlert, setActiveGlobalToastAlert] = useState<MarketIndicatorAlert | null>(null);

  // Navigation Tabs continuous marquee pause state
  const [isNavTabsPaused, setIsNavTabsPaused] = useState(false);

  // Screen Display Scale / Zoom state (100%, 90%, 85%) for small laptop screens
  const [zoomLevel, setZoomLevel] = useState<'100' | '90' | '85'>(() => {
    return (localStorage.getItem('egx_zoom_level') as '100' | '90' | '85') || '100';
  });

  const handleZoomLevelChange = (level: '100' | '90' | '85') => {
    setZoomLevel(level);
    localStorage.setItem('egx_zoom_level', level);
  };

  // Ref for Navigation Tabs ribbon horizontal scrolling
  const navTabsRef = useRef<HTMLDivElement>(null);

  // Smart Portfolio Account & Journal State
  const [portfolioAccount, setPortfolioAccount] = useState<PortfolioAccount>(() =>
    loadPortfolioAccount()
  );

  // Firebase Auth & Firestore User Data State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userAlerts, setUserAlerts] = useState<FirestoreUserAlert[]>([]);
  const [dailyReport, setDailyReport] = useState<DailyReportData | null>(null);

  // Modals state
  const [isShariahGuideOpen, setIsShariahGuideOpen] = useState(false);
  const [isAlertsModalOpen, setIsAlertsModalOpen] = useState(false);
  const [isDailyReportModalOpen, setIsDailyReportModalOpen] = useState(false);
  const [selectedStockForModal, setSelectedStockForModal] = useState<EGXStock | null>(null);
  const [selectedStockForReport, setSelectedStockForReport] = useState<EGXStock | null>(null);
  const [isAdvisorOpen, setIsAdvisorOpen] = useState(false);
  const [isChartVisionOpen, setIsChartVisionOpen] = useState(false);
  const [advisorTargetSymbol, setAdvisorTargetSymbol] = useState<string>('TMGH');
  const [isGoogleNewsOpen, setIsGoogleNewsOpen] = useState(false);
  const [googleNewsTargetSymbol, setGoogleNewsTargetSymbol] = useState<string>('TMGH');

  // Direct AI Chart Analysis from TradingView screen without image
  const [isDirectChartAiOpen, setIsDirectChartAiOpen] = useState<boolean>(false);
  const [directChartSymbol, setDirectChartSymbol] = useState<string>('TMGH');

  // Global Free-form AI Stock Chat Sidebar Drawer
  const [isGlobalStockChatOpen, setIsGlobalStockChatOpen] = useState<boolean>(false);

  // Real-time Institutional Liquidity Alerts (ADV-20 Spike)
  const [isLiquidityDrawerOpen, setIsLiquidityDrawerOpen] = useState<boolean>(false);
  const [isLiquiditySoundMuted, setIsLiquiditySoundMuted] = useState<boolean>(false);
  const [activeToastAlert, setActiveToastAlert] = useState<InstitutionalLiquidityAlert | null>(null);

  // Smart User Guidebook modal state
  const [isUserGuideOpen, setIsUserGuideOpen] = useState<boolean>(false);

  // System Health & Diagnostics state (Default: 30 minutes = 1800s)
  const [isHealthModalOpen, setIsHealthModalOpen] = useState<boolean>(false);
  const [healthReport, setHealthReport] = useState<SystemHealthReport | null>(() => getStoredHealthReport());
  const [healthAutoCheckInterval, setHealthAutoCheckInterval] = useState<number>(() => getHealthCheckIntervalSec());
  const [healthCountdownSeconds, setHealthCountdownSeconds] = useState<number>(() => getHealthCheckIntervalSec());

  const handleHealthIntervalChange = (newSec: number) => {
    setHealthAutoCheckInterval(newSec);
    setHealthCountdownSeconds(newSec);
    setHealthCheckIntervalSec(newSec);
  };

  // Auto-refresh interval state in seconds (Default: 60 = 1 minute as requested)
  const [refreshInterval, setRefreshInterval] = useState<number>(() => {
    try {
      const stored = localStorage.getItem('egx_market_refresh_interval');
      if (stored !== null) {
        const val = parseInt(stored, 10);
        if (!isNaN(val)) return val;
      }
    } catch (e) {
      console.warn('Could not read refresh interval', e);
    }
    return 60; // Default: every 1 minute
  });

  const [countdownSeconds, setCountdownSeconds] = useState<number>(() => {
    try {
      const stored = localStorage.getItem('egx_market_refresh_interval');
      if (stored !== null) {
        const val = parseInt(stored, 10);
        if (!isNaN(val) && val > 0) return val;
      }
    } catch {}
    return 60;
  });

  const handleRefreshIntervalChange = (newInterval: number) => {
    setRefreshInterval(newInterval);
    setCountdownSeconds(newInterval);
    try {
      localStorage.setItem('egx_market_refresh_interval', newInterval.toString());
    } catch (e) {
      console.warn('Could not save refresh interval', e);
    }
  };

  // Favorites state
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('egx_user_favorites');
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Could not read favorites from localStorage', e);
    }
    return DEFAULT_FAVORITES;
  });

  // Track Firebase Auth Changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
    });
    return () => unsubscribe();
  }, []);

  // Subscribe to user Firestore alerts & watchlist (with local guest fallback)
  useEffect(() => {
    if (!currentUser) {
      try {
        const stored = localStorage.getItem('egx_guest_alerts');
        if (stored) {
          setUserAlerts(JSON.parse(stored));
          return;
        }
      } catch (e) {
        console.warn('Failed to parse guest alerts', e);
      }
      setUserAlerts([]);
      return;
    }

    const unsubAlerts = subscribeToUserAlerts(currentUser.uid, (alerts) => {
      setUserAlerts(alerts);
    });

    const unsubWatchlist = subscribeToUserWatchlist(currentUser.uid, (cloudSymbols) => {
      if (cloudSymbols.length > 0) {
        setFavorites((prev) => Array.from(new Set([...prev, ...cloudSymbols])));
      }
    });

    return () => {
      unsubAlerts();
      unsubWatchlist();
    };
  }, [currentUser]);

  const handleQuickSaveAlert = async (
    alertData: Omit<FirestoreUserAlert, 'id' | 'userId' | 'createdAt'>
  ) => {
    if (currentUser) {
      await saveUserAlert(currentUser.uid, alertData);
    } else {
      const alertId = `guest_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const newAlert: FirestoreUserAlert = {
        ...alertData,
        id: alertId,
        userId: 'guest',
        createdAt: new Date().toISOString(),
      };
      setUserAlerts((prev) => {
        const next = [newAlert, ...prev];
        try {
          localStorage.setItem('egx_guest_alerts', JSON.stringify(next));
        } catch {}
        return next;
      });
    }
  };

  const handleQuickToggleAlert = async (alertId: string, currentActive: boolean) => {
    if (currentUser) {
      await toggleAlertStatus(currentUser.uid, alertId, !currentActive);
    } else {
      setUserAlerts((prev) => {
        const next = prev.map((a) =>
          a.id === alertId ? { ...a, isActive: !currentActive } : a
        );
        try {
          localStorage.setItem('egx_guest_alerts', JSON.stringify(next));
        } catch {}
        return next;
      });
    }
  };

  const handleQuickDeleteAlert = async (alertId: string) => {
    if (currentUser) {
      await deleteUserAlert(currentUser.uid, alertId);
    } else {
      setUserAlerts((prev) => {
        const next = prev.filter((a) => a.id !== alertId);
        try {
          localStorage.setItem('egx_guest_alerts', JSON.stringify(next));
        } catch {}
        return next;
      });
    }
  };

  const toggleFavorite = (sym: string) => {
    const clean = sym.trim().toUpperCase();
    const updated = favorites.includes(clean)
      ? favorites.filter((s) => s !== clean)
      : [...favorites, clean];
    setFavorites(updated);
    try {
      localStorage.setItem('egx_user_favorites', JSON.stringify(updated));
    } catch (e) {
      console.warn('Could not save favorites', e);
    }
  };

  const handleOpenAdvisor = (symbol?: string) => {
    if (symbol) {
      setAdvisorTargetSymbol(symbol);
    } else if (selectedSymbol) {
      setAdvisorTargetSymbol(selectedSymbol);
    }
    setIsAdvisorOpen(true);
  };

  // Load stock data from TradingView scanner
  const loadMarketData = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await fetchLiveEgxStocks();
      if (res.stocks && res.stocks.length > 0) {
        setStocks(res.stocks);
        setLastUpdated(res.lastUpdated);
        setIsLiveFeed(res.isLive);

        // Generate / Update daily report
        const rep = await getOrGenerateDailyReport(res.stocks);
        setDailyReport(rep);
      }
    } catch (err) {
      console.error('Error fetching EGX market data:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadMarketData();
  }, [loadMarketData]);

  // Initial & periodic full system health diagnostics (Default: 30 minutes = 1800s)
  useEffect(() => {
    if (stocks.length > 0 && !healthReport) {
      runFullSystemDiagnostics(stocks).then((rep) => setHealthReport(rep));
    }
  }, [stocks]);

  useEffect(() => {
    if (healthAutoCheckInterval <= 0) return;
    const healthTimer = setInterval(() => {
      runFullSystemDiagnostics(stocks).then((rep) => {
        setHealthReport(rep);
        setHealthCountdownSeconds(healthAutoCheckInterval);
      });
    }, healthAutoCheckInterval * 1000);
    return () => clearInterval(healthTimer);
  }, [stocks, healthAutoCheckInterval]);

  // 1-second countdown ticker for the 30-minute system health check
  useEffect(() => {
    if (healthAutoCheckInterval <= 0) return;
    const healthTicker = setInterval(() => {
      setHealthCountdownSeconds((prev) => {
        if (prev <= 1) {
          return healthAutoCheckInterval;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(healthTicker);
  }, [healthAutoCheckInterval]);

  // Auto-sync interval based on user-chosen interval (Default: 60 seconds = 1 minute)
  useEffect(() => {
    if (refreshInterval <= 0) return; // Manual only, no auto-refresh

    const timer = setInterval(() => {
      loadMarketData();
      setCountdownSeconds(refreshInterval);
    }, refreshInterval * 1000);

    return () => clearInterval(timer);
  }, [loadMarketData, refreshInterval]);

  // 1-second countdown ticker for the UI
  useEffect(() => {
    if (refreshInterval <= 0) return;

    const ticker = setInterval(() => {
      setCountdownSeconds((prev) => {
        if (prev <= 1) {
          return refreshInterval;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(ticker);
  }, [refreshInterval]);

  // Real-time Institutional Liquidity Alerts (Volume > 20-Day Average Volume)
  const liquidityAlerts = useMemo(
    () => scanInstitutionalLiquidityAlerts(stocks, 1.0),
    [stocks]
  );

  // Audio chime & Floating Toast notification for new institutional liquidity spikes
  useEffect(() => {
    if (stocks.length === 0 || liquidityAlerts.length === 0) return;
    const unseen = getNewUnseenLiquidityAlerts(liquidityAlerts);
    if (unseen.length > 0) {
      const topSpike = unseen[0];
      setActiveToastAlert(topSpike);
      if (!isLiquiditySoundMuted) {
        playSonarPingSound();
      }
      markLiquidityAlertsAsSeen(unseen.map((u) => u.id));
    }
  }, [liquidityAlerts, isLiquiditySoundMuted, stocks.length]);

  // Filtered & Sorted Stocks for the General Watchlist
  const displayedStocks = useMemo(() => {
    let list = [...stocks];

    switch (activeCategory) {
      case 'SHARIAH':
        list = list.filter((s) => s.isShariahCompliant);
        break;
      case 'INSTITUTIONAL_LIQUIDITY': {
        const spikeSymbols = new Set(liquidityAlerts.map((a) => a.symbol));
        list = list.filter((s) => spikeSymbols.has(s.symbol));
        break;
      }
      case 'EGX30':
        list = list.filter((s) => s.isInEgx30);
        break;
      case 'EGX70':
        list = list.filter((s) => s.isInEgx70);
        break;
      case 'EGX100':
        list = list.filter((s) => s.isInEgx100);
        break;
      case 'FAVORITES':
        list = list.filter((s) => favorites.includes(s.symbol));
        break;
      case 'MOST_ACTIVE':
        list = list.sort((a, b) => (b.valueTraded || 0) - (a.valueTraded || 0)).slice(0, 30);
        break;
      case 'GAINERS':
        list = list.filter((s) => s.changePct > 0).sort((a, b) => b.changePct - a.changePct);
        break;
      case 'LOSERS':
        list = list.filter((s) => s.changePct < 0).sort((a, b) => a.changePct - b.changePct);
        break;
      case 'ALL':
      default:
        break;
    }

    if (shariahOnly && activeCategory !== 'SHARIAH') {
      list = list.filter((s) => s.isShariahCompliant);
    }

    if (activeCategory !== 'GAINERS' && activeCategory !== 'LOSERS') {
      if (sortBy === 'liquidity') {
        list.sort((a, b) => (b.valueTraded || 0) - (a.valueTraded || 0));
      } else if (sortBy === 'gainers') {
        list.sort((a, b) => b.changePct - a.changePct);
      } else if (sortBy === 'losers') {
        list.sort((a, b) => a.changePct - b.changePct);
      } else if (sortBy === 'price') {
        list.sort((a, b) => b.price - a.price);
      }
    }

    return list;
  }, [stocks, activeCategory, shariahOnly, sortBy, favorites, liquidityAlerts]);

  // Category Counts
  const counts = useMemo(() => {
    return {
      shariah: stocks.filter((s) => s.isShariahCompliant).length,
      egx30: stocks.filter((s) => s.isInEgx30).length,
      egx70: stocks.filter((s) => s.isInEgx70).length,
      egx100: stocks.filter((s) => s.isInEgx100).length,
      all: stocks.length,
      favorites: stocks.filter((s) => favorites.includes(s.symbol)).length,
      institutionalLiquidity: liquidityAlerts.length,
    };
  }, [stocks, favorites, liquidityAlerts]);

  const activeStock = stocks.find((s) => s.symbol === selectedSymbol) || stocks[0];
  const directChartStock = useMemo(() => {
    return stocks.find((s) => s.symbol === directChartSymbol) || activeStock || stocks[0];
  }, [stocks, directChartSymbol, activeStock]);

  const renderNavigationTabButtons = (keySuffix: string) => (
    <React.Fragment key={keySuffix}>
      {/* Tab 1: General Watchlist */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('WATCHLIST')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'WATCHLIST'
            ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm'
            : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Layers className="w-3.5 h-3.5" />
        <span>قوائم البورصة العامة</span>
        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-800 text-slate-400">
          {displayedStocks.length}
        </span>
      </button>

      {/* Tab 2: Shariah Stocks */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('SHARIAH')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'SHARIAH'
            ? 'bg-gradient-to-r from-emerald-500/20 to-teal-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
            : 'text-emerald-400/80 hover:text-emerald-300 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
        <span>مؤشر الشريعة</span>
        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-mono">
          {counts.shariah}
        </span>
      </button>

      {/* Tab: GLOBAL MARKETS & MOVING AVERAGES */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('GLOBAL_MARKETS')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'GLOBAL_MARKETS'
            ? 'bg-gradient-to-r from-cyan-500/25 via-teal-500/25 to-blue-500/25 text-cyan-200 border border-cyan-400/60 shadow-md shadow-cyan-500/20 font-black'
            : 'text-cyan-400/90 hover:text-cyan-300 hover:bg-slate-900 border border-cyan-500/30'
        }`}
      >
        <Globe className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
        <span>الأسواق العالمية والمتوسطات</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
          S&P, Gold, MAs 🌍
        </span>
      </button>

      {/* Tab 3: TECHNICAL ANALYST & ACCUMULATION & MOVING AVERAGES */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('TECHNICAL_ANALYST')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'TECHNICAL_ANALYST'
            ? 'bg-gradient-to-r from-cyan-600/25 to-teal-600/25 text-cyan-300 border border-cyan-400/50 shadow-md'
            : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Compass className="w-3.5 h-3.5 text-cyan-400" />
        <span>المحلل الفني ومناطق التجميع</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
          التجميع والمتوسطات 🎯
        </span>
      </button>

      {/* Tab: TRADE MANAGEMENT LIFECYCLE */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('TRADE_MANAGEMENT')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'TRADE_MANAGEMENT'
            ? 'bg-gradient-to-r from-emerald-600/30 to-teal-600/30 text-emerald-300 border border-emerald-400/60 shadow-md'
            : 'text-slate-400 hover:text-emerald-300 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Target className="w-3.5 h-3.5 text-emerald-400" />
        <span>إدارة الصفقات والوقف</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
          مباشر 🚀
        </span>
      </button>

      {/* Tab: AI DAY-TRADING ANALYST & ALL-STOCKS SCANNER */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('DAY_TRADING')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'DAY_TRADING'
            ? 'bg-gradient-to-r from-amber-500/25 to-yellow-500/25 text-amber-300 border border-amber-400/60 shadow-md shadow-amber-500/20 font-black'
            : 'text-amber-400/90 hover:text-amber-300 hover:bg-slate-900 border border-amber-500/30'
        }`}
      >
        <Flame className="w-3.5 h-3.5 text-amber-400" />
        <span>محلل التداول وماسح الأسهم</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800 font-mono">
          مسح الأسهم وخطط SMC ⚡
        </span>
      </button>

      {/* Tab: SMART PORTFOLIO JOURNAL */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('PORTFOLIO')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'PORTFOLIO'
            ? 'bg-gradient-to-r from-cyan-600/30 to-indigo-600/30 text-cyan-300 border border-cyan-400/60 shadow-md'
            : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Layers className="w-3.5 h-3.5 text-cyan-400" />
        <span>سجل المحفظة الذكية</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
          رأس المال 💼
        </span>
      </button>

      {/* Quick Launcher: Google AI & Search News Analyst */}
      <button
        dir="rtl"
        onClick={() => {
          setGoogleNewsTargetSymbol(selectedSymbol);
          setIsGoogleNewsOpen(true);
        }}
        className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-teal-500 via-emerald-500 to-teal-400 hover:from-teal-400 hover:to-emerald-300 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md shadow-teal-500/30 whitespace-nowrap shrink-0 border border-teal-200/50 hover:brightness-110 active:scale-95 transition-all cursor-pointer"
        title="محلل AI وبحث Google لرصد الأخبار والإفصاحات اللحظية لأي سهم"
      >
        <Bot className="w-3.5 h-3.5 text-slate-950" />
        <span>محلل AI وبحث Google 🤖</span>
      </button>

      {/* Tab: ASO MARKET REGIME & SENTIMENT */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('ASO_REGIME')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'ASO_REGIME'
            ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-300 border border-amber-500/50 shadow-sm'
            : 'text-slate-400 hover:text-amber-300 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Activity className="w-3.5 h-3.5 text-amber-400" />
        <span>مؤشر حالة السوق (ASO)</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-850 font-mono">
          ميزان القوى 🔥
        </span>
      </button>

      {/* Tab 4: DIVERGENCE RADAR (8 Indicators) */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('DIVERGENCE')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'DIVERGENCE'
            ? 'bg-gradient-to-r from-indigo-500/20 to-purple-500/20 text-indigo-300 border border-indigo-500/50 shadow-sm'
            : 'text-slate-400 hover:text-indigo-300 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Zap className="w-3.5 h-3.5 text-indigo-400" />
        <span>راصد الدايفرجنس (8 مؤشرات)</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
          تاريخ الرصد ⚡
        </span>
      </button>

      {/* Tab 5: THE 4 ADVANCED RADARS */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('RADARS')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'RADARS'
            ? 'bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
            : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Target className="w-3.5 h-3.5 text-cyan-400" />
        <span>الرواصد الفنية الأربعة</span>
      </button>

      {/* Tab 6: INVESTOR CATEGORIES & NET FLOWS */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('INVESTOR_CATEGORIES')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'INVESTOR_CATEGORIES'
            ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-300 border border-amber-500/50 shadow-sm'
            : 'text-slate-400 hover:text-amber-300 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Users className="w-3.5 h-3.5 text-amber-400" />
        <span>فئات المستثمرين والمؤسسات</span>
      </button>

      {/* Tab 7: VERIFIED NEWS SOURCES & DIRECT LINKS */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('NEWS')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'NEWS'
            ? 'bg-teal-500/20 text-teal-300 border border-teal-500/50 shadow-sm'
            : 'text-slate-400 hover:text-teal-300 hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Newspaper className="w-3.5 h-3.5 text-teal-400" />
        <span>الأخبار وروابط إنفستنج</span>
        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-teal-950 text-teal-300 border border-teal-800">
          روابط ↗
        </span>
      </button>

      {/* Tab 8: DAILY AUTOMATED REPORT */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('DAILY_REPORT')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'DAILY_REPORT'
            ? 'bg-teal-500/15 text-teal-300 border border-teal-500/40 shadow-sm'
            : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
        }`}
      >
        <FileText className="w-3.5 h-3.5 text-teal-400" />
        <span>التقرير اليومي</span>
      </button>

      {/* Tab 9: TradingView Chart */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('CHART')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'CHART'
            ? 'bg-blue-500/15 text-blue-300 border border-blue-500/40 shadow-sm'
            : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
        }`}
      >
        <LineChart className="w-3.5 h-3.5" />
        <span>الشارت اللحظي</span>
        {activeStock && (
          <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-md bg-slate-800 text-slate-300">
            {activeStock.symbol}
          </span>
        )}
      </button>

      {/* Tab 10: DCA Calculator */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('DCA')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'DCA'
            ? 'bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm'
            : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
        }`}
      >
        <Calculator className="w-3.5 h-3.5 text-amber-400" />
        <span>حاسبة DCA</span>
      </button>

      {/* Tab 11: Sectors */}
      <button
        dir="rtl"
        onClick={() => setActiveTab('SECTORS')}
        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
          activeTab === 'SECTORS'
            ? 'bg-indigo-500/15 text-indigo-300 border border-indigo-500/40 shadow-sm'
            : 'text-slate-400 hover:text-white hover:bg-slate-900 border border-transparent'
        }`}
      >
        <PieChart className="w-3.5 h-3.5 text-indigo-400" />
        <span>القطاعات</span>
      </button>
    </React.Fragment>
  );

  return (
    <div
      className="min-h-screen bg-[#070a0f] text-slate-100 flex flex-col font-['Cairo',sans-serif] selection:bg-cyan-500/30 selection:text-cyan-300 transition-[zoom] duration-200"
      style={{
        zoom: zoomLevel === '90' ? 0.9 : zoomLevel === '85' ? 0.85 : 1,
      }}
    >
      {/* Top Header */}
      <Header
        stocks={stocks}
        selectedSymbol={selectedSymbol}
        zoomLevel={zoomLevel}
        onZoomLevelChange={handleZoomLevelChange}
        onSelectStock={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('CHART');
        }}
        onSelectStockForTab={(sym, tab) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab(tab as any);
        }}
        onOpenAdvisorWithSymbol={(sym) => {
          setSelectedSymbol(sym);
          handleOpenAdvisor(sym);
        }}
        onOpenReportWithStock={(stk) => {
          setSelectedSymbol(stk.symbol);
          setAdvisorTargetSymbol(stk.symbol);
          setSelectedStockForReport(stk);
        }}
        isLoading={isLoading}
        onRefresh={loadMarketData}
        lastUpdated={lastUpdated}
        shariahOnly={shariahOnly}
        onToggleShariahOnly={() => setShariahOnly(!shariahOnly)}
        onOpenShariahGuide={() => setIsShariahGuideOpen(true)}
        currentUser={currentUser}
        onOpenAlertsModal={() => setIsAlertsModalOpen(true)}
        onOpenLiquidityAlerts={() => setIsLiquidityDrawerOpen(true)}
        liquidityAlertsCount={liquidityAlerts.length}
        onOpenDailyReportModal={() => setIsDailyReportModalOpen(true)}
        onOpen360Report={() => activeStock && setSelectedStockForReport(activeStock)}
        onOpenAdvisor={() => handleOpenAdvisor(selectedSymbol)}
        onOpenGlobalMarkets={() => setActiveTab('GLOBAL_MARKETS')}
        onOpenChartVision={() => setIsChartVisionOpen(true)}
        onOpenGoogleAiNews={() => {
          setGoogleNewsTargetSymbol(selectedSymbol);
          setIsGoogleNewsOpen(true);
        }}
        onOpenGoogleAiNewsWithSymbol={(sym) => {
          setSelectedSymbol(sym);
          setGoogleNewsTargetSymbol(sym);
          setIsGoogleNewsOpen(true);
        }}
        onOpenStockChat={() => setIsGlobalStockChatOpen(true)}
        onSelectIndexCategory={(cat) => {
          setActiveCategory(cat);
          setActiveTab('WATCHLIST');
        }}
        alertsCount={userAlerts.length}
        refreshInterval={refreshInterval}
        onRefreshIntervalChange={handleRefreshIntervalChange}
        countdownSeconds={countdownSeconds}
        onOpenUserGuide={() => setIsUserGuideOpen(true)}
        onOpenHealthModal={() => setIsHealthModalOpen(true)}
        healthScore={healthReport?.overallScore ?? 100}
        onExportMasterExcel={() => exportMasterComprehensiveAllStocksExcel(stocks)}
      />

      {/* Cairo Market Hours & Feed Status Bar with User-Controlled Refresh Interval & Health Badge */}
      <DailyEgxMarketStatusBar
        lastUpdated={lastUpdated}
        totalStocksCount={stocks.length}
        shariahCount={counts.shariah}
        isLiveFeed={isLiveFeed}
        onRefresh={loadMarketData}
        isLoading={isLoading}
        refreshInterval={refreshInterval}
        onRefreshIntervalChange={handleRefreshIntervalChange}
        countdownSeconds={countdownSeconds}
        onOpenHealthModal={() => setIsHealthModalOpen(true)}
        healthScore={healthReport?.overallScore ?? 100}
        healthStatus={healthReport?.overallLevel ?? 'OPTIMAL'}
        onOpenUserGuide={() => setIsUserGuideOpen(true)}
        onNavigateToDayTradingScanner={() => setActiveTab('DAY_TRADING')}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          setActiveTab('WATCHLIST');
        }}
        stocks={stocks}
      />

      {/* Continuous Real-time Price Ticker Tape */}
      <LiveTickerTape
        stocks={stocks}
        selectedSymbol={selectedSymbol}
        onSelectStock={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('CHART');
        }}
        isLoading={isLoading}
      />

      {/* Live Opportunities Ticker Tape (شريط الفرص اللحظية المحدث دورياً) */}
      <LiveOpportunitiesTape
        stocks={stocks}
        selectedSymbol={selectedSymbol}
        onSelectStock={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
        }}
        onSelectStockForChart={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('CHART');
        }}
        onNavigateToScanner={() => {
          setActiveTab('DAY_TRADING');
        }}
        shariahOnly={shariahOnly}
        onOpenAdvisorWithSymbol={(sym) => handleOpenAdvisor(sym)}
        onOpenReportWithStock={(stk) => setSelectedStockForReport(stk)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-[1850px] w-full mx-auto px-2 sm:px-4 lg:px-6 py-4 space-y-5">
        {/* Navigation Tabs Bar with Continuous Marquee, Manual Chevron Controls & Wheel Scrolling */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 gap-2">
          {/* Controls Group: Play/Pause and Scroll Right */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={() => setIsNavTabsPaused(!isNavTabsPaused)}
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors cursor-pointer shadow-sm"
              title={isNavTabsPaused ? 'استئناف حركة شريط قوائم وتبويبات البورصة' : 'إيقاف حركة شريط القوائم مؤقتاً'}
            >
              {isNavTabsPaused ? <Play className="w-3.5 h-3.5 text-cyan-400" /> : <Pause className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => {
                navTabsRef.current?.scrollBy({ left: -260, behavior: 'smooth' });
              }}
              className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors cursor-pointer shadow-sm"
              title="تمرير التبويبات لليمين"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Continuous Moving Track for Navigation Tabs with Wheel & Smooth Scrolling */}
          <div
            dir="ltr"
            ref={navTabsRef}
            className="relative overflow-x-auto no-scrollbar flex-1 group marquee-track scroll-smooth"
            onWheel={(e) => {
              if (navTabsRef.current) {
                navTabsRef.current.scrollLeft += e.deltaY;
              }
            }}
          >
            <div
              className={`flex items-center gap-2 will-change-transform flex-nowrap ${
                isNavTabsPaused ? 'ticker-paused' : 'animate-nav-tabs-marquee'
              }`}
            >
              {/* Set A */}
              {renderNavigationTabButtons('nav-a')}
              {/* Set B (Duplicate for Endless Seamless Continuous Loop) */}
              {renderNavigationTabButtons('nav-b')}
            </div>
          </div>

          {/* Scroll Left Button */}
          <button
            onClick={() => {
              navTabsRef.current?.scrollBy({ left: 260, behavior: 'smooth' });
            }}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors shrink-0 cursor-pointer shadow-sm"
            title="تمرير التبويبات لليسار"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Smart User Guide Quick Action */}
            <button
              onClick={() => setIsUserGuideOpen(true)}
              className="flex items-center gap-1.5 text-xs font-bold text-cyan-200 bg-gradient-to-r from-cyan-600/25 to-teal-600/25 hover:from-cyan-600/35 hover:to-teal-600/35 px-2.5 py-1.5 rounded-xl border border-cyan-400/50 transition-all shrink-0 cursor-pointer shadow-sm"
              title="دليل المستخدم الذكي والشامل للتطبيق"
            >
              <BookOpen className="w-3.5 h-3.5 text-cyan-300" />
              <span className="hidden sm:inline">دليل الاستخدام</span>
            </button>

            {/* System Health Quick Action */}
            <button
              onClick={() => setIsHealthModalOpen(true)}
              className="flex items-center gap-1.5 text-xs font-bold text-emerald-300 bg-emerald-600/20 hover:bg-emerald-600/30 px-2.5 py-1.5 rounded-xl border border-emerald-500/40 transition-all shrink-0 cursor-pointer shadow-sm"
              title="فحص سلامة النظام والإصلاح الفوري كل 30 دقيقة"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden md:inline">فحص النظام</span>
            </button>

            {/* Chart Vision Quick Trigger */}
            <button
              onClick={() => setIsChartVisionOpen(true)}
              className="flex items-center gap-1.5 text-xs font-bold text-indigo-300 bg-indigo-500/15 hover:bg-indigo-500/25 px-2.5 py-1.5 rounded-xl border border-indigo-500/40 transition-all shrink-0"
              title="تحليل صورة شارت بالذكاء الاصطناعي (Gemini Vision)"
            >
              <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden md:inline">تحليل شارت بصورة</span>
            </button>

            {/* Master All Stocks Comprehensive Excel Report (Requested) */}
            <button
              onClick={() => exportMasterComprehensiveAllStocksExcel(stocks)}
              className="flex items-center gap-1.5 text-xs font-bold text-emerald-200 bg-gradient-to-r from-emerald-600/30 to-teal-600/30 hover:from-emerald-600/45 hover:to-teal-600/45 px-3 py-1.5 rounded-xl border border-emerald-400/50 transition-all shrink-0 shadow-md active:scale-95 cursor-pointer"
              title="تحميل التقرير العام الشامل لجميع الأسهم المصرية (290+ سهم) من جميع النواحي والخطط والأهداف والمخاطر ومقياس التجميع والتصريف (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-300" />
              <span>تقرير شامل Excel لكل الأسهم 📊</span>
              <Download className="w-3 h-3 text-emerald-300" />
            </button>

            {/* 360 Report Button */}
            {activeStock && (
              <button
                onClick={() => setSelectedStockForReport(activeStock)}
                className="flex items-center gap-1.5 text-xs font-bold text-cyan-300 bg-cyan-500/15 hover:bg-cyan-500/25 px-3 py-1.5 rounded-xl border border-cyan-500/40 transition-all shrink-0 shadow-sm"
                title={`عرض التقرير الفني والشرعي الشامل 360° لسهم ${activeStock.nameAr} (${activeStock.symbol})`}
              >
                <FileText className="w-3.5 h-3.5 text-cyan-400" />
                <span>تقرير 360° لـ {activeStock.symbol}</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab 1: GENERAL WATCHLIST */}
        {activeTab === 'WATCHLIST' && (
          <div className="space-y-4">
            <WatchlistSelector
              activeCategory={activeCategory}
              onSelectCategory={setActiveCategory}
              counts={counts}
              sortBy={sortBy}
              onSortChange={setSortBy}
              shariahOnly={shariahOnly}
            />

            <StockTable
              stocks={displayedStocks}
              selectedSymbol={selectedSymbol}
              onSelectStock={(sym) => {
                setSelectedSymbol(sym);
                setActiveTab('CHART');
              }}
              favorites={favorites}
              onToggleFavorite={toggleFavorite}
              onOpenStockDetails={(s) => setSelectedStockForModal(s)}
              onOpenDetailedReport={(stock) => setSelectedStockForReport(stock)}
              onOpenChart={(sym) => {
                setSelectedSymbol(sym);
                setActiveTab('CHART');
              }}
              onOpenGoogleAiNews={(sym) => {
                setSelectedSymbol(sym);
                setGoogleNewsTargetSymbol(sym);
                setIsGoogleNewsOpen(true);
              }}
              onOpenDirectChartAi={(stock) => {
                setSelectedSymbol(stock.symbol);
                setDirectChartSymbol(stock.symbol);
                setIsDirectChartAiOpen(true);
              }}
              userAlerts={userAlerts}
              onSaveAlert={handleQuickSaveAlert}
              onToggleAlert={handleQuickToggleAlert}
              onDeleteAlert={handleQuickDeleteAlert}
              isLoggedIn={Boolean(currentUser)}
              onOpenAuthModal={() => setIsAlertsModalOpen(true)}
            />
          </div>
        )}

        {/* Tab 2: SEPARATE DEDICATED SHARIAH STOCKS LIST */}
        {activeTab === 'SHARIAH' && (
          <ShariahStocksTab
            stocks={stocks}
            selectedSymbol={selectedSymbol}
            onSelectStock={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenDetailedReport={(stock) => setSelectedStockForReport(stock)}
            onOpenShariahGuide={() => setIsShariahGuideOpen(true)}
            onOpenChart={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            favorites={favorites}
            onToggleFavorite={toggleFavorite}
          />
        )}

        {/* Tab: GLOBAL MARKETS & MOVING AVERAGES (الأسواق العالمية والمتوسطات) */}
        {activeTab === 'GLOBAL_MARKETS' && (
          <GlobalMarketsTab
            onSelectStockForChart={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenAdvisor={(sym) => handleOpenAdvisor(sym)}
          />
        )}

        {/* Tab 3: TECHNICAL ANALYST (RSI, Stochastic, MACD, SuperTrend) */}
        {activeTab === 'TECHNICAL_ANALYST' && (
          <TechnicalAnalystTab
            stocks={stocks}
            selectedSymbol={selectedSymbol}
            onSelectStock={(sym) => {
              setSelectedSymbol(sym);
            }}
            onSelectStockForChart={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenReportModal={(stock) => setSelectedStockForReport(stock)}
            onOpenAdvisor={(sym) => handleOpenAdvisor(sym)}
            shariahOnly={shariahOnly}
            onToggleShariahOnly={() => setShariahOnly(!shariahOnly)}
          />
        )}

        {/* Tab: TRADE MANAGEMENT LIFECYCLE */}
        {activeTab === 'TRADE_MANAGEMENT' && (
          <TradeManagementTab
            stocks={stocks}
            selectedSymbol={selectedSymbol}
            onSelectStock={(sym) => {
              setSelectedSymbol(sym);
              setAdvisorTargetSymbol(sym);
            }}
            portfolio={portfolioAccount}
            onUpdatePortfolio={(upd) => {
              setPortfolioAccount(upd);
              savePortfolioAccount(upd);
            }}
            onSwitchToPortfolioTab={() => setActiveTab('PORTFOLIO')}
            onOpenAdvisor={(sym) => handleOpenAdvisor(sym)}
          />
        )}

        {/* Tab: AI DAY-TRADING ANALYST (XAUUSD & EGX STOCKS) (Requested) */}
        {activeTab === 'DAY_TRADING' && (
          <DayTradingAnalystTab
            stocks={stocks}
            selectedSymbol={selectedSymbol}
            onSelectStock={(sym) => {
              setSelectedSymbol(sym);
              setAdvisorTargetSymbol(sym);
            }}
            onSelectStockForChart={(sym) => {
              setSelectedSymbol(sym);
              setAdvisorTargetSymbol(sym);
              setActiveTab('CHART');
            }}
          />
        )}

        {/* Tab: SMART PORTFOLIO JOURNAL */}
        {activeTab === 'PORTFOLIO' && (
          <PortfolioJournalTab
            stocks={stocks}
            portfolio={portfolioAccount}
            onUpdatePortfolio={(upd) => {
              setPortfolioAccount(upd);
              savePortfolioAccount(upd);
            }}
            onSelectStock={(sym) => {
              setSelectedSymbol(sym);
              setAdvisorTargetSymbol(sym);
            }}
            onSwitchToTradeManagement={() => setActiveTab('TRADE_MANAGEMENT')}
          />
        )}

        {/* Tab: ASO MARKET REGIME & SENTIMENT OSCILLATOR */}
        {activeTab === 'ASO_REGIME' && (
          <AsoMarketIndicator
            stocks={stocks}
            onSelectStock={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenReportModal={(stock) => setSelectedStockForReport(stock)}
          />
        )}

        {/* Tab 4: DIVERGENCE RADAR (8 Indicators & Detection Dates) */}
        {activeTab === 'DIVERGENCE' && (
          <DivergenceRadarTab
            stocks={stocks}
            onSelectStockForChart={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenReportModal={(stock) => setSelectedStockForReport(stock)}
            onOpenAdvisor={(sym) => handleOpenAdvisor(sym)}
            shariahOnly={shariahOnly}
            onToggleShariahOnly={() => setShariahOnly(!shariahOnly)}
          />
        )}

        {/* Tab 5: THE 4 ADVANCED RADARS */}
        {activeTab === 'RADARS' && (
          <AdvancedRadarsTab
            stocks={stocks}
            onSelectStockForChart={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenDetailedReport={(stock) => setSelectedStockForReport(stock)}
            shariahOnly={shariahOnly}
            onToggleShariahOnly={() => setShariahOnly(!shariahOnly)}
          />
        )}

        {/* Tab 6: INVESTOR CATEGORIES & NET FLOWS */}
        {activeTab === 'INVESTOR_CATEGORIES' && (
          <InvestorCategoriesTab
            stocks={stocks}
            onSelectStockForChart={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenReportModal={(stock) => setSelectedStockForReport(stock)}
            onOpenAdvisor={(sym) => handleOpenAdvisor(sym)}
          />
        )}

        {/* Tab 7: VERIFIED ACCURATE NEWS SOURCES */}
        {activeTab === 'NEWS' && (
          <EgxNewsTab
            stocks={stocks}
            onSelectStockForChart={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenReportModal={(stock) => setSelectedStockForReport(stock)}
            onOpenAdvisor={(sym) => handleOpenAdvisor(sym)}
          />
        )}

        {/* Tab 8: DAILY AUTOMATED REPORT */}
        {activeTab === 'DAILY_REPORT' && dailyReport && (
          <DailyAnalysisReportTab
            report={dailyReport}
            stocks={stocks}
            onSelectStock={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
            onOpenDetailedReport={(stock) => setSelectedStockForReport(stock)}
          />
        )}

        {/* Tab 9: ALERTS MANAGER & FIRESTORE */}
        {activeTab === 'ALERTS' && (
          <AlertsManagerTab
            currentUser={currentUser}
            alerts={userAlerts}
            stocks={stocks}
            selectedSymbol={selectedSymbol}
            onSelectStock={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
          />
        )}

        {/* Tab 10: REAL-TIME TRADINGVIEW CHART */}
        {activeTab === 'CHART' && activeStock && (
          <div className="space-y-4">
            <TradingViewWidget
              stock={activeStock}
              liveStocks={stocks}
              onOpenShariahGuide={() => setIsShariahGuideOpen(true)}
              onOpenDetailedReport={(stock) => setSelectedStockForReport(stock)}
              onOpenDirectChartAi={(stk) => {
                setDirectChartSymbol(stk.symbol);
                setIsDirectChartAiOpen(true);
              }}
            />

            {/* المكون الجديد تحت TradingViewWidget: آراء وتوقعات المحللين الماليين المعتمدين والمصادر المرتبطة بالسهم المختار مع ضمان الجلب والتحديث الدوري المنتظم */}
            <AnalystForecastsWidget
              stock={activeStock}
              onSelectRelatedStock={(sym) => {
                setSelectedSymbol(sym);
                setAdvisorTargetSymbol(sym);
              }}
            />

            {/* Quick Switcher Carousel below chart */}
            <div className="space-y-2">
              <span className="text-xs text-slate-400 font-bold block">
                تبديل سريع لأسهم مؤشر الشريعة الإسلامية:
              </span>
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                {stocks
                  .filter((s) => s.isShariahCompliant)
                  .slice(0, 25)
                  .map((s) => (
                    <button
                      key={s.symbol}
                      onClick={() => setSelectedSymbol(s.symbol)}
                      className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-bold transition-all shrink-0 ${
                        s.symbol === selectedSymbol
                          ? 'bg-emerald-500/25 border-emerald-500 text-white shadow-sm'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span>{s.symbol}</span>
                      <span className="text-[10px] text-emerald-400 mr-1.5">
                        {s.price.toFixed(1)}
                      </span>
                    </button>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 11: DCA CALCULATOR */}
        {activeTab === 'DCA' && (
          <DcaCalculator
            stocks={stocks}
            selectedSymbol={selectedSymbol}
            onSelectStock={setSelectedSymbol}
          />
        )}

        {/* Tab 12: SECTORS BREAKDOWN */}
        {activeTab === 'SECTORS' && (
          <SectorsOverview
            stocks={stocks}
            onSelectSectorStock={(sym) => {
              setSelectedSymbol(sym);
              setActiveTab('CHART');
            }}
          />
        )}
      </main>

      {/* Unified Side-by-Side Floating AI Dock at bottom-left (Zero Overlap) */}
      {!isGlobalStockChatOpen && (
        <div className="fixed bottom-5 left-5 z-40 flex items-center gap-2.5 sm:gap-3 font-['Cairo'] flex-wrap">
          {/* Button 1: AI Technical Advisor */}
          <button
            onClick={() => handleOpenAdvisor(selectedSymbol)}
            className="bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white font-black text-xs sm:text-sm px-3.5 py-2.5 sm:px-4 sm:py-3 rounded-2xl shadow-2xl shadow-cyan-500/30 border border-cyan-400/50 flex items-center gap-2.5 transition-all hover:scale-105 active:scale-95 group cursor-pointer shrink-0"
            title="استشارة المستشار الفني الذكي المباشر (AI Technical Advisor)"
          >
            <div className="w-8 h-8 rounded-xl bg-black/30 flex items-center justify-center border border-cyan-300/30 shrink-0">
              <Bot className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-200 group-hover:rotate-12 transition-transform" />
            </div>
            <div className="text-right">
              <span className="block text-[9px] sm:text-[10px] text-cyan-200 leading-none">مستشارك الفني</span>
              <span className="font-bold text-xs sm:text-sm whitespace-nowrap">المستشار المباشر 🤖</span>
            </div>
          </button>

          {/* Button 2: Free-form AI Stock Chat */}
          <button
            onClick={() => setIsGlobalStockChatOpen(true)}
            className="group flex items-center gap-2.5 px-3.5 py-2.5 sm:px-4 sm:py-3 rounded-2xl bg-gradient-to-r from-slate-950 via-cyan-950 to-slate-950 text-white border border-cyan-500/50 shadow-2xl shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-105 active:scale-95 transition-all cursor-pointer shrink-0"
            title="افتح شريط المحادثة المباشر للاستفسارات الحرة عن الأسهم بالذكاء الاصطناعي"
          >
            <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shrink-0">
              <MessageSquare className="w-4 h-4" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400" />
            </div>

            <div className="text-right">
              <div className="flex items-center gap-1.5 text-xs font-bold text-white whitespace-nowrap">
                <span>استفسار حر AI 💬</span>
                {activeStock && (
                  <span className="font-mono text-cyan-300 bg-cyan-950/80 px-1.5 py-0.2 rounded border border-cyan-500/40 text-[10px]">
                    {activeStock.symbol}
                  </span>
                )}
              </div>
              {activeStock && (
                <div className="text-[10px] text-slate-400 flex items-center gap-1 font-mono whitespace-nowrap">
                  <span>{activeStock.price.toFixed(2)} ج.م</span>
                  <span className={activeStock.changePct >= 0 ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    ({activeStock.changePct >= 0 ? '+' : ''}{activeStock.changePct}%)
                  </span>
                </div>
              )}
            </div>
          </button>
        </div>
      )}

      {/* World-Class Footer */}
      <footer className="border-t border-slate-800/80 bg-[#06090e] py-8 px-2 sm:px-4 lg:px-6 text-xs text-slate-500 mt-auto font-['Cairo']">
        <div className="max-w-[1850px] w-full mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-right">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="font-bold text-slate-200 text-sm">
                مستشار التداول الذكي
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                تحديث يومي آلي
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              بيانات الأسعار اللحظية والإغلاقات مؤكدة عبر TradingView والمصادر الإخبارية المعتمدة وهيئة الرقابة المالية ومؤشر الشريعة والأسواق العالمية والخليجية
            </p>
          </div>

          <div className="flex items-center gap-4 text-slate-400 font-medium flex-wrap justify-center">
            <button
              onClick={() => setActiveTab('GLOBAL_MARKETS')}
              className="hover:text-cyan-300 transition-colors font-bold text-cyan-400"
            >
              🌍 الأسواق العالمية والمتوسطات
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setActiveTab('TECHNICAL_ANALYST')}
              className="hover:text-cyan-400 transition-colors"
            >
              المحلل الفني
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setActiveTab('DIVERGENCE')}
              className="hover:text-indigo-400 transition-colors"
            >
              راصد الدايفرجنس
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setActiveTab('INVESTOR_CATEGORIES')}
              className="hover:text-amber-400 transition-colors"
            >
              فئات المستثمرين
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setActiveTab('NEWS')}
              className="hover:text-teal-400 transition-colors"
            >
              الأخبار المعتمدة
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setIsChartVisionOpen(true)}
              className="hover:text-cyan-400 transition-colors"
            >
              تحليل شارت بصورة
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setActiveTab('DAY_TRADING')}
              className="hover:text-amber-300 transition-colors font-bold"
            >
              ⚡ محلل التداول اللحظي (XAUUSD & الأسهم)
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setIsShariahGuideOpen(true)}
              className="hover:text-emerald-400 transition-colors"
            >
              معايير الشريعة
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setIsUserGuideOpen(true)}
              className="hover:text-cyan-300 transition-colors font-bold"
            >
              📖 دليل الاستخدام الذكي
            </button>
            <span className="text-slate-700">·</span>
            <button
              onClick={() => setIsHealthModalOpen(true)}
              className="hover:text-emerald-300 transition-colors font-bold"
            >
              🛡️ فحص سلامة النظام (30 دقيقة)
            </button>
          </div>
        </div>
      </footer>

      {/* AI Technical Advisor Modal */}
      <TechnicalAdvisorModal
        isOpen={isAdvisorOpen}
        onClose={() => setIsAdvisorOpen(false)}
        stocks={stocks}
        initialSymbol={advisorTargetSymbol}
        onSelectStock={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
        }}
        onSelectStockForChart={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('CHART');
        }}
        onOpenTradeManagement={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('TRADE_MANAGEMENT');
        }}
      />

      {/* Google AI Search & News Analyst Modal */}
      <GoogleAiNewsModal
        isOpen={isGoogleNewsOpen}
        onClose={() => setIsGoogleNewsOpen(false)}
        stocks={stocks}
        initialSymbol={googleNewsTargetSymbol || selectedSymbol}
        onSelectStockForChart={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('CHART');
        }}
        onOpenTradeManagement={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('TRADE_MANAGEMENT');
        }}
      />

      {/* Chart Image Analyzer Modal (Gemini Vision) */}
      <ChartImageAnalyzerModal
        isOpen={isChartVisionOpen}
        onClose={() => setIsChartVisionOpen(false)}
        defaultSymbol={selectedSymbol}
        onOpenDirectChartAi={(sym) => {
          setDirectChartSymbol(sym);
          setIsDirectChartAiOpen(true);
        }}
      />

      {/* Direct TradingView AI Chart Analysis Modal without Images (Requested) */}
      {directChartStock && (
        <DirectChartAnalysisModal
          isOpen={isDirectChartAiOpen}
          onClose={() => setIsDirectChartAiOpen(false)}
          stock={directChartStock}
          onOpenDetailedReport={(stk) => {
            setSelectedStockForReport(stk);
            setIsDirectChartAiOpen(false);
          }}
          onOpenTradeManagement={(sym) => {
            setSelectedSymbol(sym);
            setAdvisorTargetSymbol(sym);
            setIsDirectChartAiOpen(false);
            setActiveTab('TRADE_MANAGEMENT');
          }}
        />
      )}

      {/* Shariah Screening Standards Modal */}
      <ShariahScreeningGuideModal
        isOpen={isShariahGuideOpen}
        onClose={() => setIsShariahGuideOpen(false)}
      />

      {/* Stock Deep Details Modal */}
      <StockDetailsModal
        stock={selectedStockForModal}
        isOpen={!!selectedStockForModal}
        onClose={() => setSelectedStockForModal(null)}
        onOpenChart={(sym) => {
          setSelectedSymbol(sym);
          setActiveTab('CHART');
        }}
        onOpenDetailedReport={(stock) => setSelectedStockForReport(stock)}
        onOpenAdvisor={(sym) => handleOpenAdvisor(sym)}
        isFavorite={selectedStockForModal ? favorites.includes(selectedStockForModal.symbol) : false}
        onToggleFavorite={toggleFavorite}
      />

      {/* Comprehensive 360 Stock Technical & Shariah Report Modal */}
      <ComprehensiveStockReportModal
        stock={selectedStockForReport}
        liveStocks={stocks}
        isOpen={!!selectedStockForReport}
        onClose={() => setSelectedStockForReport(null)}
        onOpenChart={(sym) => {
          setSelectedSymbol(sym);
          setActiveTab('CHART');
        }}
      />

      {/* User Alerts Configuration & Google Auth Modal */}
      <UserAlertsModal
        isOpen={isAlertsModalOpen}
        onClose={() => setIsAlertsModalOpen(false)}
        currentUser={currentUser}
        alerts={userAlerts}
        stocks={stocks}
        selectedSymbol={selectedSymbol}
      />

      {/* Daily Automated Analysis Market Report Modal */}
      {dailyReport && (
        <DailyAnalysisReportModal
          isOpen={isDailyReportModalOpen}
          onClose={() => setIsDailyReportModalOpen(false)}
          report={dailyReport}
          stocks={stocks}
        />
      )}

      {/* Smart Interactive User Guidebook Modal (Requested) */}
      <SmartUserGuideModal
        isOpen={isUserGuideOpen}
        onClose={() => setIsUserGuideOpen(false)}
        onNavigateToTab={(tab) => {
          setActiveTab(tab as any);
          setIsUserGuideOpen(false);
        }}
        onOpenHealthModal={() => {
          setIsUserGuideOpen(false);
          setIsHealthModalOpen(true);
        }}
      />

      {/* System Health Diagnostics & Self-Healing Modal (Default: every 30 mins) (Requested) */}
      <SystemHealthDiagnosticModal
        isOpen={isHealthModalOpen}
        onClose={() => setIsHealthModalOpen(false)}
        report={healthReport}
        stocks={stocks}
        onRefreshReport={(rep) => setHealthReport(rep)}
        countdownSeconds={healthCountdownSeconds}
        autoCheckInterval={healthAutoCheckInterval}
        onIntervalChange={handleHealthIntervalChange}
      />

      {/* Real-time Institutional Liquidity Alerts Drawer (ADV-20 Spike Monitor) */}
      <LiveLiquidityAlertsDrawer
        isOpen={isLiquidityDrawerOpen}
        onClose={() => setIsLiquidityDrawerOpen(false)}
        alerts={liquidityAlerts}
        stocks={stocks}
        isSoundMuted={isLiquiditySoundMuted}
        onToggleSound={() => setIsLiquiditySoundMuted((prev) => !prev)}
        onSelectStockForChart={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('CHART');
          setIsLiquidityDrawerOpen(false);
        }}
        onOpenReportModal={(stock) => {
          setSelectedStockForReport(stock);
          setIsLiquidityDrawerOpen(false);
        }}
        onOpenAdvisor={(sym) => {
          handleOpenAdvisor(sym);
          setIsLiquidityDrawerOpen(false);
        }}
      />

      {/* Floating Bottom Notification Toast on New Institutional Spikes */}
      <FloatingLiquidityAlertToast
        alert={activeToastAlert}
        onOpenDrawer={() => {
          setActiveToastAlert(null);
          setIsLiquidityDrawerOpen(true);
        }}
        onSelectStockForChart={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
          setActiveTab('CHART');
          setActiveToastAlert(null);
        }}
        onDismiss={() => setActiveToastAlert(null)}
      />

      {/* Floating Global Market Indicator Alert Toast (الأسواق العالمية والمتوسطات) */}
      <GlobalMarketAlertToast
        alert={activeGlobalToastAlert}
        onSelectAssetForChart={(sym) => {
          setActiveTab('GLOBAL_MARKETS');
          setActiveGlobalToastAlert(null);
        }}
        onDismiss={() => setActiveGlobalToastAlert(null)}
      />

      {/* Global Free-form AI Stock Chat Sidebar Drawer */}
      <AiStockChatDrawer
        isOpen={isGlobalStockChatOpen}
        onToggle={() => setIsGlobalStockChatOpen((prev) => !prev)}
        stocks={stocks}
        currentStock={activeStock}
        hideLauncherButton={true}
        onSelectStock={(sym) => {
          setSelectedSymbol(sym);
          setAdvisorTargetSymbol(sym);
        }}
      />
    </div>
  );
}
