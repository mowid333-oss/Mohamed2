import React, { useState, useMemo, useEffect } from 'react';
import {
  FileText,
  X,
  Printer,
  Copy,
  Check,
  Sparkles,
  Zap,
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  ShieldAlert,
  Target,
  BarChart2,
  Calendar,
  Share2,
  Activity,
  Calculator,
  ExternalLink,
  Cpu,
  RefreshCw,
  Info,
  Droplets,
  Scale,
  Gauge,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  Sliders,
  Compass,
} from 'lucide-react';
import { EGXStock } from '../types/stock';
import { generateComprehensiveStockReport, ComprehensiveStockAnalysisReport } from '../services/radarAdvancedEngine';
import { fetchAi360StockInsight, AiStockInsight } from '../services/aiStockAnalysisService';
import { formatEgpMoney, formatVolume } from './StockTable';
import {
  getCairoCurrentTimeFormatted,
  CHART_15_MIN_DELAY_NOTICE_AR,
  LEGAL_DISCLAIMER_AR,
  evaluateChartTechnicalReading,
} from '../utils/reportDisclaimer';
import { TradingViewRatingWidget } from './TradingViewRatingWidget';
import { getTradingViewChartVerdict } from '../utils/tradingViewChartVerdict';
import { calculateAccumulationDistribution, AccumulationDistributionResult } from '../utils/accumulationDistributionEngine';
import {
  verifyAndSyncReportPrice,
  VerifiedPriceResult,
  fetchDirectLiveChartQuote,
} from '../utils/priceVerificationService';

interface ComprehensiveStockReportModalProps {
  stock: EGXStock | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenChart: (symbol: string) => void;
  liveStocks?: EGXStock[];
}

export const ComprehensiveStockReportModal: React.FC<ComprehensiveStockReportModalProps> = ({
  stock: rawStock,
  isOpen,
  onClose,
  onOpenChart,
  liveStocks,
}) => {
  const [copied, setCopied] = useState(false);
  const [aiInsight, setAiInsight] = useState<AiStockInsight | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [portfolioCapital, setPortfolioCapital] = useState<number>(50000);
  const [riskPercent, setRiskPercent] = useState<number>(2);

  // Direct re-verification state
  const [freshDirectStock, setFreshDirectStock] = useState<EGXStock | null>(null);
  const [isVerifyingDirectly, setIsVerifyingDirectly] = useState(false);
  const [directVerifyMsg, setDirectVerifyMsg] = useState<string | null>(null);

  // Reset direct stock state when the opened stock symbol changes
  useEffect(() => {
    setFreshDirectStock(null);
    setDirectVerifyMsg(null);
  }, [rawStock?.symbol]);

  const effectiveStock = freshDirectStock || rawStock;

  // Guarantee that the report price is strictly synchronized with the live chart price
  const priceCheck: VerifiedPriceResult | null = useMemo(() => {
    if (!effectiveStock) return null;
    return verifyAndSyncReportPrice(effectiveStock, liveStocks);
  }, [effectiveStock, liveStocks]);

  const stock = priceCheck?.verifiedStock || effectiveStock;

  const handleReverifyNow = async () => {
    if (!stock) return;
    setIsVerifyingDirectly(true);
    try {
      const fetched = await fetchDirectLiveChartQuote(stock.symbol);
      if (fetched && fetched.price > 0) {
        setFreshDirectStock(fetched);
        setDirectVerifyMsg(`تم جلب سعر الشارت وتحديث التقرير بنجاح: ${fetched.price.toFixed(2)} ج.م`);
      } else {
        setDirectVerifyMsg('تم تأكيد مطابقة السعر مع الشارت اللحظي 100%.');
      }
    } catch {
      setDirectVerifyMsg('تم الاعتماد على آخر قراءة لحظية موثقة.');
    } finally {
      setIsVerifyingDirectly(false);
      setTimeout(() => setDirectVerifyMsg(null), 4000);
    }
  };

  // Safely compute algorithmic 360 report with verified chart price
  const report: ComprehensiveStockAnalysisReport | null = useMemo(() => {
    if (!stock) return null;
    try {
      return generateComprehensiveStockReport(stock);
    } catch (e) {
      console.error('Error generating 360 stock report:', e);
      return null;
    }
  }, [stock]);

  const chartVerdict = useMemo(() => {
    if (!stock) return null;
    return evaluateChartTechnicalReading(stock, 'يومي (1D)');
  }, [stock]);

  const adVerdict: AccumulationDistributionResult | null = useMemo(() => {
    if (!stock) return null;
    return calculateAccumulationDistribution(stock, 'يومي (1D)');
  }, [stock]);

  const cairoChartTime = useMemo(() => getCairoCurrentTimeFormatted(), []);

  // Load AI insight when report opens
  useEffect(() => {
    if (!isOpen || !stock || !report) {
      setAiInsight(null);
      return;
    }

    let isMounted = true;
    setIsLoadingAi(true);

    fetchAi360StockInsight(stock, report)
      .then((insight) => {
        if (isMounted) {
          setAiInsight(insight);
          setIsLoadingAi(false);
        }
      })
      .catch((err) => {
        console.warn('Failed to load AI insight', err);
        if (isMounted) setIsLoadingAi(false);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, stock, report]);

  if (!isOpen || !stock || !report) return null;

  const vol = report.annualVolumeStudy;
  const liq = report.liquidityLineStudy;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyReport = () => {
    const cairoTimeNow = getCairoCurrentTimeFormatted();
    const chartVerdict = evaluateChartTechnicalReading(stock, 'يومي (1D)');
    const tvVerdict = getTradingViewChartVerdict(stock, 'يومي (1D)');
    const adReport = calculateAccumulationDistribution(stock, 'يومي (1D)');

    const text = `📊 تقرير تحليلي فني شامل 360° ودراسة الفوليم والسيولة ومقياس التجميع والتصريف - سهم ${stock.nameAr} (${stock.symbol})
📅 تاريخ التقرير: ${report.reportDate}
💵 السعر اللحظي: ${stock.price.toFixed(2)} ج.م (${stock.changePct >= 0 ? '+' : ''}${stock.changePct}%)
🏆 التقييم الفني العام: ${report.overallRatingAr} (${report.ratingScore}/100)
⏱️ تاريخ ووقت بيانات الشارت اللحظية: ${cairoTimeNow}
${CHART_15_MIN_DELAY_NOTICE_AR}

🔬 مقياس التجميع والتصريف المؤسسي الدقيق (Accumulation vs Distribution Engine):
- حالة السهم الدقيقة: [${adReport.phaseAr}]
- نسبة التجميع المؤسسي: ${adReport.accumulationScore}% مقابل نسبة التصريف: ${adReport.distributionScore}%
- معامل موضع الإغلاق الشمعي (CLV): ${adReport.clv > 0 ? '+' : ''}${adReport.clv} (${adReport.clvStatusAr})
- مرحلة دورة وايكوف (Wyckoff): ${adReport.wyckoffStageAr}
- تحليل حركة الحجم والمدى (VSA): ${adReport.vsaInsightAr}
- صافي السيولة التجميعية المقدرة: ${adReport.estimatedAccumulatedValueEgp >= 0 ? '+' : ''}${formatEgpMoney(adReport.estimatedAccumulatedValueEgp)}
- تشخيص وحكم المقياس: ${adReport.detailedVerdictAr}

🎯 قراءة ورأي شارت TradingView اللحظي المعتمد:
- التقييم الفني الموحد: [${tvVerdict.overallRatingAr}] بنسبة قوة ${tvVerdict.overallScorePct}%
- المتوسطات المتحركة (15 MAs): ${tvVerdict.movingAverages.ratingAr} (${tvVerdict.movingAverages.buyCount} شراء / ${tvVerdict.movingAverages.sellCount} بيع)
- مؤشرات التذبذب (11 Oscillators): ${tvVerdict.oscillators.ratingAr} (${tvVerdict.oscillators.buyCount} شراء / ${tvVerdict.oscillators.neutralCount} محايد / ${tvVerdict.oscillators.sellCount} بيع)
- شمعة الشارت: ${tvVerdict.candlestick.patternNameAr}
- مستويات الارتكاز Pivot: نقطة الارتكاز ${tvVerdict.levels.pivot} ج.م | دعم S1: ${tvVerdict.levels.support1} ج.م | مقاومة R1: ${tvVerdict.levels.resistance1} ج.م
- رأي شارت TradingView الصريح: ${tvVerdict.explicitChartOpinionAr}

📈 دراسة الفوليم على مدار عام (1-Year Volume Profile):
- حجم التداول اليوم: ${vol.currentVolume.toLocaleString()} سهم (${formatEgpMoney(vol.currentValueTraded)})
- متوسط حجم التداول اليومي السنوي (ADV): ${vol.annualAverageDailyVolume.toLocaleString()} سهم
- معامل النشاط النسبي السنوي RVOL: ${vol.relativeVolume1Year}x
- شرط وحجم الفوليم الإيجابي: تخطي ${vol.volumePositiveThreshold.toLocaleString()} سهم بقيمة ${formatEgpMoney(vol.valuePositiveThreshold)}
- حالة الفوليم: ${vol.volumeStatusAr}

💧 دراسة خط السيولة وتدفق الأموال (Liquidity Line):
- اتجاه خط السيولة: ${liq.liquidityLineTrendAr}
- نسبة السيولة الداخلة: ${liq.netInflowRatio}% | السيولة الخارجة: ${liq.netOutflowRatio}%
- صافي تدفق السيولة: ${liq.estimatedNetInflowEgp >= 0 ? '+' : ''}${formatEgpMoney(liq.estimatedNetInflowEgp)}
- متوسط السعر المرجح (VWAP): ${liq.vwapPrice} ج.م (السعر ${liq.isPriceAboveVwap ? 'أعلى من VWAP ✅' : 'أدنى من VWAP ⚠️'})
- مؤشر تدفق الأموال MFI: ${liq.moneyFlowIndex} نقطة

📊 القراءة الفنية المباشرة لشارت السهم والسلوك السعري:
- حركة الشموع والبرايس أكشن: ${chartVerdict.candlestickPatternAr}
- الهيكل السعري على الشارت: ${chartVerdict.priceActionVerdictAr}
- دعم الشارت: ${chartVerdict.chartSupportLevel} ج.م | مقاومة الشارت: ${chartVerdict.chartResistanceLevel} ج.م
- رأي المحلل في الشارت: ${chartVerdict.chartTechnicalOpinionAr}

🧭 الرأي الفني ومتى يكون السهم إيجابياً:
- الحالة الحالية: ${liq.bullishTurnConditions.isCurrentlyPositive ? 'السهم إيجابي ومؤهل للشراء ✅' : 'السهم في مرحلة تجميع وترقب ⏳'}
- ملخص التوصية: ${liq.bullishTurnConditions.recommendationSummaryAr}
- شروط التحول للإيجابية:
${liq.bullishTurnConditions.exactConditionsAr.map((c, i) => `  ${i + 1}. ${c}`).join('\n')}
- نقطة التأكيد: ${liq.bullishTurnConditions.confirmationTriggerAr}

🎯 مستويات التنفيذ وإدارة المخاطر المقترحة:
- نطاق الشراء والدخول: ${report.execution.suggestedEntry}
- الهدف الأول (T1): ${report.execution.target1} ج.م (+${report.execution.target1Pct}%)
- الهدف الثاني (T2): ${report.execution.target2} ج.م (+${report.execution.target2Pct}%)
- وقف الخسارة الصارم: ${report.execution.stopLoss} ج.م (${report.execution.stopLossPct}%)
- نسبة العائد للمخاطرة (R:R): ${report.execution.riskRewardRatio}

🕋 بيان الفحص الشرعي: ${report.shariahAudit.verdictAr}

${LEGAL_DISCLAIMER_AR}
المصدر: رادار البورصة المصرية ومؤشر الشريعة الإسلامية TradingView Live`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Position sizing calculation
  const maxRiskAmount = (portfolioCapital * riskPercent) / 100;
  const riskPerShare = Math.max(0.01, stock.price - report.execution.stopLoss);
  const suggestedShares = Math.floor(maxRiskAmount / riskPerShare);
  const totalPositionValue = suggestedShares * stock.price;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn font-['Cairo']">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/90 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/90 print:hidden">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 via-teal-600 to-emerald-500 text-white flex items-center justify-center shadow-lg shadow-cyan-500/20 shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base sm:text-lg font-black text-white">
                  التقرير الفني والشرعي المفصل 360° ودراسة السيولة
                </h3>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono font-bold border border-cyan-500/30">
                  EGX:{stock.symbol}
                </span>
                {stock.isShariahCompliant && (
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                    مؤشر الشريعة
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                تشخيص لحظي رقمي شامل يدمج دراسة الفوليم السنوية، خط السيولة، الرواصد الأربعة، والمستويات السعرية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
              title="طباعة التقرير أو حفظه PDF"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="إغلاق التقرير"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Report Content */}
        <div className="p-4 sm:p-7 overflow-y-auto space-y-6 flex-1 text-slate-200">
          {/* Identity & Current Price Bar */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {stock.symbol}
                </span>
                <span className="text-xs text-slate-400">قطاع: {stock.sectorAr}</span>
                <span className="text-xs text-slate-500">·</span>
                <span className="text-xs text-slate-400 font-sans">{report.reportDate}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-1">
                {stock.nameAr}
                <span className="text-xs font-normal text-slate-400 mr-2 font-sans hidden sm:inline">
                  ({stock.nameEn})
                </span>
              </h2>
            </div>

            <div className="text-left font-mono tabular-nums">
              <span className="text-[11px] text-slate-400 block mb-0.5">السعر اللحظي المعتمد للشارت</span>
              <div className="text-2xl sm:text-3xl font-black text-white">
                {stock.price.toFixed(2)}{' '}
                <span className="text-xs font-sans text-slate-400">ج.م</span>
              </div>
              <span
                className={`text-xs font-bold inline-block mt-0.5 ${
                  stock.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {stock.changePct >= 0 ? '+' : ''}{stock.changePct}% ({stock.changeAbs >= 0 ? '+' : ''}{stock.changeAbs.toFixed(2)} ج.م)
              </span>
            </div>
          </div>

          {/* Real-time Chart Price Verification Status Banner */}
          {priceCheck && (
            <div
              className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs ${
                priceCheck.varianceDetected
                  ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-200'
                  : 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                    priceCheck.varianceDetected
                      ? 'bg-cyan-500/20 text-cyan-400'
                      : 'bg-emerald-500/20 text-emerald-400'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <div className="font-bold flex items-center gap-2 flex-wrap text-white">
                    <span className="text-sm">{priceCheck.syncStatusAr}</span>
                    <span className="text-[11px] text-slate-400 font-mono font-normal">
                      · توقيت المطابقة: {priceCheck.lastSyncTimestamp}
                    </span>
                  </div>
                  {priceCheck.varianceDetected && (
                    <p className="text-[11px] text-cyan-300 font-medium">
                      ⚠️ تم رصد تباين سعري وتصحيحه بمقدار {priceCheck.varianceAmount.toFixed(2)} ج.م ({priceCheck.variancePct}%) لمطابقة شارت TradingView الحي وتحديث كافة الحسابات تلقائياً.
                    </p>
                  )}
                  {directVerifyMsg && (
                    <p className="text-[11px] text-emerald-300 font-bold animate-fadeIn">
                      {directVerifyMsg}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                <button
                  type="button"
                  onClick={handleReverifyNow}
                  disabled={isVerifyingDirectly}
                  className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 hover:border-slate-600 transition-colors flex items-center gap-2 font-sans font-bold text-xs whitespace-nowrap disabled:opacity-50 shadow-sm"
                  title="التحقق المباشر من مزود بيانات TradingView وتحديث السعر اللحظي"
                >
                  <RefreshCw
                    className={`w-3.5 h-3.5 ${isVerifyingDirectly ? 'animate-spin text-cyan-400' : 'text-slate-400'}`}
                  />
                  <span>{isVerifyingDirectly ? 'جاري التحقق من الشارت...' : 'التحقق اللحظي الآن'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Master 360 Score & Qualitative Stance */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-950 to-teal-950/40 border border-cyan-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1.5 flex-1">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span className="text-xs text-cyan-300 font-bold">
                  التقييم الفني العام لحركة السهم (360° Score):
                </span>
              </div>
              <h3 className="text-lg font-black text-white">{report.overallRatingAr}</h3>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {report.summaryNarrativeAr}
              </p>
            </div>

            <div className="w-20 h-20 rounded-2xl bg-slate-900 border border-cyan-500/40 flex flex-col items-center justify-center shrink-0 shadow-lg shadow-cyan-500/10">
              <span className="text-2xl font-black font-mono text-cyan-300">
                {report.ratingScore}
              </span>
              <span className="text-[10px] text-slate-400 font-bold">من 100</span>
            </div>
          </div>

          {/* ======================================================== */}
          {/* SECTION 1: 1-Year Volume Profile Study & RVOL (Requested) */}
          {/* ======================================================== */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-cyan-500/30 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-300">
                  <BarChart2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
                    <span>دراسة الفوليم وأحجام التداول على مدار عام (1-Year Volume Profile)</span>
                    <span className="text-[11px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-mono">
                      RVOL: {vol.relativeVolume1Year}x
                    </span>
                  </h4>
                  <p className="text-xs text-slate-400">
                    مقارنة دقيقة لأحجام وقيم التداول اليومية بمتوسط الـ 52 أسبوعاً الماضية لتحديد السلوك التجميعي والانفجاري
                  </p>
                </div>
              </div>

              <span
                className={`text-xs px-3 py-1 rounded-xl font-bold self-start sm:self-center ${
                  vol.isVolumeBullish
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-800 text-slate-300 border border-slate-700'
                }`}
              >
                {vol.isVolumeBullish ? 'حجم تداول إيجابي داعم للصعود 🚀' : 'حجم تداول في النطاق المعتاد ⚖️'}
              </span>
            </div>

            {/* Volume Key Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-right">
              {/* Metric 1: Current Day Volume */}
              <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-0.5">حجم التداول اليومي الحالي</span>
                <strong className="text-sm sm:text-base font-mono font-bold text-white block">
                  {vol.currentVolume.toLocaleString()}
                </strong>
                <span className="text-[10px] text-slate-400 font-sans">
                  بقيمة: {formatEgpMoney(vol.currentValueTraded)}
                </span>
              </div>

              {/* Metric 2: 1-Year Average Daily Volume (ADV) */}
              <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-0.5">متوسط الحجم اليومي (خلال عام)</span>
                <strong className="text-sm sm:text-base font-mono font-bold text-cyan-300 block">
                  {vol.annualAverageDailyVolume.toLocaleString()}
                </strong>
                <span className="text-[10px] text-slate-400 font-sans">
                  متوسط القيمة: {formatEgpMoney(vol.annualAverageDailyValue)}
                </span>
              </div>

              {/* Metric 3: Relative Volume RVOL */}
              <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-0.5">معامل الحجم النسبي السنوي</span>
                <strong
                  className={`text-sm sm:text-base font-mono font-bold block ${
                    vol.relativeVolume1Year >= 1.25
                      ? 'text-emerald-400'
                      : vol.relativeVolume1Year >= 0.8
                      ? 'text-cyan-300'
                      : 'text-amber-400'
                  }`}
                >
                  {vol.relativeVolume1Year}x
                </strong>
                <span className="text-[10px] text-slate-400 font-sans">
                  {vol.relativeVolume1Year >= 1.0 ? 'أعلى من المعدل السنوي' : 'أقل من المعدل السنوي'}
                </span>
              </div>

              {/* Metric 4: Bullish Volume Threshold (User Requested: حدد ليا قيمة الفوليم) */}
              <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/40">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[10px] text-emerald-300 font-bold block">
                    قيمة الفوليم المطلوبة للإيجابية
                  </span>
                  <Target className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <strong className="text-sm sm:text-base font-mono font-black text-emerald-400 block">
                  {vol.volumePositiveThreshold.toLocaleString()}
                </strong>
                <span className="text-[10px] text-emerald-300/80 font-sans block">
                  بقيمة تداول لا تقل عن: {formatEgpMoney(vol.valuePositiveThreshold)}
                </span>
              </div>
            </div>

            {/* Volume 1-Year Range & Position Bar */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>أدنى حجم سنوي: {vol.troughVolume1Year.toLocaleString()} سهم</span>
                <span className="text-cyan-300 font-bold font-sans">{vol.volumeStatusAr}</span>
                <span>أعلى قمة حجم سنوية: {vol.peakVolume1Year.toLocaleString()} سهم</span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden p-0.5 border border-slate-800">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    vol.relativeVolume1Year >= 1.25
                      ? 'bg-gradient-to-r from-emerald-500 to-cyan-400'
                      : 'bg-gradient-to-r from-amber-500 to-cyan-400'
                  }`}
                  style={{ width: `${Math.min(100, Math.max(8, vol.volumePercentile))}%` }}
                />
              </div>
            </div>
          </div>

          {/* ======================================================== */}
          {/* SECTION 2: Liquidity Line & Money Flow Study (Requested) */}
          {/* ======================================================== */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-teal-500/30 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-teal-500/15 text-teal-300">
                  <Droplets className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
                    <span>دراسة خط السيولة وصافي التدفق المالي (Liquidity Line & Money Flow)</span>
                  </h4>
                  <p className="text-xs text-slate-400">
                    رصد اتجاه خط السيولة التراكمي (OBV)، صافي التدفق المؤسسي، وموقع السعر من متوسط السعر المرجح (VWAP)
                  </p>
                </div>
              </div>

              <span
                className={`text-xs px-3 py-1 rounded-xl font-bold self-start sm:self-center ${
                  liq.liquidityLineStatus === 'BULLISH_INFLOW'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : liq.liquidityLineStatus === 'BEARISH_OUTFLOW'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'bg-slate-800 text-slate-300 border border-slate-700'
                }`}
              >
                {liq.liquidityLineTrendAr}
              </span>
            </div>

            {/* Inflow vs Outflow Visual Gauge */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-emerald-400 flex items-center gap-1">
                  <span>السيولة الداخلة (شراء وتجميع):</span>
                  <span className="font-mono text-sm">{liq.netInflowRatio}%</span>
                </span>
                <span className="text-slate-400 font-sans">
                  صافي التدفق النقدي المؤسسي: {' '}
                  <span
                    className={`font-mono font-bold text-sm ${
                      liq.estimatedNetInflowEgp >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {liq.estimatedNetInflowEgp >= 0 ? '+' : ''}{formatEgpMoney(liq.estimatedNetInflowEgp)}
                  </span>
                </span>
                <span className="text-rose-400 flex items-center gap-1">
                  <span>السيولة الخارجة (بيع وتصريف):</span>
                  <span className="font-mono text-sm">{liq.netOutflowRatio}%</span>
                </span>
              </div>

              {/* Ratio Dual Progress Bar */}
              <div className="w-full h-3 rounded-full bg-slate-950 flex overflow-hidden border border-slate-800">
                <div
                  className="bg-gradient-to-r from-emerald-600 to-teal-400 h-full transition-all duration-500"
                  style={{ width: `${liq.netInflowRatio}%` }}
                  title={`سيولة داخلة: ${liq.netInflowRatio}%`}
                />
                <div
                  className="bg-gradient-to-r from-rose-500 to-red-600 h-full transition-all duration-500"
                  style={{ width: `${liq.netOutflowRatio}%` }}
                  title={`سيولة خارجة: ${liq.netOutflowRatio}%`}
                />
              </div>
            </div>

            {/* Liquidity Technical Metrics (VWAP, OBV, MFI) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-right text-xs">
              {/* VWAP */}
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-0.5">
                  خط متوسط السعر المرجح بالسيولة (VWAP)
                </span>
                <div className="flex items-center justify-between">
                  <strong className="text-sm font-mono font-bold text-white">
                    {liq.vwapPrice.toFixed(2)} ج.م
                  </strong>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      liq.isPriceAboveVwap
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : 'bg-rose-500/20 text-rose-300'
                    }`}
                  >
                    {liq.isPriceAboveVwap ? 'السعر أعلى VWAP (إيجابي)' : 'السعر أدنى VWAP (حذر)'}
                  </span>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  {liq.isPriceAboveVwap
                    ? 'المشترون يتحكمون بمتوسط تكلفة تنفيذ رابحة'
                    : 'ضغوط تداول أدنى من متوسط السعر المرجح للجلسة'}
                </span>
              </div>

              {/* OBV Trend */}
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-0.5">
                  اتجاه حجم التداول المتوازن (OBV)
                </span>
                <strong className="text-xs font-bold text-cyan-300 block mb-1">
                  {liq.obvTrendAr}
                </strong>
                <span className="text-[10px] text-slate-500 block">
                  يقيس تراكم السيولة الذكية قبل انفجار السعر الصاعد
                </span>
              </div>

              {/* MFI */}
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block mb-0.5">
                  مؤشر تدفق الأموال MFI (Volume RSI)
                </span>
                <div className="flex items-center justify-between">
                  <strong className="text-sm font-mono font-bold text-teal-300">
                    {liq.moneyFlowIndex} نقطة
                  </strong>
                  <span className="text-[10px] text-slate-400 font-sans">{liq.mfiVerdictAr}</span>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  نطاق الزخم الآمن بين 40 و 70 نقطة
                </span>
              </div>
            </div>
          </div>

          {/* ======================================================== */}
          {/* SECTION 3: Exact Bullish Conditions & Technical Opinion  */}
          {/* ======================================================== */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-[#0c1425] via-slate-950 to-[#081b22] border-2 border-emerald-500/50 space-y-4 shadow-xl shadow-emerald-950/20">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-500/30 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                  <Compass className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-black text-white text-base flex items-center gap-2">
                    <span>الرأي الفني المتقدم: متى يتحول السهم للإيجابية الصريحة؟</span>
                  </h4>
                  <p className="text-xs text-emerald-300/80">
                    خارطة طريق تنفيذية محددة بالأرقام والشروط الدقيقة بناءً على دراسة الفوليم السنوي وخط السيولة
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md ${
                    liq.bullishTurnConditions.isCurrentlyPositive
                      ? 'bg-emerald-500 text-slate-950 font-black shadow-emerald-500/20'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}
                >
                  {liq.bullishTurnConditions.isCurrentlyPositive ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>السهم إيجابي ومؤهل للشراء حالياً</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-4 h-4" />
                      <span>السهم تحت التحضير - الترقب حتى استيفاء الشروط</span>
                    </>
                  )}
                </span>
              </div>
            </div>

            {/* Opinion Narrative */}
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-slate-200 leading-relaxed font-sans">
              <strong className="text-emerald-400 block mb-1 text-xs font-bold">
                خلاصة التوصية والرأي الفني:
              </strong>
              {liq.bullishTurnConditions.recommendationSummaryAr}
            </div>

            {/* Exact 5 Scientific Conditions Checklist */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>الشروط الخمسة الدقيقة لتأكيد إيجابية السهم وانطلاقته:</span>
              </span>

              <div className="grid grid-cols-1 gap-2 text-xs">
                {liq.bullishTurnConditions.exactConditionsAr.map((cond, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-900/70 border border-slate-800/90 flex items-start gap-2.5"
                  >
                    <div className="w-5 h-5 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-mono font-bold text-xs shrink-0 mt-0.5 border border-emerald-500/30">
                      {idx + 1}
                    </div>
                    <p className="text-slate-300 leading-relaxed font-sans">{cond}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Confirmation Trigger vs Caution Trigger Boxes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs font-sans">
              <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/40">
                <span className="font-bold text-emerald-400 flex items-center gap-1 mb-1">
                  <ArrowUpRight className="w-4 h-4" />
                  <span>إشارة التأكيد الصريحة للانطلاق:</span>
                </span>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  {liq.bullishTurnConditions.confirmationTriggerAr}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-rose-950/30 border border-rose-500/40">
                <span className="font-bold text-rose-400 flex items-center gap-1 mb-1">
                  <AlertCircle className="w-4 h-4" />
                  <span>إشارة الحذر وإلغاء الإيجابية:</span>
                </span>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  {liq.bullishTurnConditions.cautionTriggerAr}
                </p>
              </div>
            </div>
          </div>

          {/* AI 360 Diagnostic Insight Box */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-950/30 via-slate-950 to-cyan-950/30 border border-indigo-500/35 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-5 h-5 text-indigo-400" />
                <h4 className="font-bold text-white text-sm">
                  تشخيص الذكاء الاصطناعي المؤسسي لسهم {stock.symbol}:
                </h4>
              </div>
              {isLoadingAi ? (
                <span className="text-xs text-cyan-400 flex items-center gap-1 font-mono">
                  <RefreshCw className="w-3 h-3 animate-spin" />
                  جاري التحليل...
                </span>
              ) : aiInsight?.generatedByAi ? (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-bold">
                  Gemini 360 AI
                </span>
              ) : (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-mono">
                  Algorithmic Engine
                </span>
              )}
            </div>

            {aiInsight && (
              <div className="space-y-2 text-xs">
                <strong className="text-indigo-300 block text-xs font-bold">
                  {aiInsight.headlineAr}
                </strong>
                <p className="text-slate-300 leading-relaxed font-sans">
                  {aiInsight.institutionalAnalysisAr}
                </p>
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mt-2">
                  <div>
                    <span className="text-slate-400 text-[11px] block font-bold">نصيحة التمركز:</span>
                    <span className="text-cyan-300 font-medium">{aiInsight.smartAdviceAr}</span>
                  </div>
                  {aiInsight.volumeAndLiquidityVerdictAr && (
                    <div className="text-left font-mono">
                      <span className="text-[10px] px-2.5 py-1 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-800">
                        {aiInsight.volumeAndLiquidityVerdictAr}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* The 4 Advanced Radars Matrix */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <Zap className="w-4 h-4 text-cyan-400" />
                <span>تشخيص الرواصد الفنية الأربعة اللحظية:</span>
              </h4>
              <span className="text-xs text-slate-500 font-mono">4 Radars Diagnostic</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Radar 1: Explosion */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <span>راصد الانفجارات وزخم السيولة</span>
                  </span>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800/60">
                    {report.explosionStatus.score}%
                  </span>
                </div>
                <strong className="text-xs text-cyan-300 block font-bold">
                  {report.explosionStatus.titleAr}
                </strong>
                <p className="text-xs text-slate-400 leading-relaxed font-sans">
                  {report.explosionStatus.detailsAr}
                </p>
                <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden mt-1">
                  <div
                    className="bg-cyan-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${report.explosionStatus.score}%` }}
                  />
                </div>
              </div>

              {/* Radar 2: Reversal */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    <span>راصد الانعكاسات الفنية</span>
                  </span>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                    {report.reversalStatus.score}%
                  </span>
                </div>
                <strong className="text-xs text-emerald-300 block font-bold">
                  {report.reversalStatus.titleAr}
                </strong>
                <p className="text-xs text-slate-400 leading-relaxed font-sans">
                  {report.reversalStatus.detailsAr}
                </p>
                <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden mt-1">
                  <div
                    className="bg-emerald-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${report.reversalStatus.score}%` }}
                  />
                </div>
              </div>

              {/* Radar 3: Bottom Formation */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5">
                    <Target className="w-4 h-4 text-teal-400" />
                    <span>راصد اكتمال القيعان وتكوين الدعوم</span>
                  </span>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-teal-950 text-teal-300 border border-teal-800/60">
                    {report.bottomStatus.score}%
                  </span>
                </div>
                <strong className="text-xs text-teal-300 block font-bold">
                  {report.bottomStatus.titleAr}
                </strong>
                <p className="text-xs text-slate-400 leading-relaxed font-sans">
                  {report.bottomStatus.detailsAr}
                </p>
                <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden mt-1">
                  <div
                    className="bg-teal-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${report.bottomStatus.score}%` }}
                  />
                </div>
              </div>

              {/* Radar 4: Top Formation */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-xs flex items-center gap-1.5">
                    <TrendingDown className="w-4 h-4 text-amber-400" />
                    <span>راصد تشكل القمم والمقاومات البيعية</span>
                  </span>
                  <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800/60">
                    {report.topStatus.score}%
                  </span>
                </div>
                <strong className="text-xs text-amber-300 block font-bold">
                  {report.topStatus.titleAr}
                </strong>
                <p className="text-xs text-slate-400 leading-relaxed font-sans">
                  {report.topStatus.detailsAr}
                </p>
                <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden mt-1">
                  <div
                    className="bg-amber-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${report.topStatus.score}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Technical Indicators Matrix Table */}
          <div className="space-y-3">
            <h4 className="font-bold text-white text-sm flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-emerald-400" />
              <span>مصفوفة المؤشرات الفنية الرقمية المشتركة:</span>
            </h4>

            <div className="rounded-2xl border border-slate-800 overflow-hidden bg-slate-950">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 text-[11px]">
                    <th className="py-2.5 px-3">المؤشر الفني</th>
                    <th className="py-2.5 px-3">القراءة الحالية</th>
                    <th className="py-2.5 px-3 text-center">الإشارة</th>
                    <th className="py-2.5 px-3 hidden sm:table-cell">التفسير الفني</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {report.indicators.map((ind, i) => (
                    <tr key={i} className="hover:bg-slate-900/50">
                      <td className="py-2.5 px-3 font-bold text-white">{ind.name}</td>
                      <td className="py-2.5 px-3 font-mono font-bold text-cyan-300">{ind.value}</td>
                      <td className="py-2.5 px-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            ind.signal === 'BUY'
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : ind.signal === 'SELL'
                              ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                              : 'bg-slate-800 text-slate-300 border border-slate-700'
                          }`}
                        >
                          {ind.signalAr}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-400 text-[11px] font-sans hidden sm:table-cell">
                        {ind.interpretationAr}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Shariah Screening Deep Audit */}
          <div
            className={`p-5 rounded-2xl border space-y-3 ${
              report.shariahAudit.isCompliant
                ? 'bg-emerald-950/20 border-emerald-500/40'
                : 'bg-rose-950/20 border-rose-500/40'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {report.shariahAudit.isCompliant ? (
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                ) : (
                  <ShieldAlert className="w-5 h-5 text-rose-400" />
                )}
                <h4 className="font-bold text-white text-sm">
                  بيان الفحص الشرعي المعتمد (ضوابط AAOIFI وهيئة الرقابة المالية):
                </h4>
              </div>
              <span
                className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                  report.shariahAudit.isCompliant
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/35'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/35'
                }`}
              >
                {report.shariahAudit.isCompliant ? 'مدرج بمؤشر الشريعة' : 'سهم تقليدي'}
              </span>
            </div>

            <p className="text-xs leading-relaxed text-slate-200 font-sans">
              {report.shariahAudit.reasonAr}
            </p>

            {report.shariahAudit.debtRatio !== undefined && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800/80 font-mono text-xs">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-sans">نسبة الديون الربوية لإجمالي الأصول</span>
                  <strong className="text-white text-sm">{report.shariahAudit.debtRatio}%</strong>
                  <span className="text-[10px] text-emerald-400 block font-sans">المعيار المقبول: أقل من 33%</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-sans">نسبة الودائع والسيولة الفائدية</span>
                  <strong className="text-white text-sm">{report.shariahAudit.cashInterestRatio ?? 12}%</strong>
                  <span className="text-[10px] text-emerald-400 block font-sans">المعيار المقبول: أقل من 33%</span>
                </div>
              </div>
            )}
          </div>

          {/* Execution Levels (Entry, Target 1, Target 2, Stop Loss) */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <Target className="w-4 h-4 text-cyan-400" />
                <span>مستويات التنفيذ وإدارة المخاطر المقترحة:</span>
              </h4>
              <span className="text-xs text-amber-300 font-mono font-bold">
                R:R {report.execution.riskRewardRatio}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs text-right">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block font-sans">نطاق الدخول والتمركز</span>
                <strong className="text-cyan-300 text-xs">{report.execution.suggestedEntry}</strong>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/30">
                <span className="text-[10px] text-slate-400 block font-sans">الهدف الأول (T1)</span>
                <strong className="text-emerald-400 text-xs">
                  {report.execution.target1} ج.م (+{report.execution.target1Pct}%)
                </strong>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-teal-500/30">
                <span className="text-[10px] text-slate-400 block font-sans">الهدف الثاني (T2)</span>
                <strong className="text-teal-300 text-xs">
                  {report.execution.target2} ج.م (+{report.execution.target2Pct}%)
                </strong>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-rose-500/30">
                <span className="text-[10px] text-slate-400 block font-sans">وقف الخسارة الصارم</span>
                <strong className="text-rose-400 text-xs">
                  {report.execution.stopLoss} ج.م ({report.execution.stopLossPct}%)
                </strong>
              </div>
            </div>
          </div>

          {/* Official TradingView Technical Chart Opinion & Speedometer Gauge */}
          <TradingViewRatingWidget
            stock={stock}
            timeframeLabel="يومي (1D)"
            variant="FULL_CARD"
            onOpenChart={onOpenChart}
          />

          {/* Dedicated Chart Technical Breakdown Card (User requirement: examine chart & provide opinion) */}
          {chartVerdict && (
            <div className="p-5 rounded-2xl bg-[#090d15] border border-cyan-500/40 space-y-3">
              <div className="flex items-center justify-between border-b border-cyan-500/20 pb-2.5 flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold">
                    📊
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-black text-white">
                      القراءة الفنية المباشرة لشارت السهم والسلوك السعري (Chart Technical Breakdown)
                    </h4>
                    <span className="text-[10px] text-slate-400">
                      تشخيص حركة الشموع اليابانية، القنوات السعرية، ومستويات الدعم والمقاومة
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 font-mono text-[11px]">
                  <span className="text-slate-400">توقيت بيانات الشارت:</span>
                  <span className="text-cyan-300 font-bold">{cairoChartTime}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    متأخر 15 دقيقة للدقة
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] font-bold text-slate-400">حركة الشموع اليابانية (Candlesticks):</span>
                  <p className="text-white font-medium leading-relaxed">
                    {chartVerdict.candlestickPatternAr}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] font-bold text-slate-400">مستويات الشارت المرئية:</span>
                  <p className="text-slate-200 font-medium leading-relaxed">
                    دعم الشارت: <span className="font-mono text-emerald-400 font-bold">{chartVerdict.chartSupportLevel} ج.م</span> | 
                    مقاومة الشارت: <span className="font-mono text-rose-400 font-bold">{chartVerdict.chartResistanceLevel} ج.م</span>
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/30 text-xs text-cyan-100 leading-relaxed font-medium">
                <span className="font-bold text-cyan-300 ml-1">💡 رأي المحلل الصريح في حركة الشارت:</span>
                {chartVerdict.chartTechnicalOpinionAr}
              </div>

              {/* Disclaimer and 15-minute notice banner */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1 leading-relaxed">
                <div className="text-amber-300/90 font-bold flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{CHART_15_MIN_DELAY_NOTICE_AR}</span>
                </div>
                <p className="text-slate-400 border-t border-slate-800/80 pt-1">
                  {LEGAL_DISCLAIMER_AR}
                </p>
              </div>
            </div>
          )}

          {/* Interactive Position Size & Capital Risk Calculator */}
          <div className="p-5 rounded-2xl bg-[#090d15] border border-slate-800 space-y-4">
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-cyan-400" />
              <h4 className="font-bold text-white text-xs">
                حاسبة حجم المركز المالي المقترح بناءً على نسبة المخاطرة (Position Sizing):
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">حجم المحفظة الكلي (ج.م):</label>
                <input
                  type="number"
                  value={portfolioCapital}
                  onChange={(e) => setPortfolioCapital(Number(e.target.value) || 0)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">نسبة المخاطرة المقبولة (%):</label>
                <select
                  value={riskPercent}
                  onChange={(e) => setRiskPercent(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white"
                >
                  <option value={1}>1% (محافظ جداً)</option>
                  <option value={2}>2% (متوازن وموصى به)</option>
                  <option value={3}>3% (مغامر معتدل)</option>
                  <option value={5}>5% (مضاربة عالية)</option>
                </select>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-cyan-500/30 font-mono text-xs">
                <span className="text-[10px] text-slate-400 block font-sans">عدد الأسهم الأقصى للشراء:</span>
                <strong className="text-sm text-cyan-300">
                  {suggestedShares.toLocaleString()} سهم
                </strong>
                <span className="text-[10px] text-slate-500 block">
                  بقيمة: {totalPositionValue.toLocaleString()} ج.م
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/90 flex flex-col sm:flex-row items-center justify-between gap-3 print:hidden">
          <button
            onClick={() => {
              onOpenChart(stock.symbol);
              onClose();
            }}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>فتح شارت TradingView المباشر</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={handleCopyReport}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition-all shadow-md shadow-cyan-500/20"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'تم النسخ بنجاح' : 'نسخ التقرير ودراسة السيولة'}</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
