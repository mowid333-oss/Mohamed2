import React, { useState } from 'react';
import {
  Star,
  Bell,
  BellRing,
  ExternalLink,
  Info,
  Check,
  Copy,
  TrendingUp,
  TrendingDown,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  Zap,
  FileText,
  Target,
  Bot,
} from 'lucide-react';
import { EGXStock } from '../types/stock';
import { TradingViewRatingWidget } from './TradingViewRatingWidget';
import { calculateAccumulationDistribution } from '../utils/accumulationDistributionEngine';
import { getEstimated20DayAvgVolume } from '../services/institutionalLiquidityAlertService';
import { FirestoreUserAlert } from '../services/userFirestoreService';
import { QuickAlertPopover } from './QuickAlertPopover';

interface StockTableProps {
  stocks: EGXStock[];
  selectedSymbol: string;
  onSelectStock: (symbol: string) => void;
  favorites: string[];
  onToggleFavorite: (symbol: string) => void;
  onOpenStockDetails: (stock: EGXStock) => void;
  onOpenDetailedReport: (stock: EGXStock) => void;
  onOpenChart: (symbol: string) => void;
  onOpenGoogleAiNews?: (symbol: string) => void;
  onOpenDirectChartAi?: (stock: EGXStock) => void;
  userAlerts?: FirestoreUserAlert[];
  onSaveAlert?: (alert: {
    symbol: string;
    stockNameAr: string;
    condition: FirestoreUserAlert['condition'];
    targetValue: number;
    currentPriceWhenCreated: number;
    isActive: boolean;
    isTriggered: boolean;
    note: string;
  }) => Promise<void> | void;
  onToggleAlert?: (alertId: string, currentActive: boolean) => Promise<void> | void;
  onDeleteAlert?: (alertId: string) => Promise<void> | void;
  isLoggedIn?: boolean;
  onOpenAuthModal?: () => void;
}

export function formatEgpMoney(val?: number): string {
  if (val === undefined || val === null || isNaN(val) || val === 0) return '-';
  if (val >= 1_000_000_000) return `${(val / 1_000_000_000).toFixed(2)} مليار ج.م`;
  if (val >= 1_000_000) return `${(val / 1_000_000).toFixed(1)} مليون ج.م`;
  if (val >= 1_000) return `${(val / 1_000).toFixed(0)} ألف ج.م`;
  return `${val.toLocaleString()} ج.م`;
}

export function formatVolume(vol?: number): string {
  if (vol === undefined || vol === null || isNaN(vol) || vol === 0) return '-';
  if (vol >= 1_000_000) return `${(vol / 1_000_000).toFixed(1)}M`;
  if (vol >= 1_000) return `${(vol / 1_000).toFixed(0)}K`;
  return vol.toLocaleString();
}

export const StockTable: React.FC<StockTableProps> = ({
  stocks,
  selectedSymbol,
  onSelectStock,
  favorites,
  onToggleFavorite,
  onOpenStockDetails,
  onOpenDetailedReport,
  onOpenChart,
  onOpenGoogleAiNews,
  onOpenDirectChartAi,
  userAlerts = [],
  onSaveAlert,
  onToggleAlert,
  onDeleteAlert,
  isLoggedIn = false,
  onOpenAuthModal,
}) => {
  const [copiedSymbol, setCopiedSymbol] = useState<string | null>(null);
  const [alertPopoverStock, setAlertPopoverStock] = useState<EGXStock | null>(null);
  const [alertPopoverAnchor, setAlertPopoverAnchor] = useState<DOMRect | null>(null);

  const handleOpenAlertPopover = (e: React.MouseEvent, s: EGXStock) => {
    e.stopPropagation();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    if (alertPopoverStock?.symbol === s.symbol) {
      setAlertPopoverStock(null);
      setAlertPopoverAnchor(null);
    } else {
      setAlertPopoverStock(s);
      setAlertPopoverAnchor(rect);
    }
  };

  const handleCopyStockSummary = (e: React.MouseEvent, s: EGXStock) => {
    e.stopPropagation();
    const ad = calculateAccumulationDistribution(s, 'يومي (1D)');
    const text = `📊 تقرير سهم ${s.nameAr} (${s.symbol}) - البورصة المصرية EGX:
💵 السعر الحالي: ${s.price.toFixed(2)} ج.م (${s.changePct >= 0 ? '+' : ''}${s.changePct}%)
🕋 الحكم الشرعي: ${s.isShariahCompliant ? 'متوافق مع الشريعة الإسلامية ✅' : 'غير متوافق (تقليدي) ⚠️'}
🔬 مقياس التجميع والتصريف الدقيق: [${ad.phaseAr}] (تجميع ${ad.accumulationScore}% / تصريف ${ad.distributionScore}%)
🏛️ مرحلة دورة وايكوف: ${ad.wyckoffStageAr}
📈 السيولة المتداولة: ${formatEgpMoney(s.valueTraded)} (${formatVolume(s.volume)} سهم)
📐 نطاق اليوم: أدنى ${s.low.toFixed(2)} - أعلى ${s.high.toFixed(2)} ج.م
🏢 القطاع: ${s.sectorAr}
📌 الرأي الشرعي: ${s.shariahReasonAr}
المصدر: رادار البورصة المصرية ومؤشر الشريعة TradingView Live`;

    navigator.clipboard.writeText(text);
    setCopiedSymbol(s.symbol);
    setTimeout(() => setCopiedSymbol(null), 2000);
  };

  if (stocks.length === 0) {
    return (
      <div className="p-12 text-center rounded-2xl bg-slate-900/60 border border-slate-800 text-slate-400 space-y-2">
        <Sparkles className="w-8 h-8 text-slate-600 mx-auto" />
        <p className="font-bold text-sm text-slate-300">لا توجد أسهم مطابقة لمعايير التصفية الحالية</p>
        <p className="text-xs text-slate-500">جرب تغيير التصنيف أو إلغاء فلتر البحث للوصول لكافة أسهم البورصة</p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border border-slate-800/90 bg-[#0a0e17] overflow-hidden shadow-2xl relative">
      <div className="overflow-x-auto">
        <table className="w-full text-right text-xs">
          <thead>
            <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-bold uppercase tracking-wider text-[11px]">
              <th className="py-3 px-2 text-center w-16">المفضلة والتنبيه</th>
              <th className="py-3 px-3">السهم والشركة</th>
              <th className="py-3 px-3 text-center">التوافق الشرعي</th>
              <th className="py-3 px-3 text-left">السعر اللحظي</th>
              <th className="py-3 px-3 text-left">التغير اليومي %</th>
              <th className="py-3 px-3 text-left hidden sm:table-cell">التغير (ج.م)</th>
              <th className="py-3 px-3 text-left">قيمة التداول (السيولة)</th>
              <th className="py-3 px-3 text-center hidden md:table-cell">نطاق التجميع المقترح</th>
              <th className="py-3 px-3 text-center hidden lg:table-cell">نطاق اليوم (أدنى - أعلى)</th>
              <th className="py-3 px-3 text-center">الإجراء والشارت</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {stocks.map((s) => {
              const isSelected = s.symbol === selectedSymbol;
              const isFav = favorites.includes(s.symbol);
              const isPositive = s.changePct > 0;
              const isNegative = s.changePct < 0;

              const matchingAlerts = userAlerts.filter(
                (a) => a.symbol.trim().toUpperCase() === s.symbol.trim().toUpperCase()
              );
              const hasActiveAlert = matchingAlerts.some((a) => a.isActive);

              return (
                <tr
                  key={s.symbol}
                  onClick={() => onSelectStock(s.symbol)}
                  className={`cursor-pointer transition-colors group ${
                    isSelected
                      ? 'bg-emerald-950/25 border-r-4 border-r-emerald-500 hover:bg-emerald-950/35'
                      : 'hover:bg-slate-900/80'
                  }`}
                >
                  {/* Favorite & Alert Bell Toggle */}
                  <td className="py-3 px-2 text-center">
                    <div className="flex items-center justify-center gap-1">
                      {/* Star Button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(s.symbol);
                        }}
                        className="p-1 rounded-lg text-slate-500 hover:text-amber-400 transition-colors"
                        title={isFav ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
                      >
                        <Star
                          className={`w-3.5 h-3.5 ${
                            isFav ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                          }`}
                        />
                      </button>

                      {/* Bell Quick Alert Toggle */}
                      <button
                        type="button"
                        onClick={(e) => handleOpenAlertPopover(e, s)}
                        className={`p-1 rounded-lg transition-all relative ${
                          hasActiveAlert
                            ? 'text-amber-400 bg-amber-500/15 border border-amber-500/40 hover:bg-amber-500/25 shadow-sm shadow-amber-500/20'
                            : 'text-slate-500 hover:text-amber-400 hover:bg-slate-800'
                        }`}
                        title={
                          hasActiveAlert
                            ? `إدارة تنبيهات السعر (${matchingAlerts.length} نشط)`
                            : 'تحديد تنبيه سعر سريع لهذا السهم'
                        }
                      >
                        {hasActiveAlert ? (
                          <>
                            <BellRing className="w-3.5 h-3.5 animate-pulse" />
                            <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-amber-400" />
                          </>
                        ) : (
                          <Bell className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Stock Symbol & Arabic Name */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2.5">
                      <div className="flex flex-col">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-black text-sm text-white group-hover:text-cyan-400 transition-colors">
                            {s.symbol}
                          </span>
                          {s.isInEgx30 && (
                            <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800/60">
                              EGX30
                            </span>
                          )}
                          {s.isInShariahIndex && (
                            <span className="text-[9px] font-mono font-bold px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                              شريعة
                            </span>
                          )}
                          <TradingViewRatingWidget stock={s} variant="MINI_BADGE" />
                          {(() => {
                            const ad = calculateAccumulationDistribution(s, 'يومي (1D)');
                            return (
                              <span
                                className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                                  ad.isAccumulation
                                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35'
                                    : ad.isDistribution
                                    ? 'bg-rose-500/15 text-rose-300 border-rose-500/35'
                                    : 'bg-slate-800 text-slate-400 border-slate-700'
                                }`}
                                title={`مقياس التجميع والتصريف الدقيق: ${ad.phaseAr} (تجميع ${ad.accumulationScore}% / تصريف ${ad.distributionScore}%)`}
                              >
                                {ad.isAccumulation ? 'تجميع 💎' : ad.isDistribution ? 'تصريف 🛑' : 'توازن ⚖️'}
                              </span>
                            );
                          })()}
                        </div>
                        <span className="text-slate-300 text-xs font-semibold truncate max-w-[190px] sm:max-w-[260px] font-['Cairo']">
                          {s.nameAr}
                        </span>
                        <span className="text-slate-500 text-[10px] truncate max-w-[200px]">
                          {s.sectorAr}
                        </span>
                      </div>
                    </div>
                  </td>

                  {/* Shariah Compliance Badge */}
                  <td className="py-3 px-3 text-center">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenStockDetails(s);
                      }}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold border transition-all hover:scale-105 ${
                        s.isShariahCompliant
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35 shadow-sm shadow-emerald-500/10'
                          : 'bg-rose-500/15 text-rose-300 border-rose-500/35'
                      }`}
                      title={s.shariahReasonAr}
                    >
                      {s.isShariahCompliant ? (
                        <>
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span>متوافق شرعاً</span>
                        </>
                      ) : (
                        <>
                          <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                          <span>غير متوافق</span>
                        </>
                      )}
                    </button>
                  </td>

                  {/* Live Price in EGP */}
                  <td className="py-3 px-3 text-left font-mono tabular-nums">
                    <span className="text-sm font-black text-white">
                      {s.price > 0 ? s.price.toFixed(s.price >= 10 ? 2 : 3) : '-'}
                    </span>
                    <span className="text-[10px] text-slate-500 font-sans mr-1"> ج.م</span>
                  </td>

                  {/* Daily Change % */}
                  <td className="py-3 px-3 text-left font-mono tabular-nums">
                    <span
                      className={`inline-flex items-center gap-0.5 px-2 py-0.5 rounded-lg text-xs font-bold ${
                        isPositive
                          ? 'bg-emerald-500/15 text-emerald-400'
                          : isNegative
                          ? 'bg-rose-500/15 text-rose-400'
                          : 'text-slate-400 bg-slate-800/60'
                      }`}
                    >
                      {isPositive ? (
                        <ArrowUpRight className="w-3.5 h-3.5 stroke-[2.5]" />
                      ) : isNegative ? (
                        <ArrowDownRight className="w-3.5 h-3.5 stroke-[2.5]" />
                      ) : null}
                      <span>
                        {isPositive ? '+' : ''}
                        {s.changePct.toFixed(2)}%
                      </span>
                    </span>
                  </td>

                  {/* Absolute Change in EGP */}
                  <td className="py-3 px-3 text-left font-mono tabular-nums hidden sm:table-cell">
                    <span
                      className={`text-xs font-bold ${
                        isPositive ? 'text-emerald-400' : isNegative ? 'text-rose-400' : 'text-slate-400'
                      }`}
                    >
                      {isPositive ? '+' : ''}
                      {s.changeAbs.toFixed(2)}
                    </span>
                  </td>

                  {/* Value Traded (EGP Liquidity) & 20-day Volume Spike */}
                  <td className="py-3 px-3 text-left font-mono tabular-nums">
                    <div className="flex flex-col items-end">
                      <span className="text-xs font-bold text-cyan-300">
                        {formatEgpMoney(s.valueTraded)}
                      </span>
                      {(() => {
                        const adv20 = getEstimated20DayAvgVolume(s);
                        const vol = s.volume || 0;
                        const hasSpike = vol >= adv20 && (s.valueTraded || 0) >= 50000;
                        if (!hasSpike || adv20 <= 0) return null;
                        const rvol = (vol / adv20).toFixed(1);
                        return (
                          <span
                            className="mt-0.5 inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-black"
                            title={`حجم التداول (${vol.toLocaleString('en-US')}) تجاوز متوسط 20 يوم (${adv20.toLocaleString('en-US')}) بنسبة +${Math.round(((vol / adv20) - 1) * 100)}%`}
                          >
                            <Zap className="w-2.5 h-2.5 text-amber-400 fill-amber-400" />
                            <span>⚡ قفزة 20 يوم ({rvol}x)</span>
                          </span>
                        );
                      })()}
                    </div>
                  </td>

                  {/* Accumulation Zone Range */}
                  <td className="py-3 px-3 text-center font-mono tabular-nums hidden md:table-cell">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-950/40 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold">
                      <Target className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>
                        {(s.price * 0.97).toFixed(s.price >= 10 ? 2 : 3)} - {(s.price * 1.015).toFixed(s.price >= 10 ? 2 : 3)}
                      </span>
                    </span>
                  </td>

                  {/* Daily Range (Low - High) */}
                  <td className="py-3 px-3 text-center font-mono tabular-nums text-slate-300 hidden lg:table-cell">
                    <div className="flex items-center justify-center gap-1.5 text-[11px]">
                      <span className="text-rose-400">{s.low.toFixed(2)}</span>
                      <span className="text-slate-600">-</span>
                      <span className="text-emerald-400">{s.high.toFixed(2)}</span>
                    </div>
                  </td>

                  {/* Action Buttons */}
                  <td className="py-3 px-3 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {/* Detailed 360 Report Button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenDetailedReport(s);
                        }}
                        className="px-2 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/35 text-[11px] font-bold flex items-center gap-1 transition-all"
                        title="عرض التقرير الفني والشرعي المفصل 360°"
                      >
                        <FileText className="w-3 h-3 text-cyan-400" />
                        <span className="hidden sm:inline">تقرير 360°</span>
                      </button>

                      {/* Google AI Search & News Analyst Button */}
                      {onOpenGoogleAiNews && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenGoogleAiNews(s.symbol);
                          }}
                          className="px-2 py-1 rounded-lg bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/35 text-[11px] font-bold flex items-center gap-1 transition-all"
                          title="محلل AI وبحث Google لرصد الأخبار والإفصاحات اللحظية للسهم"
                        >
                          <Bot className="w-3 h-3 text-teal-300" />
                          <span className="hidden md:inline">أخبار Google</span>
                        </button>
                      )}

                      {/* Direct Chart AI Analysis Button */}
                      {onOpenDirectChartAi && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenDirectChartAi(s);
                          }}
                          className="px-2 py-1 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/35 text-cyan-300 border border-cyan-500/40 text-[11px] font-bold flex items-center gap-1 transition-all"
                          title="تحليل الشارت المباشر بالذكاء الاصطناعي دون إرفاق صورة"
                        >
                          <Bot className="w-3 h-3 text-cyan-300" />
                          <span className="hidden xl:inline">تحليل الشارت</span>
                        </button>
                      )}

                      {/* Quick Price Alert Action Button */}
                      <button
                        type="button"
                        onClick={(e) => handleOpenAlertPopover(e, s)}
                        className={`px-2 py-1 rounded-lg border text-[11px] font-bold flex items-center gap-1 transition-all ${
                          hasActiveAlert
                            ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-500/40 shadow-sm shadow-amber-500/20'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700 hover:text-amber-300'
                        }`}
                        title={
                          hasActiveAlert
                            ? `إدارة تنبيهات السعر (${matchingAlerts.length} نشط)`
                            : 'تحديد تنبيه سعر لحظي'
                        }
                      >
                        {hasActiveAlert ? (
                          <BellRing className="w-3 h-3 text-amber-400" />
                        ) : (
                          <Bell className="w-3 h-3 text-slate-400" />
                        )}
                        <span className="hidden xl:inline">{hasActiveAlert ? 'تنبيه نشط' : 'تنبيه'}</span>
                      </button>

                      {/* Direct Chart Button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenChart(s.symbol);
                        }}
                        className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[11px] font-bold flex items-center gap-1 transition-all"
                        title="فتح شارت TradingView التفاعلي المباشر"
                      >
                        <Zap className="w-3 h-3 text-emerald-400" />
                        <span>الشارت</span>
                      </button>

                      {/* Copy Stock Summary */}
                      <button
                        type="button"
                        onClick={(e) => handleCopyStockSummary(e, s)}
                        className={`p-1.5 rounded-lg border text-xs font-bold transition-all ${
                          copiedSymbol === s.symbol
                            ? 'bg-emerald-500/30 text-emerald-300 border-emerald-500/50'
                            : 'bg-slate-800 text-slate-400 hover:text-white border-slate-700'
                        }`}
                        title="نسخ ملخص السهم والحكم الشرعي"
                      >
                        {copiedSymbol === s.symbol ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Quick Price Alert Floating Popover */}
      {alertPopoverStock && alertPopoverAnchor && (
        <QuickAlertPopover
          stock={alertPopoverStock}
          isOpen={Boolean(alertPopoverStock)}
          anchorRect={alertPopoverAnchor}
          onClose={() => {
            setAlertPopoverStock(null);
            setAlertPopoverAnchor(null);
          }}
          alerts={userAlerts}
          onSaveAlert={onSaveAlert || (async () => {})}
          onToggleAlert={onToggleAlert || (async () => {})}
          onDeleteAlert={onDeleteAlert || (async () => {})}
          isLoggedIn={isLoggedIn}
          onOpenAuthModal={onOpenAuthModal}
        />
      )}
    </div>
  );
};
