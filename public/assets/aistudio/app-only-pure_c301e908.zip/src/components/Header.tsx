import React, { useState, useRef, useEffect } from 'react';
import {
  Activity,
  RefreshCw,
  Search,
  BookOpen,
  X,
  Bell,
  FileText,
  LogIn,
  LogOut,
  ShieldCheck,
  User as UserIcon,
  Bot,
  Image as ImageIcon,
  FileSpreadsheet,
  Download,
  Zap,
  MessageSquare,
  Globe,
} from 'lucide-react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { EGXStock, WatchlistCategory } from '../types/stock';
import { signInWithGoogle, logOut } from '../services/firebase';
import { EGX_MARKET_INDICES, MarketIndexItem, getLiveCalculatedIndices } from '../data/marketIndices';
import { TradingViewRatingWidget } from './TradingViewRatingWidget';

interface HeaderProps {
  stocks: EGXStock[];
  selectedSymbol: string;
  onExportMasterExcel: () => void;
  onOpenGlobalMarkets?: () => void;
  onOpenLiquidityAlerts?: () => void;
  liquidityAlertsCount?: number;
  onSelectStock: (symbol: string) => void;
  isLoading: boolean;
  onRefresh: () => void;
  lastUpdated: string;
  shariahOnly: boolean;
  onToggleShariahOnly: () => void;
  onOpenShariahGuide: () => void;
  currentUser: User | null;
  onOpenAlertsModal: () => void;
  onOpenDailyReportModal: () => void;
  onOpen360Report?: () => void;
  onOpenAdvisor?: () => void;
  onOpenAdvisorWithSymbol?: (symbol: string) => void;
  onOpenReportWithStock?: (stock: EGXStock) => void;
  onSelectStockForTab?: (symbol: string, tab: any) => void;
  onOpenChartVision?: () => void;
  onOpenGoogleAiNews?: () => void;
  onOpenGoogleAiNewsWithSymbol?: (symbol: string) => void;
  onOpenStockChat?: () => void;
  onSelectIndexCategory?: (category: WatchlistCategory) => void;
  onOpenUserGuide?: () => void;
  onOpenHealthModal?: () => void;
  healthScore?: number;
  alertsCount: number;
  refreshInterval?: number;
  onRefreshIntervalChange?: (intervalSec: number) => void;
  countdownSeconds?: number;
  zoomLevel?: '100' | '90' | '85';
  onZoomLevelChange?: (level: '100' | '90' | '85') => void;
}

function normalizeArabicText(text: string): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/[ة]/g, 'ه')
    .replace(/[ى]/g, 'ي')
    .replace(/[\u064B-\u065F]/g, '')
    .trim();
}

export const Header: React.FC<HeaderProps> = ({
  stocks,
  selectedSymbol,
  onExportMasterExcel,
  onOpenGlobalMarkets,
  onSelectStock,
  isLoading,
  onRefresh,
  lastUpdated,
  shariahOnly,
  onToggleShariahOnly,
  onOpenShariahGuide,
  currentUser,
  onOpenAlertsModal,
  onOpenLiquidityAlerts,
  liquidityAlertsCount,
  onOpenDailyReportModal,
  onOpen360Report,
  onOpenAdvisor,
  onOpenAdvisorWithSymbol,
  onOpenReportWithStock,
  onSelectStockForTab,
  onOpenChartVision,
  onOpenGoogleAiNews,
  onOpenGoogleAiNewsWithSymbol,
  onOpenStockChat,
  onSelectIndexCategory,
  onOpenUserGuide,
  onOpenHealthModal,
  healthScore,
  alertsCount,
  refreshInterval,
  onRefreshIntervalChange,
  countdownSeconds,
  zoomLevel = '100',
  onZoomLevelChange,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Close search on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setShowSearchResults(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter EGX Indices (EGX30, EGX70, EGX100, Shariah Index, etc.)
  const indexResults = React.useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase().trim();
    const normQ = normalizeArabicText(q);

    return getLiveCalculatedIndices(stocks).filter((idx) => {
      const sym = idx.symbol.toLowerCase();
      const normSym = normalizeArabicText(idx.symbol);
      const normNameAr = normalizeArabicText(idx.nameAr);
      const normNameEn = normalizeArabicText(idx.nameEn);

      // Check if user is searching for an index or market category
      const isIndexIntent =
        normQ.includes('مؤشر') ||
        normQ.includes('ايجي') ||
        normQ.includes('ايجى') ||
        normQ.includes('egx') ||
        normQ.includes('index') ||
        normQ === '30' ||
        normQ === '70' ||
        normQ === '100' ||
        normQ.includes('شريع') ||
        normQ.includes('shariah');

      if (!isIndexIntent) {
        return (
          sym.includes(q) ||
          normSym.includes(normQ) ||
          normNameAr.includes(normQ) ||
          normNameEn.includes(normQ)
        );
      }

      // Check specific index number
      if (normQ.includes('30') || q.includes('30')) {
        return idx.symbol.includes('30');
      }
      if (normQ.includes('70') || q.includes('70')) {
        return idx.symbol.includes('70');
      }
      if (normQ.includes('100') || q.includes('100')) {
        return idx.symbol.includes('100');
      }
      if (normQ.includes('شريع') || q.includes('shariah')) {
        return idx.symbol.toLowerCase().includes('shariah');
      }

      return true;
    });
  }, [searchQuery, stocks]);

  const searchResults = React.useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase().trim();
    const normQ = normalizeArabicText(q);

    return stocks
      .filter((s) => {
        const sym = s.symbol.toLowerCase();
        const normSym = normalizeArabicText(s.symbol);
        const normNameAr = normalizeArabicText(s.nameAr);
        const normNameEn = normalizeArabicText(s.nameEn || '');
        const normSector = normalizeArabicText(s.sectorAr || '');

        return (
          sym.includes(q) ||
          normSym.includes(normQ) ||
          normNameAr.includes(normQ) ||
          normNameEn.includes(normQ) ||
          normSector.includes(normQ)
        );
      })
      .slice(0, 25);
  }, [searchQuery, stocks]);

  return (
    <header className="border-b border-slate-800 bg-[#0b0f17]/95 backdrop-blur-md sticky top-0 z-40 px-2 sm:px-4 lg:px-6 py-2.5 font-['Cairo']">
      <div className="max-w-[1850px] w-full mx-auto flex flex-col md:flex-row items-center justify-between gap-3 sm:gap-4">
        {/* Zone 1: Brand Wordmark & Official Title */}
        <div className="flex items-center gap-3.5 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-600 p-0.5 shadow-lg shadow-emerald-500/20 shrink-0">
              <div className="w-full h-full bg-[#070a0f] rounded-[10px] flex items-center justify-center">
                <Activity className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white">
                  مستشار التداول الذكي
                </h1>
                <span className="text-[11px] font-bold text-emerald-400 border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                  مؤشر الشريعة
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">
                تحليل فني لحظي، الأسواق العالمية والخليجية والبورصة المصرية عبر TradingView
              </p>
            </div>
          </div>

          {/* Mobile Refresh Button */}
          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={onRefresh}
              disabled={isLoading}
              className="p-2 rounded-xl bg-slate-800 text-slate-200 border border-slate-700 hover:text-white"
              title="تحديث الأسعار الآن"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-cyan-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Zone 2: Instant Search Autocomplete */}
        <div className="relative w-full md:w-72 lg:w-80" ref={searchContainerRef}>
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSearchResults(true);
              }}
              onFocus={() => setShowSearchResults(true)}
              placeholder="ابحث برمز السهم أو الاسم (مثل TMGH, السويدي)..."
              className="w-full bg-slate-900/90 border border-slate-700/80 rounded-xl pr-10 pl-8 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Autocomplete Dropdown */}
          {showSearchResults && (searchResults.length > 0 || indexResults.length > 0) && (
            <div className="absolute top-full mt-1.5 right-0 left-0 bg-slate-950 border border-slate-700 rounded-2xl shadow-2xl p-2 z-50 space-y-2 max-h-96 overflow-y-auto">
              {/* Indices Matching Section (EGX30, EGX70, EGX100, Shariah) */}
              {indexResults.length > 0 && (
                <div className="space-y-1.5 pb-2 border-b border-slate-800">
                  <div className="text-[10px] text-amber-400 font-bold px-2 py-1 flex justify-between items-center bg-amber-500/10 rounded-lg border border-amber-500/20">
                    <span>مؤشرات السوق الرئيسية ({indexResults.length}) - اضغط للتحليل المباشر</span>
                    <span className="font-mono text-[9px]">EGX Indices AI Analysis</span>
                  </div>
                  {indexResults.map((idx) => (
                    <div
                      key={idx.id}
                      className="p-2.5 rounded-xl bg-slate-900/90 border border-amber-500/40 hover:border-amber-400 transition-all space-y-2 shadow-sm"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          onSelectStock(idx.symbol);
                          if (onOpenAdvisorWithSymbol) {
                            onOpenAdvisorWithSymbol(idx.symbol);
                          } else if (onOpenAdvisor) {
                            onOpenAdvisor();
                          }
                          setShowSearchResults(false);
                          setSearchQuery('');
                        }}
                        className="w-full text-right flex items-center justify-between text-xs cursor-pointer group"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-black text-amber-300 text-sm group-hover:text-amber-200">
                            {idx.symbol}
                          </span>
                          <span className="text-white font-bold text-xs truncate max-w-[170px] group-hover:text-cyan-300">
                            {idx.nameAr}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 font-mono">
                          <span className="font-bold text-white tabular-nums">{idx.points.toLocaleString('ar-EG')}</span>
                          <span
                            className={`text-[10px] font-bold ${
                              idx.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            ({idx.changePct >= 0 ? '+' : ''}{idx.changePct}%)
                          </span>
                        </div>
                      </button>

                      <div className="flex items-center gap-1.5 pt-1.5 border-t border-slate-800/80 text-[10px] flex-wrap">
                        {/* Primary Button: Open General Index Analysis */}
                        <button
                          type="button"
                          onClick={() => {
                            onSelectStock(idx.symbol);
                            if (onOpenAdvisorWithSymbol) {
                              onOpenAdvisorWithSymbol(idx.symbol);
                            } else if (onOpenAdvisor) {
                              onOpenAdvisor();
                            }
                            setShowSearchResults(false);
                            setSearchQuery('');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white font-bold transition-all shadow-sm flex items-center gap-1 cursor-pointer"
                        >
                          <Bot className="w-3 h-3 text-cyan-200" />
                          <span>تحليل المؤشر العام AI 🤖</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            onSelectStock(idx.symbol);
                            onSelectStockForTab?.(idx.symbol, 'CHART');
                            setShowSearchResults(false);
                            setSearchQuery('');
                          }}
                          className="px-2 py-1 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 font-bold transition-colors cursor-pointer"
                        >
                          شارت {idx.symbol} 📈
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            onSelectIndexCategory?.(idx.categoryFilter);
                            setShowSearchResults(false);
                            setSearchQuery('');
                          }}
                          className="px-2 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-bold transition-colors cursor-pointer"
                        >
                          أسهم {idx.symbol}
                        </button>
                        {onOpenGoogleAiNewsWithSymbol && (
                          <button
                            onClick={() => {
                              onOpenGoogleAiNewsWithSymbol(idx.symbol);
                              setShowSearchResults(false);
                              setSearchQuery('');
                            }}
                            className="px-2 py-0.5 rounded-lg bg-teal-500/15 hover:bg-teal-500/30 text-teal-300 font-bold transition-colors"
                          >
                            🌐 أخبار Google
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Stocks Matching Section */}
              {searchResults.length > 0 && (
                <div className="text-[10px] text-slate-400 font-bold px-2 py-1 flex justify-between items-center">
                  <span>الأسهم المطابقة ({searchResults.length})</span>
                  <span className="text-cyan-400 font-mono">EGX TradingView</span>
                </div>
              )}
              {searchResults.map((s) => (
                <div
                  key={s.symbol}
                  className="p-2 rounded-xl bg-slate-900/70 hover:bg-slate-800/90 border border-slate-800 transition-colors"
                >
                  <div
                    onClick={() => {
                      onSelectStock(s.symbol);
                      setShowSearchResults(false);
                      setSearchQuery('');
                    }}
                    className="cursor-pointer flex items-center justify-between text-xs group"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-white group-hover:text-cyan-400 text-sm">
                        {s.symbol}
                      </span>
                      <span className="text-slate-200 font-semibold truncate max-w-[170px]">
                        {s.nameAr}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                          s.isShariahCompliant
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {s.isShariahCompliant ? 'شريعة ✅' : 'تقليدي'}
                      </span>
                      <TradingViewRatingWidget stock={s} variant="MINI_BADGE" />
                      <span className="font-mono font-bold text-slate-200">
                        {s.price > 0 ? s.price.toFixed(2) : '-'} ج.م
                      </span>
                      <span
                        className={`text-[10px] font-mono font-bold ${
                          s.changePct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        ({s.changePct >= 0 ? '+' : ''}{s.changePct}%)
                      </span>
                    </div>
                  </div>

                  {/* Quick Action Shortcuts */}
                  <div className="mt-1.5 pt-1.5 border-t border-slate-800/60 flex items-center gap-1.5 flex-wrap">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectStockForTab?.(s.symbol, 'TECHNICAL_ANALYST');
                        setShowSearchResults(false);
                        setSearchQuery('');
                      }}
                      className="px-2 py-0.5 rounded-lg bg-indigo-500/15 hover:bg-indigo-500/30 text-indigo-300 text-[10px] font-bold transition-colors"
                    >
                      📈 التحليل الفني
                    </button>
                    {onOpenAdvisorWithSymbol && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenAdvisorWithSymbol(s.symbol);
                          setShowSearchResults(false);
                          setSearchQuery('');
                        }}
                        className="px-2 py-0.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/30 text-cyan-300 text-[10px] font-bold transition-colors"
                      >
                        🤖 المستشار
                      </button>
                    )}
                    {onOpenReportWithStock && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenReportWithStock(s);
                          setShowSearchResults(false);
                          setSearchQuery('');
                        }}
                        className="px-2 py-0.5 rounded-lg bg-teal-500/15 hover:bg-teal-500/30 text-teal-300 text-[10px] font-bold transition-colors"
                      >
                        📑 تقرير 360°
                      </button>
                    )}
                    {onOpenGoogleAiNewsWithSymbol && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenGoogleAiNewsWithSymbol(s.symbol);
                          setShowSearchResults(false);
                          setSearchQuery('');
                        }}
                        className="px-2 py-0.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/30 text-emerald-300 text-[10px] font-bold transition-colors"
                      >
                        🌐 أخبار Google
                      </button>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectStockForTab?.(s.symbol, 'CHART');
                        setShowSearchResults(false);
                        setSearchQuery('');
                      }}
                      className="px-2 py-0.5 rounded-lg bg-blue-500/15 hover:bg-blue-500/30 text-blue-300 text-[10px] font-bold transition-colors"
                    >
                      📊 الشارت
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Zone 3: Shariah Filter Switch, Alerts, Daily Report & Google Auth */}
        <div className="flex items-center gap-2 flex-wrap w-full md:w-auto justify-end">
          {/* Screen Display Scale / Zoom Controller to prevent side clipping on laptops */}
          {onZoomLevelChange && (
            <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded-xl text-[11px] font-mono shadow-sm">
              <span className="text-slate-400 px-1 text-[10px] hidden xl:inline">عرض الشاشة:</span>
              {(['100', '90', '85'] as const).map((z) => (
                <button
                  key={z}
                  onClick={() => onZoomLevelChange(z)}
                  className={`px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                    zoomLevel === z
                      ? 'bg-cyan-500 text-slate-950 font-black shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title={`ضبط حجم الشاشة إلى ${z}%`}
                >
                  {z}%
                </button>
              ))}
            </div>
          )}

          {/* Global Markets & Moving Averages Launcher */}
          {onOpenGlobalMarkets && (
            <button
              onClick={onOpenGlobalMarkets}
              className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-500 hover:from-blue-500 hover:to-teal-400 text-white font-black text-xs flex items-center gap-1.5 shadow-md shadow-cyan-600/25 active:scale-95 transition-all cursor-pointer border border-cyan-300/40"
              title="الأسواق العالمية والمتوسطات المتحركة والتنبيهات اللحظية"
            >
              <Globe className="w-3.5 h-3.5 text-white" />
              <span>الأسواق العالمية 🌍</span>
            </button>
          )}

          {/* محلل AI وبحث Google (Google AI Search & News Analyst) - Matching User Attachment */}
          {onOpenGoogleAiNews && (
            <button
              onClick={onOpenGoogleAiNews}
              className="px-4 py-1.5 rounded-full bg-gradient-to-r from-teal-500 via-emerald-500 to-teal-400 hover:from-teal-400 hover:to-emerald-300 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-teal-500/35 active:scale-95 transition-all cursor-pointer border border-teal-200/50 hover:brightness-110"
              title="محلل AI وبحث Google لرصد أحدث الأخبار والإفصاحات اللحظية لأي سهم"
            >
              <Bot className="w-4 h-4 text-slate-950" />
              <span>محلل AI وبحث Google 🤖</span>
            </button>
          )}

          {/* Prominent AI Technical Advisor Button */}
          {onOpenAdvisor && (
            <button
              onClick={onOpenAdvisor}
              className="relative px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg shadow-cyan-600/30 transition-all border border-cyan-400/40 hover:scale-[1.02]"
              title="المستشار الفني الذكي المباشر (AI Technical Advisor)"
            >
              <Bot className="w-4 h-4 text-cyan-200" />
              <span>المستشار الفني 🤖</span>
            </button>
          )}

          {/* Institutional Liquidity Inflow Alerts (ADV-20 Spike) */}
          {onOpenLiquidityAlerts && (
            <button
              onClick={onOpenLiquidityAlerts}
              className="relative px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-orange-500/20 to-amber-500/10 hover:from-amber-500/30 hover:to-orange-500/30 text-amber-300 border border-amber-500/50 text-xs font-black flex items-center gap-1.5 transition-all shadow-md shadow-amber-500/15 cursor-pointer active:scale-95"
              title="رادار تنبيهات تدفق السيولة المؤسساتية اللحظية (تجاوز متوسط حجم 20 يوم)"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400 animate-pulse" />
              <span>رادار السيولة ⚡</span>
              {liquidityAlertsCount !== undefined && liquidityAlertsCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-mono text-[10px] font-black animate-bounce">
                  {liquidityAlertsCount}
                </span>
              )}
            </button>
          )}

          {/* Chart Vision AI Button */}
          {onOpenChartVision && (
            <button
              onClick={onOpenChartVision}
              className="px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
              title="تحليل الشارت الفني بالرؤية الحاسوبية من خلال صورة مرفقة (Gemini Vision)"
            >
              <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">شارت بصورة</span>
            </button>
          )}

          {/* Free-form AI Stock Chat Drawer Button */}
          {onOpenStockChat && (
            <button
              onClick={onOpenStockChat}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500/20 to-teal-500/20 hover:from-cyan-500/30 hover:to-teal-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
              title="فتح شريط المحادثة المباشر للاستفسارات الحرة لأي سهم مختار بالذكاء الاصطناعي"
            >
              <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
              <span>استفسار حر 💬</span>
            </button>
          )}

          {/* Shariah-Only Toggle Switch */}
          <button
            onClick={onToggleShariahOnly}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm ${
              shariahOnly
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-emerald-500/15'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
            title="تصفية فورية لعرض أسهم الشريعة الإسلامية فقط"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                shariahOnly ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
              }`}
            />
            <span>أسهم الشريعة</span>
          </button>

          {/* 360 Comprehensive Report Button */}
          {onOpen360Report && (
            <button
              onClick={onOpen360Report}
              className="px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/35 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm"
              title="عرض التقرير الفني والشرعي الشامل 360° للسهم الحالي"
            >
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              <span>تقرير 360°</span>
            </button>
          )}

          {/* Master All-Stocks Comprehensive Excel Report Button (Requested) */}
          {onExportMasterExcel && (
            <button
              onClick={onExportMasterExcel}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white font-black text-xs flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/25 active:scale-95 cursor-pointer border border-emerald-400/40"
              title="تحميل التقرير العام الشامل لجميع الأسهم المصرية (290+ سهم) من جميع النواحي والخطط والأهداف والمخاطر ومقياس التجميع والتصريف (.xlsx)"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>تقرير شامل عام Excel لكل الأسهم 📊</span>
              <Download className="w-3.5 h-3.5 text-emerald-200" />
            </button>
          )}

          {/* Daily Automated Analysis Report Button */}
          <button
            onClick={onOpenDailyReportModal}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-bold flex items-center gap-1.5 transition-colors"
            title="التقرير اليومي الآلي لأداء البورصة المصرية وأسهم الشريعة"
          >
            <FileText className="w-3.5 h-3.5 text-teal-400" />
            <span className="hidden sm:inline">التقرير اليومي</span>
          </button>

          {/* User Alerts System Trigger */}
          <button
            onClick={onOpenAlertsModal}
            className="relative px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 text-xs font-bold flex items-center gap-1.5 transition-colors"
            title="تنبيهات الأسعار المخصصة (Firestore Sync)"
          >
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">التنبيهات</span>
            {alertsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-mono text-[9px] font-black">
                {alertsCount}
              </span>
            )}
          </button>

          {/* Smart User Guide Button (Requested) */}
          {onOpenUserGuide && (
            <button
              onClick={onOpenUserGuide}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600/30 to-teal-600/30 hover:from-cyan-600/40 hover:to-teal-600/40 text-cyan-200 border border-cyan-500/50 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
              title="دليل المستخدم الذكي والشامل للتطبيق"
            >
              <BookOpen className="w-3.5 h-3.5 text-cyan-300" />
              <span>دليل الاستخدام 📖</span>
            </button>
          )}

          {/* System Health Check Button (Requested) */}
          {onOpenHealthModal && (
            <button
              onClick={onOpenHealthModal}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
              title="فحص سلامة النظام الشامل والإصلاح الفوري"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">صحة النظام:</span>
              <span className="font-mono text-emerald-300 font-bold">{healthScore ?? 100}%</span>
            </button>
          )}

          {/* Shariah Standards Guide Button */}
          <button
            onClick={onOpenShariahGuide}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-bold flex items-center gap-1.5 transition-colors"
            title="معايير وضوابط الفحص الشرعي للأسهم المصرية"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
          </button>

          {/* Refresh Interval Selector & Countdown */}
          {onRefreshIntervalChange && refreshInterval !== undefined && (
            <div className="hidden xl:flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 rounded-xl px-2.5 py-1 text-xs">
              <span className="text-slate-400 font-bold text-[11px]">التحديث:</span>
              <select
                value={refreshInterval}
                onChange={(e) => onRefreshIntervalChange(Number(e.target.value))}
                className="bg-transparent text-cyan-300 font-bold focus:outline-none cursor-pointer text-xs font-['Cairo']"
                title="تحديد فترة التحديث التلقائي لبيانات وأسعار البورصة المصرية"
              >
                <option value={15} className="bg-slate-950 text-slate-200">15 ثانية ⚡</option>
                <option value={30} className="bg-slate-950 text-slate-200">30 ثانية</option>
                <option value={60} className="bg-slate-950 text-emerald-400 font-bold">1 دقيقة (افتراضي ⭐)</option>
                <option value={120} className="bg-slate-950 text-slate-200">2 دقيقة</option>
                <option value={300} className="bg-slate-950 text-slate-200">5 دقائق</option>
                <option value={0} className="bg-slate-950 text-rose-300">يدوي فقط</option>
              </select>
              {refreshInterval > 0 && countdownSeconds !== undefined && (
                <span className="font-mono text-[10px] text-cyan-400 font-bold bg-cyan-950/80 px-1 py-0.5 rounded border border-cyan-800/60 tabular-nums">
                  {countdownSeconds}ث
                </span>
              )}
            </div>
          )}

          {/* Refresh Button */}
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-all shadow-sm disabled:opacity-50"
            title="تحديث تدقيق الأسعار من TradingView"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-cyan-300' : ''}`} />
            <span>تحديث</span>
          </button>

          {/* Google Auth User Pill */}
          {currentUser ? (
            <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 rounded-xl px-2.5 py-1 text-xs">
              {currentUser.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt={currentUser.displayName || ''}
                  className="w-5 h-5 rounded-full border border-emerald-500/50"
                />
              ) : (
                <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px]">
                  {currentUser.displayName?.charAt(0) || 'U'}
                </div>
              )}
              <span className="text-[11px] font-bold text-white max-w-[90px] truncate hidden md:inline">
                {currentUser.displayName?.split(' ')[0] || 'حسابي'}
              </span>
              <button
                onClick={() => logOut()}
                className="text-slate-400 hover:text-rose-400 p-0.5 ml-0.5"
                title="تسجيل الخروج"
              >
                <LogOut className="w-3 h-3" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => signInWithGoogle()}
              className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all"
              title="تسجيل الدخول بحساب Google لمزامنة التنبيهات مع Firestore"
            >
              <LogIn className="w-3.5 h-3.5 text-rose-500" />
              <span>دخول Google</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
