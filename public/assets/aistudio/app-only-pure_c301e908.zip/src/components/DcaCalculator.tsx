import React, { useState, useMemo } from 'react';
import {
  Calculator,
  Target,
  Info,
  CheckCircle2,
  TrendingDown,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { EGXStock } from '../types/stock';

interface DcaCalculatorProps {
  stocks: EGXStock[];
  selectedSymbol: string;
  onSelectStock: (symbol: string) => void;
}

export const DcaCalculator: React.FC<DcaCalculatorProps> = ({
  stocks,
  selectedSymbol,
  onSelectStock,
}) => {
  const stock = stocks.find((s) => s.symbol === selectedSymbol) || stocks[0];
  const currentPrice = stock?.price || 50;

  const [originalPrice, setOriginalPrice] = useState<number>(() =>
    Number((currentPrice * 1.15).toFixed(2))
  );
  const [originalShares, setOriginalShares] = useState<number>(1000);
  const [targetBuyPrice, setTargetBuyPrice] = useState<number>(() =>
    Number((currentPrice * 0.96).toFixed(2))
  );
  const [newSharesToAdd, setNewSharesToAdd] = useState<number>(1000);

  // Sync when stock changes
  React.useEffect(() => {
    if (stock && stock.price > 0) {
      setOriginalPrice(Number((stock.price * 1.15).toFixed(2)));
      setTargetBuyPrice(Number((stock.price * 0.97).toFixed(2)));
    }
  }, [stock?.symbol]);

  const calculation = useMemo(() => {
    const originalCost = originalPrice * originalShares;
    const additionalCost = targetBuyPrice * newSharesToAdd;
    const totalCost = originalCost + additionalCost;
    const totalShares = originalShares + newSharesToAdd;
    const newAveragePrice = totalShares > 0 ? totalCost / totalShares : 0;
    const priceReductionPct =
      originalPrice > 0 ? ((originalPrice - newAveragePrice) / originalPrice) * 100 : 0;

    const currentPositionValue = currentPrice * totalShares;
    const unrealizedDiff = currentPositionValue - totalCost;
    const distanceToBreakevenPct =
      currentPrice > 0 ? ((newAveragePrice - currentPrice) / currentPrice) * 100 : 0;

    return {
      originalCost,
      additionalCost,
      totalCost,
      totalShares,
      newAveragePrice: Number(newAveragePrice.toFixed(2)),
      priceReductionPct: Number(priceReductionPct.toFixed(1)),
      distanceToBreakevenPct: Number(distanceToBreakevenPct.toFixed(1)),
      unrealizedDiff: Number(unrealizedDiff.toFixed(2)),
    };
  }, [originalPrice, originalShares, targetBuyPrice, newSharesToAdd, currentPrice]);

  return (
    <div className="rounded-2xl border border-slate-800 bg-[#0a0e17] p-5 sm:p-6 shadow-2xl space-y-6 font-['Cairo']">
      {/* Title */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>حاسبة التعديل الذكي لمتوسط السعر (DCA Calculator)</span>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300">
                {stock.symbol}
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              احسب بدقة عدد الأسهم المطلوبة وسعر التعادل ونسبة خفض المتوسط لمحفظتك
            </p>
          </div>
        </div>

        {/* Stock Selector Dropdown */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400 font-bold">السهم المختار:</label>
          <select
            value={stock.symbol}
            onChange={(e) => onSelectStock(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-1.5 text-xs font-bold focus:outline-none focus:border-cyan-500"
          >
            {stocks.slice(0, 30).map((s) => (
              <option key={s.symbol} value={s.symbol}>
                {s.symbol} - {s.nameAr}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Input Fields */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Input 1 */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-300 block">
            سعر الشراء الأصلي (ج.م):
          </label>
          <input
            type="number"
            step="0.05"
            value={originalPrice}
            onChange={(e) => setOriginalPrice(parseFloat(e.target.value) || 0)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm font-mono font-bold text-white focus:outline-none focus:border-cyan-500"
          />
          <span className="text-[10px] text-slate-500 block">سعر دخولك القديم</span>
        </div>

        {/* Input 2 */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-300 block">
            عدد الأسهم المملوكة حالياً:
          </label>
          <input
            type="number"
            step="100"
            value={originalShares}
            onChange={(e) => setOriginalShares(parseInt(e.target.value, 10) || 0)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm font-mono font-bold text-white focus:outline-none focus:border-cyan-500"
          />
          <span className="text-[10px] text-slate-500 block">الكمية بمحفظتك الآن</span>
        </div>

        {/* Input 3 */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-300 block">
            سعر التعديل المقترح (ج.م):
          </label>
          <input
            type="number"
            step="0.05"
            value={targetBuyPrice}
            onChange={(e) => setTargetBuyPrice(parseFloat(e.target.value) || 0)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm font-mono font-bold text-cyan-300 focus:outline-none focus:border-cyan-500"
          />
          <span className="text-[10px] text-slate-500 block">
            السعر الحالي: {currentPrice.toFixed(2)} ج.م
          </span>
        </div>

        {/* Input 4 */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-slate-300 block">
            عدد الأسهم الجديدة للشراء:
          </label>
          <input
            type="number"
            step="100"
            value={newSharesToAdd}
            onChange={(e) => setNewSharesToAdd(parseInt(e.target.value, 10) || 0)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm font-mono font-bold text-emerald-300 focus:outline-none focus:border-cyan-500"
          />
          <span className="text-[10px] text-slate-500 block">
            السيولة المطلوبة: {calculation.additionalCost.toLocaleString()} ج.م
          </span>
        </div>
      </div>

      {/* Calculated Results Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
          <span className="text-[11px] text-slate-400 block mb-1">متوسط السعر الجديد</span>
          <div className="text-xl font-mono font-black text-emerald-400">
            {calculation.newAveragePrice.toFixed(2)}{' '}
            <span className="text-xs font-sans text-slate-400 font-normal">ج.م</span>
          </div>
          <span className="text-[10px] text-emerald-400/90 block mt-1 font-bold">
            انخفض بنسبة {calculation.priceReductionPct}%
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
          <span className="text-[11px] text-slate-400 block mb-1">المسافة لسعر التعادل</span>
          <div className="text-xl font-mono font-black text-cyan-300">
            {calculation.distanceToBreakevenPct}%
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            من السعر الحالي ({currentPrice.toFixed(2)} ج.م)
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
          <span className="text-[11px] text-slate-400 block mb-1">السيولة الإضافية المطلوبة</span>
          <div className="text-xl font-mono font-black text-amber-300">
            {calculation.additionalCost.toLocaleString()}{' '}
            <span className="text-xs font-sans text-slate-400 font-normal">ج.م</span>
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            لشراء {newSharesToAdd.toLocaleString()} سهم
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
          <span className="text-[11px] text-slate-400 block mb-1">إجمالي التكلفة الإجمالية</span>
          <div className="text-xl font-mono font-black text-white">
            {calculation.totalCost.toLocaleString()}{' '}
            <span className="text-xs font-sans text-slate-400 font-normal">ج.م</span>
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            إجمالي {calculation.totalShares.toLocaleString()} سهم
          </span>
        </div>
      </div>

      {/* Advisory Note */}
      <div className="p-3.5 rounded-xl bg-cyan-950/20 border border-cyan-500/30 text-xs text-cyan-200 flex items-start gap-2.5">
        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <p>
          نصيحة إدارة المخاطر: لا تقم بالتعديل دفعة واحدة؛ وزع السيولة على مستويات الدعم الفنية الرئيسية (مثل تصحيحات فيبوناتشي 61.8% أو قاع القناة السعرية) بعد تأكيد ارتداد السعر بشمعة عاكسة.
        </p>
      </div>
    </div>
  );
};
