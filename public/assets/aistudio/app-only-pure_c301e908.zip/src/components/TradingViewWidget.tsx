import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  ExternalLink,
  Maximize2,
  Copy,
  Check,
  Zap,
  TrendingUp,
  ShieldCheck,
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  FileText,
  Bot,
  Sparkles,
  Image as ImageIcon,
  RefreshCw,
  Activity,
  Layers,
} from 'lucide-react';
import { EGXStock } from '../types/stock';
import { TradingViewRatingWidget } from './TradingViewRatingWidget';
import { verifyAndSyncReportPrice, VerifiedPriceResult } from '../utils/priceVerificationService';

interface TradingViewWidgetProps {
  stock: EGXStock;
  onOpenShariahGuide: () => void;
  onOpenDetailedReport?: (stock: EGXStock) => void;
  onOpenDirectChartAi?: (stock: EGXStock) => void;
  onOpenChartVision?: () => void;
  liveStocks?: EGXStock[];
}

export const TradingViewWidget: React.FC<TradingViewWidgetProps> = ({
  stock,
  onOpenShariahGuide,
  onOpenDetailedReport,
  onOpenDirectChartAi,
  onOpenChartVision,
  liveStocks,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);

  // Dynamic Remount & Loading States (تحديث ديناميكي وإعادة تحميل مع مؤشر التحميل)
  const [remountKey, setRemountKey] = useState<number>(() => Date.now());
  const [isChartLoading, setIsChartLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Verify and synchronize the live chart price
  const priceCheck: VerifiedPriceResult = React.useMemo(() => {
    return verifyAndSyncReportPrice(stock, liveStocks);
  }, [stock, liveStocks]);

  const verifiedStock = priceCheck.verifiedStock;
  const tvSymbol = verifiedStock.tradingViewSymbol || `EGX:${verifiedStock.symbol}`;
  const directTvUrl = `https://www.tradingview.com/chart/?symbol=${encodeURIComponent(tvSymbol)}`;

  /**
   * Dynamic remount function that guarantees complete re-mounting of the widget
   * when switching stocks or when manually triggered by the user.
   */
  const handleDynamicRemount = useCallback(() => {
    setIsRefreshing(true);
    setIsChartLoading(true);

    // Clean up container DOM before re-mounting
    if (containerRef.current) {
      containerRef.current.innerHTML = '';
    }

    // Force unique key to trigger React component remount
    setRemountKey(Date.now());

    // Stabilization buffer: gives the TradingView iframe time to instantiate without flickering
    const timer = setTimeout(() => {
      setIsChartLoading(false);
      setIsRefreshing(false);
    }, 1100);

    return () => clearTimeout(timer);
  }, []);

  // Trigger dynamic remount whenever the selected stock symbol changes
  useEffect(() => {
    const cleanup = handleDynamicRemount();
    return () => {
      if (cleanup) cleanup();
    };
  }, [tvSymbol, handleDynamicRemount]);

  // Embed TradingView Script on clean remount
  useEffect(() => {
    if (!containerRef.current) return;
    containerRef.current.innerHTML = '';

    const widgetDiv = document.createElement('div');
    widgetDiv.className = 'tradingview-widget-container__widget';
    widgetDiv.style.height = '100%';
    widgetDiv.style.width = '100%';
    containerRef.current.appendChild(widgetDiv);

    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
    script.type = 'text/javascript';
    script.async = true;
    script.innerHTML = JSON.stringify({
      autosize: true,
      symbol: tvSymbol,
      interval: 'D',
      timezone: 'Africa/Cairo',
      theme: 'dark',
      style: '1',
      locale: 'ar_AE',
      enable_publishing: false,
      hide_top_toolbar: false,
      hide_legend: false,
      save_image: true,
      calendar: false,
      hide_volume: false,
      withdateranges: true,
      allow_symbol_change: true,
      details: true,
      hotlist: false,
      support_host: 'https://www.tradingview.com',
    });
    containerRef.current.appendChild(script);

    return () => {
      if (containerRef.current) {
        containerRef.current.innerHTML = '';
      }
    };
  }, [remountKey, tvSymbol]);

  const handleCopySymbol = () => {
    navigator.clipboard.writeText(tvSymbol);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenPopout = () => {
    const width = 1260;
    const height = 800;
    const left = Math.max(0, (window.screen.width - width) / 2);
    const top = Math.max(0, (window.screen.height - height) / 2);
    window.open(
      directTvUrl,
      'TradingViewProLive',
      `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes,status=yes`
    );
  };

  const isPos = verifiedStock.changePct >= 0;

  return (
    <div className="rounded-2xl border border-slate-800 bg-[#0a0e17] p-4 sm:p-5 shadow-2xl space-y-4 font-['Cairo']">
      {/* Chart Top Header & HUD */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 border-b border-slate-800 pb-3.5">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="font-mono text-base font-black text-white bg-slate-900 border border-slate-700 px-3 py-1 rounded-xl">
              {verifiedStock.symbol}
            </span>
            <button
              onClick={handleCopySymbol}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="نسخ كود السهم لـ TradingView"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>{verifiedStock.nameAr}</span>
              <span className="text-xs font-normal text-slate-400 hidden sm:inline">
                ({verifiedStock.nameEn})
              </span>
            </h2>
          </div>

          {/* Shariah Badge */}
          <div
            onClick={onOpenShariahGuide}
            className={`cursor-pointer flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold border transition-all ${
              verifiedStock.isShariahCompliant
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35 hover:bg-emerald-500/25'
                : 'bg-rose-500/15 text-rose-300 border-rose-500/35 hover:bg-rose-500/25'
            }`}
          >
            {verifiedStock.isShariahCompliant ? (
              <>
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>متوافق مع الشريعة الإسلامية</span>
              </>
            ) : (
              <>
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                <span>غير متوافق شرعاً (تقليدي)</span>
              </>
            )}
          </div>

          {/* TradingView Instant Technical Rating Mini Badge */}
          <TradingViewRatingWidget stock={verifiedStock} variant="MINI_BADGE" />

          {/* Stability & Freshness Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-400">
            <span className={`w-2 h-2 rounded-full ${isChartLoading ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
            <span>{isChartLoading ? 'استقرار العرض...' : 'شارت مستقر 🟢'}</span>
          </div>
        </div>

        {/* Live Price and Actions */}
        <div className="flex items-center gap-3 flex-wrap w-full lg:w-auto justify-between lg:justify-end">
          {/* Synchronized Verified Chart Price */}
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 font-mono text-xs shadow-sm">
            <span className="text-slate-400 font-sans">سعر الشارت الحالي:</span>
            <strong className="text-base text-white font-black">{verifiedStock.price.toFixed(2)}</strong>
            <span className="text-[10px] text-slate-500">ج.م</span>
            <span
              className={`flex items-center font-bold px-1.5 py-0.2 rounded text-[11px] ${
                isPos ? 'bg-emerald-500/15 text-emerald-400' : 'bg-rose-500/15 text-rose-400'
              }`}
            >
              {isPos ? <ArrowUpRight className="w-3 h-3 ml-0.5 inline" /> : <ArrowDownRight className="w-3 h-3 ml-0.5 inline" />}
              {isPos ? '+' : ''}{verifiedStock.changePct}%
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Dynamic Re-mount / Refresh Chart Button (Requested) */}
            <button
              onClick={handleDynamicRemount}
              disabled={isRefreshing}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 hover:border-cyan-400 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95 disabled:opacity-50"
              title="إعادة تحميل وتحديث الشارت مع مؤشر الاستقرار الفوري"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-cyan-400' : 'text-cyan-400'}`} />
              <span className="hidden sm:inline">تحديث الشارت 🔄</span>
            </button>

            {onOpenDirectChartAi && (
              <button
                onClick={() => onOpenDirectChartAi(verifiedStock)}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg shadow-cyan-600/25 border border-cyan-400/40 transition-all hover:scale-[1.02] cursor-pointer"
                title="تحليل شارت TradingView المباشر بالذكاء الاصطناعي دون إرفاق صورة"
              >
                <Bot className="w-3.5 h-3.5 text-cyan-200" />
                <span className="hidden sm:inline">تحليل الشارت AI 🤖</span>
                <span className="sm:hidden">تحليل AI</span>
              </button>
            )}

            {onOpenChartVision && (
              <button
                onClick={onOpenChartVision}
                className="px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                title="تحليل الشارت بصورة أو لقطة شاشة عبر الرؤية الحاسوبية (Gemini Vision)"
              >
                <ImageIcon className="w-3.5 h-3.5 text-indigo-400" />
                <span className="hidden md:inline">شارت بصورة 📷</span>
              </button>
            )}

            {onOpenDetailedReport && (
              <button
                onClick={() => onOpenDetailedReport(verifiedStock)}
                className="px-3.5 py-1.5 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
                title="عرض التقرير الفني والشرعي المفصل 360°"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>تقرير 360°</span>
              </button>
            )}

            <button
              onClick={handleOpenPopout}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
              title="فتح الشارت في نافذة متقدمة منفصلة"
            >
              <Zap className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">شاشة كاملة</span>
              <Maximize2 className="w-3 h-3" />
            </button>

            <a
              href={directTvUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
              title="فتح في موقع TradingView الرسمي"
            >
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>

      {/* Embedded Chart Container with Integrated In-Frame Loading Indicator */}
      <div className="relative w-full h-[520px] rounded-xl overflow-hidden border border-slate-800/80 bg-slate-950 shadow-inner">
        {/* Loading Indicator Inside Chart Frame (Requested: مؤشر تحميل داخل إطار الشارت لضمان استقرار العرض عند تبديل الأسهم) */}
        {isChartLoading && (
          <div className="absolute inset-0 z-30 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center gap-3.5 text-center p-4 transition-opacity duration-300">
            <div className="relative flex items-center justify-center">
              <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                <Activity className="w-7 h-7 text-cyan-400 animate-pulse" />
              </div>
              <Sparkles className="w-4 h-4 text-emerald-400 absolute -top-1 -right-1 animate-spin" />
            </div>

            <div className="space-y-1 max-w-sm">
              <div className="flex items-center justify-center gap-2">
                <span className="font-bold text-white text-sm">جارٍ تحميل واستقرار الشارت اللحظي</span>
                <span className="font-mono text-cyan-300 text-xs px-2 py-0.5 rounded bg-slate-900 border border-slate-700">
                  {verifiedStock.symbol}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                إعادة تهيئة الإطار وتحديث الشموع لـ {verifiedStock.nameAr} بتوقيت القاهرة
              </p>
            </div>

            {/* Micro Progress Pulse Bar */}
            <div className="w-48 h-1 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div className="h-full bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 rounded-full animate-pulse w-full" />
            </div>
          </div>
        )}

        {/* The Re-mounted TradingView Widget DOM Element */}
        <div
          key={`tv-chart-frame-${remountKey}`}
          ref={containerRef}
          className="tradingview-widget-container h-full w-full"
        />
      </div>

      {/* Exact TradingView Technical Chart Opinion & Speedometer Gauge */}
      <TradingViewRatingWidget
        stock={verifiedStock}
        timeframeLabel="يومي (1D)"
        variant="FULL_CARD"
        onOpenChart={() => handleOpenPopout()}
      />

      {/* Bottom Shariah Details Strip with Synchronized Price Tag */}
      <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-slate-300 flex-wrap">
          <span className="font-bold text-emerald-400">بيان التوافق الشرعي:</span>
          <span>{verifiedStock.shariahReasonAr}</span>
        </div>
        <div className="flex items-center gap-3 font-mono text-[11px] text-slate-400 shrink-0">
          <span>سعر الشارت المؤكد: <strong className="text-cyan-300 font-bold">{verifiedStock.price.toFixed(2)} ج.م</strong></span>
          {verifiedStock.shariahRatioDebt !== undefined && (
            <>
              <span>•</span>
              <span>نسبة الديون: <strong className="text-white">{verifiedStock.shariahRatioDebt}%</strong> (&lt;33%)</span>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
